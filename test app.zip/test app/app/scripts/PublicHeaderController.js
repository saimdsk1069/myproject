(function () {
    'use strict';
}());

angular.module('agSADCeFarms')
    .controller('PublicHeaderController', ['$scope', '$log', '$state', 'AuthService',
        'modalService', 'modalMessageService', 'agSupportEmail', '$window',
        function( $scope, $log, $state, AuthService,
                  modalService, modalMessageService, agSupportEmail, $window ) {

            $scope.login = function() {
                $state.go('app.public');
            };

    }])
;
