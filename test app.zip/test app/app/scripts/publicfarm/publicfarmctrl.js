(function () {
    'use strict';
}());

angular.module('agSADCeFarms')
    .controller('PublicFarmBaseController',function($scope,$state,GetfarmInfo) {
        $scope.toggleCollapse = false;
        $scope.farmid = $state.params.farm_id;


        $scope.ui_components = {
            'ui_farmdashboard_applications': true,
            'ui_farmdashboard_expenses': true,
            'ui_farmdashboard_contacts': true,
            'ui_farmdashboard_scores': true,
            'ui_farmdashboard_expenseedit': true
        };

    });

angular.module('agSADCeFarms')
    .constant('errorImageURL', '../app/images/error-404.png')
    .controller('publicfarmctrl', ['$scope', '$uibModal', '$state', '$log',
        function($scope,$uibModal,$state,$log,modalService,modalMessageService) {

        if($state.params.farm_id == null || typeof($state.params.farm_id) == undefined || $state.params.farm_id == ''){
            $state.go('app.home');
        }
    }]);

//FarmInfo
angular.module('agSADCeFarms')
    .controller('PublicFarmInfoController', ['$scope','$uibModal','GetfarmInfo','DeleteFarmTags',
        'GetFarmTags','$log','modalMessageService','$stateParams','errorImageURL','modalService',
        function($scope, $uibModal,GetfarmInfo,DeleteFarmTags,GetFarmTags,$log,modalMessageService,
          $stateParams, errorImageURL,modalService){


        //Get Farm Details
        var farmInfo = GetfarmInfo.getFarmInfo($scope.farmid).get()
           .$promise.then(
              function(response){
                $scope.FarmInfo =response;
              });




        $scope.parents = [];
        $scope.children = [];
        $scope.current_flg = false;
        var PFICtrl = this;
        PFICtrl.showErrorMessage = false;
        PFICtrl.errorImageURL = errorImageURL;
         PFICtrl.getFarmId = function(){
            return $stateParams.farm_id;
         };

        PFICtrl.tagOrder= {};
        PFICtrl.farmInfo = GetfarmInfo.getFarmInfo(PFICtrl.getFarmId()).get()
                  .$promise.then(
                    function(response){
                       PFICtrl.farmInfo =response;
                       $scope.current_flg = PFICtrl.farmInfo.current_flg;
                       $scope.parents = PFICtrl.farmInfo.farm_lineage.parents;
                       $scope.children = PFICtrl.farmInfo.farm_lineage.children;

                    },
                    function(response) {
                    $log.debug("ERROR GETTING FarmInfo:", response);
                         if ( response.data === '{ "error": "Bad Request UE" }' ) {
                             toastr.error('Error occured while fetching FarmInfo');
                         } else {
                             toastr.error("Please enter a valid Farm ID");
                             PFICtrl.showErrorMessage = true;
                         }
                         $log.debug("Error: "+ response.status + " " + response.statusText);

                    }

                 );


        //Tages edit mode
        PFICtrl.isTagsInEditMode = false;

        PFICtrl.putTagsInEditMode = function(){
            PFICtrl.isTagsInEditMode = true;
        };

        PFICtrl.putTagsToNormalMode = function(){
            PFICtrl.isTagsInEditMode = false;
        };

        $scope.redirectFarm = function(farmID){
            window.location.href = '#farm/'+farmID;
        };

        PFICtrl.deleteTag = function(index){
            var deletefarm = {
                         "farm_id": PFICtrl.farmInfo.farm_tags[index].farm_id,
                         "farm_tag_desc":  PFICtrl.farmInfo.farm_tags[index].farm_tag_desc};
           DeleteFarmTags.deleteFarmTags(deletefarm)
                            .then(
                               function(response){
                                  console.log(response);
                                  console.log('farm Tag deleted');
                                   PFICtrl.refreshFarmTags();
                                   toastr.success('Tag deleted successfully');
                               },
                               function(response) {
                                    $log.debug("ERROR Delete  tag:", response);
                                    toastr.error('Error occured while deleting tag');
                                    $log.debug("Error: "+response.status + " " + response.statusText);
                                }
                          );
        };

        PFICtrl.refreshFarmTags = function(){
            GetFarmTags.getFarmTags(PFICtrl.farmInfo.farm_id)
                  .then(
                    function(response){
                       PFICtrl.farmInfo.farm_tags =response;
                    },
                    function(response) {
                    $log.debug("ERROR GETTING FUNDDETAILS:", response);
                         if ( response.data === '{ "error": "Bad Request UE" }' ) {
                             modalMessageService.showMessage( "Error:", "Check the service");
                         } else {
                             modalMessageService.showMessage( "Error:", "An error occurred. ");
                         }
                         $log.debug("Error: "+response.status + " " + response.statusText);

                    }

                 );
        };

        PFICtrl.createNewTag = function(){
        var farmID = PFICtrl.farmInfo.farm_id;
            var modalInstance = $uibModal.open({
              animation: true,
                size: 'sm',
                static : true,
              templateUrl: 'views/farm/add_new_tag_modal.html',
              backdrop: 'static',
                resolve:{
                farm_id : function(){
                  return PFICtrl.farmInfo.farm_id;
                }
              },
              controller: ['$scope','$uibModalInstance','AddNewTag','getTagTypes','farm_id',
                  function($scope, $uibModalInstance, AddNewTag,getTagTypes,farm_id){
                  getTagTypes.getTagTypes().then(function(response){
                      $scope.tagTypes = response.data;
                    }, function(response){
                      toastr.warning('Error while getting TagTypes');
                    });
                  $scope.ok= function(){
                      var newTag = {
                          "farm_id": farmID,
                          "farm_tag_desc": $scope.tagDescription.farm_tag_desc};
                    AddNewTag.addNewTag().save(newTag)
                            .$promise.then(
                               function(response){
                                  $uibModalInstance.close();
                                  toastr.success('Tag added successfully');
                               },
                               function(response) {
                                    $log.debug("ERROR ADDING TODOITEM:", response);
                                    toastr.error('Error occured while adding tag');
                                    $log.debug("Error: "+response.status + " " + response.statusText);
                                    $uibModalInstance.close();
                                }
                          );

                };
                $scope.cancel= function(){
                    $uibModalInstance.dismiss();
                };
              }]

            });

            modalInstance.result.then(function () {
              PFICtrl.refreshFarmTags();
            }, function () {

            });
        };
    }]);

