(function () {
    'use strict';
}());

angular.module('agSADCeFarms')

    .constant("baseURL", "/AG_SADCeFarms/")
    .constant("agSupportEmail", "efarmssupport@ag.nj.gov")

    .service('modalMessageService', [ '$log', 'modalService', '$uibModal',  function( $log, modalService, $uibModal ) {
        this.showMessage = function ( heading, message ) {
            var modalOptions = {
                actionButtonText: 'Close',
                closeButtonVisible: false,
                headerText: heading,
                bodyText: message
            };
            modalService.showModal({}, modalOptions, {})
                // We don't care about the response
                .then( function(response){
                    $log.debug("Finished with modal message service");
                }, function(){
                    $log.debug("Finished with modal message service");
                });
        };

    }])
;

