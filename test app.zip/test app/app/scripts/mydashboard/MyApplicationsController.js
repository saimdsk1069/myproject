(function () {
    'use strict';
}());
angular.module('agSADCeFarms')
        .controller('MyApplicationsController', ['$scope', '$state', '$log', 'MyDashboardservices', '$sce', '$http', '$window', 'modalService', 'modalMessageService', '$uibModal', '$rootScope', function ($scope, $state, $log, MyDashboardservices, $sce, $http, $window, modalService, modalMessageService, $uibModal, $rootScope) {

                $rootScope.getApps = function () {
                    MyDashboardservices.fetchApplication().then(
                            function (response) {
                                $rootScope.gridMyDAppsInActive.data = response.inactive_applications;
                                $rootScope.gridMyDAppsActive.data = response.active_applications;
                            },
                            function (errResponse) {
                                toastr.clear();
                                toastr.error('Bad Connectivity / Server Down', 'Error while fetching Application Data');
                            }
                    );
                };

                /* -- Previous Apps  -- */
                var preAppLink = "<div class='ui-grid-cell-contents'> <a class='myDAppLink' href='#application/{{row.entity.application_id}}'><u>{{row.entity.application_id}}</u></a> </div>";
                $rootScope.gridMyDAppsInActive = {
                    paginationPageSizes: false,
                    enableFiltering: true,
                    enableRowSelection: true,
                    enableColumnResizing: true,
                    multiSelect: false,
                    resizable: true,
                    enableFullRowSelection: true,
                    enableRowHeaderSelection: false,
                    paginationPageSize: 25,
                    enableGridMenu: true,
                    exporterCsvFilename: 'Application_Inactive.csv',
                    exporterPdfDefaultStyle: {fontSize: 12},
                    exporterMenuVisibleData : true,
                    exporterPdfTableStyle: {margin: [60, 60, 60, 60]},
                    exporterPdfTableHeaderStyle: {fontSize: 12, bold: true, italics: true, color: 'black'},
                    exporterPdfHeader: { text: "Applications Inactive Details", style: 'headerStyle' },
                    exporterPdfFooter: function ( currentPage, pageCount ) {
                      return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' };
                    },
                    exporterPdfCustomFormatter: function ( docDefinition ) {
                      docDefinition.styles.headerStyle = { fontSize: 22, bold: true };
                      docDefinition.styles.footerStyle = { fontSize: 10, bold: true };
                      return docDefinition;
                    },
                    exporterPdfOrientation: 'landscape',
                    exporterPdfPageSize: 'LETTER',
                    exporterPdfMaxGridWidth: 500,
                    exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
                    exporterExcelFilename: 'Applications_Inactive.xlsx',
                    exporterExcelSheetName: 'Sheet1',
                    appScopeProvider: $scope,
                    //rowTemplate: '<div ng-click="grid.appScope.viewAppScore(row)" ng-repeat="(colRenderIndex, col) in colContainer.renderedColumns track by col.uid" class="ui-grid-cell " ng-class="col.colIndex()" ui-grid-cell></div>',
                    columnDefs: [
                        {name: 'application_id', displayName: 'Application ID', cellTooltip: true, cellTemplate:preAppLink},
                        {name: 'application_date', displayName: 'Application Date', cellTooltip: true,  cellFilter: 'date:"MMM dd,y"'},
                        {name: 'application_type', displayName: 'Application Type', cellTooltip: true},
                        {name: 'application_phase', displayName: 'Application Phase', cellTooltip: true},
                        {name: 'application_status', displayName: 'Application Status', cellTooltip: true},
                        {name: 'program_type', displayName: 'Program Type', cellTooltip: true},
                        {name: 'partner_name', displayName: 'Partner', cellTooltip: true},
                        {name: 'last_edited_date', displayName: 'Last Edited', cellTooltip: true, cellFilter: 'date:"MMM dd,y"'}
                    ]
                };

                $rootScope.gridMyDAppsInActive.onRegisterApi = function (gridMyDAppsInActiveAPI) {
                    $rootScope.gridMyDAppsInActive = gridMyDAppsInActiveAPI;
                };

                /* -- Current Apps  -- */
                var curAppLink = "<div class='ui-grid-cell-contents'> <a class='myDAppLink' href='#application/{{row.entity.application_id}}'><u>{{row.entity.application_id}}</u></a> </div>";
                $rootScope.gridMyDAppsActive = {
                    paginationPageSizes: false,
                    enableFiltering: true,
                    enableRowSelection: true,
                    enableColumnResizing: true,
                    multiSelect: false,
                    resizable: true,
                    enableFullRowSelection: true,
                    enableRowHeaderSelection: false,
                    paginationPageSize: 25,
                    enableGridMenu: true,
                    exporterCsvFilename: 'Application_Active.csv',
                    exporterPdfDefaultStyle: {fontSize: 12},
                    exporterMenuVisibleData : true,
                    exporterPdfTableStyle: {margin: [60, 60, 60, 60]},
                    exporterPdfTableHeaderStyle: {fontSize: 12, bold: true, italics: true, color: 'black'},
                    exporterPdfHeader: { text: "Applications Inactive Details", style: 'headerStyle' },
                    exporterPdfFooter: function ( currentPage, pageCount ) {
                      return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' };
                    },
                    exporterPdfCustomFormatter: function ( docDefinition ) {
                      docDefinition.styles.headerStyle = { fontSize: 22, bold: true };
                      docDefinition.styles.footerStyle = { fontSize: 10, bold: true };
                      return docDefinition;
                    },
                    exporterPdfOrientation: 'landscape',
                    exporterPdfPageSize: 'LETTER',
                    exporterPdfMaxGridWidth: 500,
                    exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
                    exporterExcelFilename: 'Application_Active.xlsx',
                    exporterExcelSheetName: 'Sheet1',
                    appScopeProvider: $scope,
                    //rowTemplate: '<div ng-click="grid.appScope.viewAppScore(row)" ng-repeat="(colRenderIndex, col) in colContainer.renderedColumns track by col.uid" class="ui-grid-cell " ng-class="col.colIndex()" ui-grid-cell></div>',
                    columnDefs: [
                        {name: 'application_id', displayName: 'Application ID', cellTooltip: true,  cellTemplate: curAppLink},
                        {name: 'application_date', displayName: 'Application Date', cellTooltip: true, cellFilter: 'date:"MMM dd,y"'},
                        {name: 'application_type', displayName: 'Application Type', cellTooltip: true},
                        {name: 'application_phase', displayName: 'Application Phase', cellTooltip: true},
                        {name: 'application_status', displayName: 'Application Status', cellTooltip: true},
                        {name: 'program_type', displayName: 'Program Type', cellTooltip: true},
                        {name: 'partner_name', displayName: 'Partner', cellTooltip: true},
                        {name: 'last_edited_date', displayName: 'Last Edited', cellTooltip: true, cellFilter: 'date:"MMM dd,y"'}
                    ]
                };

                $rootScope.gridMyDAppsActive.onRegisterApi = function (gridMyDAppsActiveAPI) {
                    $rootScope.gridMyDAppsActive = gridMyDAppsActiveAPI;
                };

                $rootScope.getApps();

            }]);