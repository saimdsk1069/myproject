(function() {
    'use strict';
}());

angular.module('agSADCeFarms')
.constant("baseURL", "/AG_SADCeFarms/")
.factory('MyDashboardservices', ['$http','baseURL', '$q', function($http, baseURL, $q) {

      return {
             fetchToDos: function () {
                        return $http.get(baseURL+'mytodos')
                                .then(
                                        function (response) {
                                            return response.data;
                                        },
                                        function (errResponse) {
                                            console.error('Error while fetching Dashboard TODO ');
                                            //return $q.reject(errResponse);
                                        }
                                );
                    },
             fetchAccountInfo: function() {
                return $http.get(baseURL+'myaccount')
                        .then(
                        function(response) {
                            return response.data;
                        },
                        function(errResponse) {
                            toastr.clear();
                            toastr.error('Bad Connectivity / Server Down', 'Error while fetching User Account Details');
                            //console.error('Error while fetching Admin ToDo Data');
                            //return $q.reject(errResponse);
                        }
                );
            },
             putAccountInfo: function (putData) {
                        var URL = baseURL + 'userinfo';
                        return $http.put(URL, putData)
                                .then(
                                        function (response) {
                                            return response;
                                        },
                                        function (errResponse) {
                                            console.error('Error while Submitting User Account Info');
                                            //return $q.reject(errResponse);
                                        }
                                );
                    },
             fetchApplication: function () {
                        return $http.get(baseURL+'myapps')
                                .then(
                                        function (response) {
                                            return response.data;
                                        },
                                        function (errResponse) {
                                            console.error('Error while fetching Application Data');
                                            //return $q.reject(errResponse);
                                        }
                                );
                    },
           fetchNotifications: function () {

                        return $http.get(baseURL+'notification')

                                .then(
                                        function (response) {
                                            return response.data;
                                        },
                                        function (errResponse) {
                                            console.error('Error while fetching Dashboard Notifications ');
                                            //return $q.reject(errResponse);
                                        }
                                );
                    },
           delDashboardNotification: function (NotifyID) {
                        var url = baseURL + 'notification/' + NotifyID;
                        return $http({
                            method: 'DELETE',
                            url: url
                        }).then(
                                function (response) {
                                    return response.data;
                                },
                                function (errResponse) {
                                    console.error('Error while Deleting Notification');
                                    //return $q.reject(errResponse);
                                }
                        );
                    }
                };
            }]);
