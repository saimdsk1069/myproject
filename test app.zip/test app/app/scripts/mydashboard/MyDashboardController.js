(function () {
    'use strict';
}());
angular.module('agSADCeFarms')
    .controller('MyDashBaseController',function($scope) {
        $scope.toggleCollapse = false;
    });

angular.module('agSADCeFarms')
    .controller('MyDashboardController',function($scope) {
        $scope.toggleCollapse = false;
    });

angular.module('agSADCeFarms')
        .controller('MyToDoController', ['$scope', '$state','$location', '$log', 'MyDashboardservices', 'applicationService', '$sce', '$http', '$window', 'modalService', 'modalMessageService', '$uibModal', '$rootScope', function ($scope, $state,$location, $log, MyDashboardservices, applicationService, $sce, $http, $window, modalService, modalMessageService, $uibModal, $rootScope) {

                $rootScope.getToDos = function () {
                    MyDashboardservices.fetchToDos().then(
                            function (response) {
                                $rootScope.gridMyDToDos.data = response;
                            },
                            function (errResponse) {
                                toastr.clear();
                                toastr.error('Bad Connectivity / Server Down', 'Error while fetching myDashboard ToDo');
                            }
                    );
                };

                var appLink = "<div class='ui-grid-cell-contents'> <a href='#/application/{{row.entity.application_id}}/edittodoitem/{{row.entity.todo_item_guid}}'><u>{{row.entity.application_id}}</u></a> </div>";
                var farmLink = "<div class='ui-grid-cell-contents'> <a href='#farm/{{row.entity.farm_id}}/edittodoitem/{{row.entity.todo_item_guid}}'><u>{{row.entity.farm_id}}</u></a> </div>";
                $rootScope.gridMyDToDos = {
                    paginationPageSizes: false,
                    enableFiltering: true,
                    enableRowSelection: false,
                    enableColumnResizing: true,
                    multiSelect: false,
                    resizable: true,
                    enableFullRowSelection: false,
                    enableRowHeaderSelection: false,
                    paginationPageSize: 25,
                    enableGridMenu: true,
                    exporterCsvFilename: 'ToDos.csv',
                    exporterPdfDefaultStyle: {fontSize: 12},
                    exporterMenuVisibleData : true,
                    exporterPdfTableStyle: {margin: [60, 60, 60, 60]},
                    exporterPdfTableHeaderStyle: {fontSize: 12, bold: true, italics: true, color: 'black'},
                    exporterPdfHeader: { text: "ToDo Details", style: 'headerStyle' },
                    exporterPdfFooter: function ( currentPage, pageCount ) {
                      return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' };
                    },
                    exporterPdfCustomFormatter: function ( docDefinition ) {
                      docDefinition.styles.headerStyle = { fontSize: 22, bold: true };
                      docDefinition.styles.footerStyle = { fontSize: 10, bold: true };
                      return docDefinition;
                    },
                    exporterPdfOrientation: 'landscape',
                    exporterPdfPageSize: 'LETTER',
                    exporterPdfMaxGridWidth: 500,
                    exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
                    exporterExcelFilename: 'ToDos.xlsx',
                    exporterExcelSheetName: 'Sheet1',
                    appScopeProvider: $scope,
                    rowTemplate: '<div ng-click="grid.appScope.viewMyTodo(row)" ng-repeat="(colRenderIndex, col) in colContainer.renderedColumns track by col.uid" class="ui-grid-cell " ng-class="col.colIndex()" ui-grid-cell></div>',
                    columnDefs: [
                        {name: 'application_id', displayName: 'Application ID', cellTooltip: true, cellTemplate:appLink},
                        {name: 'farm_id', displayName: 'Farm ID', cellTooltip: true, cellTemplate:farmLink},
                        {name: 'todo_item_title', displayName: 'Title', cellTooltip: true},
                        {name: 'todo_item_due_date', displayName: 'Due Date', cellTooltip: true, cellFilter: 'date:"MMM dd,y"'},
                        {name: 'assigner', displayName: 'Assigner', cellTooltip: true},
                        {name: 'created_date', displayName: 'Created Date', cellTooltip: true, cellFilter: 'date:"MMM dd,y"'}
                    ]
                };

            $scope.viewMyTodo = function (row, itemID) {
                console.log('FOUND viewMyTodo');
                if (row != '' && row != undefined && row != null) {
                    var toDoGUID = row.entity.todo_item_guid;
                } else if (itemID != '' && itemID != undefined && itemID != null) {
                    var toDoGUID = itemID;
                }
                if (toDoGUID || itemID) {
                    var dataObj = applicationService.fetchAppToDoItem(toDoGUID).then(
                        function (response) {
                            return response;
                        },
                        function (errResponse) {
                            console.error('Error while fetching ToDo Item');
                        }
                    );
                    var modalInstance = $uibModal.open({
                        templateUrl: 'checkToDoItem.html',
                        controller: 'checkToDoItemCtrl',
                        size: 'lg',
                        backdrop: 'static',
                        resolve: {
                            Itemdata: function () {
                                return dataObj;
                            },
                            editItemId: function () {
                                return itemID;
                            }
                        }
                    });
                    modalInstance.result.then(function (selectedItem) {
                        //$scope.selected = selectedItem;
                    }, function () {
                        $rootScope.gridApi3.selection.getSelectedRows();
                        $log.info('Modal dismissed at: ' + new Date());
                    });
                } else {
                    toastr.clear();

                }
            };

                $rootScope.gridMyDToDos.onRegisterApi = function (gridMyDToDosAPI) {
                    $rootScope.gridMyDToDos = gridMyDToDosAPI;
                };

                $rootScope.getToDos();



            }]).controller('checkToDoItemCtrl', function ($scope, $rootScope, $uibModal, modalMessageService, modalService, applicationService, $filter, $window, $uibModalInstance, Itemdata, editItemId, $state,$location) {
    $scope.appToDoSingleItem = Itemdata;

    $scope.dateOptions = {
        formatYear: 'yyyy',
        maxDate: new Date(2022, 5, 22),
        minDate: new Date(1975, 1, 01),
        startingDay: 1
    };

    $scope.today = function () {
        if (Itemdata && Itemdata.todo_item_due_date != null && Itemdata.todo_item_due_date != undefined) {
            $scope.dt = new Date(Itemdata.todo_item_due_date);
        }
    };

    $scope.today();
    $scope.datePick = {};
    $scope.openDate = false;

    applicationService.fetchToDoPhaseDetails($state.params.ID).then(
        function (response) {
            //return response;
            $scope.phaseList = response; //console.log(dataObj);
        },
        function (errResponse) {
            toastr.clear();
            toastr.error('Bad Connectivity / Server Down', 'Error while fetching ToDo Phase Details');
            return {};
        }
    );

    $scope.gotoApp = function(appID){
        //$location.path('/application/'+ appID );
        $state.go('app.application',{ID:appID});
        $uibModalInstance.close('');
    };
    $scope.gotoFarm = function(farmID){
        $state.go('app.farm',{farm_id:farmID});
        $uibModalInstance.close('');
    };

    $scope.addUser = function () {

        var modalInstance = $uibModal.open({
            templateUrl: 'views/application/appAddUser.html',
            controller: 'addUserToDoItemCtrl',
            size: 'lg',
            backdrop: 'static',
            resolve: {
                userData: function () {
                    return $scope.appToDoSingleItem.users;
                }
            }
        });

        modalInstance.result.then(function (selectedItem) {
            //$scope.selected = selectedItem;
        }, function () {
            console.log('Modal dismissed at: ' + new Date());
        });
    };

    $scope.deleteUser = function (userIndex) {
        delete  $scope.editToDo.user[userIndex];
        $scope.appToDoSingleItem.users.splice(userIndex, 1);
        //console.log($scope.editToDo.user);
    };

    $scope.addRole = function () {

        var modalInstance = $uibModal.open({
            templateUrl: 'views/application/appAddRole.html',
            controller: 'addRoleToDoItemCtrl',
            size: 'lg',
            backdrop: 'static',
            resolve: {
                roleData: function () {
                    return $scope.appToDoSingleItem.roles;
                }
            }
        });

        modalInstance.result.then(function (selectedItem) {
            //$scope.selected = selectedItem;
        }, function () {
            console.log('Modal dismissed at: ' + new Date());
        });
    };

    $scope.deleteRole = function (roleIndex) {
        //$scope.editToDo.role.splice(roleIndex,1);
        delete  $scope.editToDo.role[roleIndex];
        //console.log($scope.editToDo.role);
        $scope.appToDoSingleItem.roles.splice(roleIndex, 1);
    };

    $scope.saveItem = function () {

        var putData = {
            "todo_item_guid": $scope.editToDo.ItemGUID,
            "todo_item_title": $scope.editToDo.title,
            "todo_item_desc": $scope.editToDo.desc,
            "todo_item_due_date": $scope.editToDo.dueDate ? $filter('date')($scope.editToDo.dueDate, "yyyy-MM-dd") : null,
            "todo_item_conditional_flg": $scope.editToDo.conditional ? true : false,
            "farm_id": $scope.editToDo.farmID,
            "application_id": $state.params.ID,
            "application_phase_guid": $scope.editToDo.phaseDate ? $scope.editToDo.phaseDate.application_phase_guid : null,
            "users": [],
            "roles": []
        };
        angular.forEach($scope.editToDo.user, function (value, index) {
            var tempUser = {
                "auth_user_guid": value.guid,
                "salutation": value.salutation,
                "first_name": value.first_name,
                "last_name": value.last_name,
                "title": value.title,
                "organization": value.organization
            };
            putData.users.push(tempUser);
        });
        angular.forEach($scope.editToDo.role, function (value, index) {
            var tempRole = {
                "auth_role_guid": value.guid,
                "auth_role_name": value.name
            };
            putData.roles.push(tempRole);
        });
        //console.log(putData);
        if ($scope.editToDo.conditional == true && $scope.editToDo.phaseDate == null) {
            toastr.clear();
            toastr.error('Please select Phase Details', 'Error posting Data');
        } else {
            applicationService.editAppToDoItem(putData, $scope.editToDo.ItemGUID).then(
                function (response) {
                    //$window.location.reload();
                    //console.log(response);

                    applicationService.fetchAppToDoList($state.params.ID).then(
                        function (response) {
                            $rootScope.toDoItemsGridAll.data = response;
                            //$scope.toDoItemslist = response;
                        },
                        function (errResponse) {
                            toastr.clear();
                            toastr.error('Bad Connectivity / Server Down', 'Error while fetching ToDo Items List');
                        }
                    );
                    applicationService.fetchAppToDoListToMe($state.params.ID).then(
                        function (response) {
                            $rootScope.toDoItemsGridToMe.data = response;
                            //$scope.toDoItemslist = response;
                        },
                        function (errResponse) {
                            toastr.clear();
                            toastr.error('Bad Connectivity / Server Down', 'Error while fetching ToDo Items List');
                        }
                    );
                    $uibModalInstance.close('save');
                    if (editItemId) {
                        $window.location.href = '#/mydashboard/todo';
                    }
                },
                function (errResponse) {
                    toastr.clear();
                    toastr.error('Bad Connectivity / Server Down', 'Error while updating ToDoItem');
                }
            );
        }

        //$uibModalInstance.close('Save');
    };

    $scope.deleteItem = function (delToDoGUID) {
        var modalOptions = {
            closeButtonText: 'No',
            actionButtonText: 'Yes',
            headerText: 'Warning',
            bodyText: 'Are you sure you want to delete this item?'
        };
        modalService.showModal({}, modalOptions)
            .then(function (result) {
                applicationService.deleteAppToDoItem(delToDoGUID).then(
                    function (response) {
                        $window.location.reload();
                        modalMessageService.showMessage("Success:", "Contact deleted Successfully");
                        //console.log(response);
                        $uibModalInstance.close('Delete');

                        if (editItemId) {
                            $window.location.href = '#/mydashboard/todo';
                        }
                    },
                    function (errResponse) {
                        toastr.clear();
                        toastr.error('Bad Connectivity / Server Down', 'Error while deleting ToDoItem');
                    }
                );
                console.log(delToDoGUID);
            });
    };

    $scope.markItem = function (markToDoGUID,completeflg) {
        applicationService.markAppToDoItem(markToDoGUID,completeflg).then(
            function (response) {
                $window.location.reload();
                //console.log(response);
                $uibModalInstance.close('Mark Completed');

                if (editItemId) {
                    $window.location.href = '#/mydashboard/todo';
                }
            },
            function (errResponse) {
                console.error('Error while marking Item as Completed');
            }
        );
        console.log(markToDoGUID);
    };

    $scope.cancel = function () {
        $uibModalInstance.dismiss('Cancel');
        if (editItemId) {
            $window.location.href = '#/mydashboard/todo';
        }
    };
});