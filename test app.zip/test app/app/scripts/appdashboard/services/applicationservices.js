(function() {
    'use strict';
}());

angular.module('agSADCeFarms')
.constant("baseURL", "/AG_SADCeFarms/")
.constant("agSupportEmail", "efarmssupport@ag.nj.gov")
.factory('applicationService', ['$http','baseURL', '$q', function($http,baseURL, $q)
    {

        return {

            fetchApplication: function(appID) {
                return $http.get(baseURL+'application/'+appID)
                        .then(
                        function(response) {
                            return response.data;
                        },
                        function(errResponse) {
                            console.error('Error while fetching Application Data');
                        }
                );
            },
            submitApplication: function(formData) {
                return $http.post(baseURL+'appanswer', formData)
                        .then(
                        function(response) {
                            return response;
                        },
                        function(errResponse) {
                            console.error('Error while Submitting Application Data');
                        }
                );
            },
            fetchAppInfo: function(appID) {
                return $http.get(baseURL+'appinfo/' + appID)
                        .then(
                        function(response) {
                            return response.data;
                        },
                        function(errResponse) {
                            console.error('Error while fetching Application Info');
                        }
                );
            },
            fetchAppToDoList: function(appID) {
                return $http.get(baseURL+'todo?application_id='+appID)
                        .then(
                        function(response) {
                            return response.data;
                        },
                        function(errResponse) {
                            console.error('Error while fetching Application ToDo List');
                        }
                );
            },
            fetchAppToDoListToMe: function(appID) {
                return $http.get(baseURL+'mytodos?application_id='+appID)
                        .then(
                        function(response) {
                            return response.data;
                        },
                        function(errResponse) {
                            console.error('Error while fetching Assigned ToDo List');
                        }
                );
            },
            fetchAppToDoItem: function(toDoItemGUID) {
                return $http.get(baseURL+'todo/'+toDoItemGUID)
                        .then(
                        function(response) {
                            return response.data;
                        },
                        function(errResponse) {
                            console.error('Error while fetching Application ToDo Item Service');
                        }
                );
            },
            deleteAppToDoItem: function(toDoItemGUID) {
                var url = baseURL+'todo/'+toDoItemGUID;
                return $http.delete(url)
                        .then(
                        function(response) {
                            return response.data;
                        },
                        function(errResponse) {
                            console.error('Error while deleting ToDo Item');
                        }
                );
            },
            markAppToDoItem: function(toDoItemGUID,completeflg) {
                var markData = {
                    'complete_todo': completeflg
                };
                var url = baseURL+'todo/'+toDoItemGUID;
                return $http.put(url, markData)
                        .then(
                        function(response) {
                            return response.data;
                        },
                        function(errResponse) {
                            console.error('Error while marking ToDo Item as Completed');
                        }
                );
            },
            editAppToDoItem: function(putData, toDoItemGUID) {
                console.log(putData);
                var url = baseURL+'todo/'+toDoItemGUID;
                return $http.put(url, putData)
                        .then(
                        function(response) {
                        toastr.clear();
                        toastr.success('ToDo Item data saved successfully', 'Success');
                            return response.data;
                        },
                        function(errResponse) {
                            toastr.clear();
                            toastr.error('Bad Connectivity / Server Error', 'Error while editing ToDoItem');
                        }
                );
            },
            addAppToDoItem: function(postData, appID) {
                console.log(postData);
                var url = baseURL+'todo?application_id=' + appID; // replace with post url
                return $http.post(url, postData)
                        .then(
                        function(response) {
                        toastr.clear();
                        toastr.success('ToDo Item added successfully', 'Success');
                            return response.data;
                        },
                        function(errResponse) {
                            toastr.clear();
                            toastr.error('Bad Connectivity / Server Error', 'Error while Adding ToDoItem');
                        }
                );
            },
            fetchRolesList: function(appID) {
                var url = baseURL+'roles';
                return $http.get(url)
                        .then(
                        function(response) {
                            return response.data;
                        },
                        function(errResponse) {
                            console.error('Error while adding ToDo Item');
                        }
                );
            },
            fetchUsersList: function(appID) {
                var url = baseURL + 'users';
                return $http.get(url)
                        .then(
                        function(response) {
                            return response.data;
                        },
                        function(errResponse) {
                            console.error('Error while adding ToDo Item');
                        }
                );
            },
            fetchToDoPhaseDetails: function(appID) {
                var url = baseURL+'phase/'+appID;
                return $http.get(url)
                        .then(
                        function(response) {
                            return response.data;
                        },
                        function(errResponse) {
                            console.error('Error while fetching ToDo Phase Details');
                        }
                );
            },
             fetchLoadToDoList: function(appID) {
                var url = baseURL+'todolist?application_id='+ appID;
                return $http.get(url)
                        .then(
                        function(response) {
                            return response.data;
                        },
                        function(errResponse) {
                            console.error('Error while Load ToDo Item');
                        }
                );
            },
            fetchAppMapObj: function(appID) {
                return $http.get(baseURL+'applayers/' + appID)
                    .then(
                        function(response) {
                            return response.data;
                        },
                        function(errResponse) {
                            console.error('Error while fetching Application Map data');
                        }
                    );
            },
              getNoteGroups : function(appId){
                return $http({
                    method: 'GET',
                    url : baseURL+'notegroup?application_id='+ appId,
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });
            },

            postNoteGroup : function(appId, newNoteGroup){
                return $http({
                    method: 'POST',
                    url : baseURL+'notegroup?application_id='+appId,
                    data : newNoteGroup,
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });
            },

            updateNoteGroup : function(noteGroupId, noteGroup){
                return $http({
                    method: 'PUT',
                    url : baseURL+'notegroup/'+noteGroupId,
                    data : noteGroup,
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });
            },

            deleteNoteGroup : function(noteGroupId){
                return $http({
                    method: 'DELETE',
                    url : baseURL+'notegroup/'+noteGroupId,
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });
            },

            postNote : function(newNote){
                return $http({
                    method: 'POST',
                    url : baseURL+'note',
                    data : newNote,
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });
            },

            updateNote : function(noteId, note){
                return $http({
                    method: 'PUT',
                    url : baseURL+'note/'+noteId,
                    data : note,
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });
            },

            deleteNote : function(noteId){
                return $http({
                    method: 'DELETE',
                    url :baseURL+'note/' + noteId,
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });
            },

            postNoteGroupTag : function(noteGroupTag){
                return $http({
                    method: 'POST',
                    url : baseURL+'notegrouptags',
                    data : noteGroupTag,
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });
            },

            getNoteGroupTags : function(){
                return $http({
                    method: 'GET',
                    url : baseURL+'notetagtypes',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });
            },

            deleteNoteGroupTag : function(deleteObj){
                return $http({
                    method: 'DELETE',
                    url : baseURL+'notegrouptags',
                    data : deleteObj,
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });
            },
            fetchAppDocs: function(appID) {
                var url = baseURL + 'document?application_id='+appID;
                return $http.get(url)
                        .then(
                        function(response) {
                            return response.data;
                        },
                        function(errResponse) {
                            console.error('Error while fetching Documents List');
                        }
                );
            },
             downloadDoc: function(docID) {
                var url =  baseURL + 'doc/'+ docID;
                return $http.get(url)
                        .then(
                        function(response) {
                            return response.data;
                        },
                        function(errResponse) {
                            console.error('Error while downloading Document');
                        }
                );
            },
              deleteAppDoc: function(docID,appID) {
                var url = baseURL+ 'document/'+ docID;
                var deleteData = {'application_id':appID};
                return $http({
                    method: 'DELETE',
                    url : url,
                    data : deleteData,
                    headers: {
                        'Content-Type': 'application/json'
                    }
                }).then(
                        function(response) {
                            return response.data;
                        },
                        function(errResponse) {
                            console.error('Error while Deleting Document');
                        }
                );
            },
            fetchUploadDocType: function(appID) {
                var url = baseURL + 'documenttype';
                return $http.get(url)
                        .then(
                        function(response) {
                            return response.data;
                        },
                        function(errResponse) {
                            console.error('Error while fetching Document Type Details');
                        }
                );
            },
            fetchUploadDocStatus: function(appID) {
                var url = baseURL + 'documentstatus';
                return $http.get(url)
                        .then(
                        function(response) {
                            return response.data;
                        },
                        function(errResponse) {
                            console.error('Error while fetching Document Status Details');
                        }
                );
            },
            fetchUploadDocTags: function(appID) {
                var url =  baseURL + 'documenttagtype';
                return $http.get(url)
                        .then(
                        function(response) {
                            return response.data;
                        },
                        function(errResponse) {
                            console.error('Error while fetching Document Tags Details');
                        }
                );
            },
            fetchUploadedDoc: function(appID, docGUID) {
                var url = baseURL + 'document/'+ docGUID;
                return $http.get(url)
                        .then(
                        function(response) {
                            return response.data;
                        },
                        function(errResponse) {
                            console.error('Error while fetching Document Details');

                        }
                );
            },
            uploadEditDocument: function(putData, docGUID) { console.log(putData, docGUID);
                var url = baseURL + 'document/' + docGUID;
                return $http.put(url, putData)
                        .then(
                        function(response) {
                            return response;
                        },
                        function(errResponse) {
                            console.error('Error while Editing Document Details');
                        }
                );
            },
            uploadDocument: function (formData, appID) {
//                        console.log(formData);
                        var url =  baseURL + 'doc?application_id=' + appID; // replace with post url
                       return $http({
                       method: 'POST',
                       url : url,
                       headers: {
                        'Content-Type': undefined
                    },
                         data : formData
                })  .then(
                                        function (response) {
                                            toastr.clear();
                                            toastr.success('Document Uploaded successfully', 'Success');
                                            return response.data;
                                        },
                                        function (errResponse) {
                                            toastr.clear();
                                            toastr.error('Bad Connectivity / Server Error', 'Error while Uploading Document');
                                        }
                                );
            },
            fetchAppScores: function(appID) {
                var url = baseURL + 'appscore/'+ appID;
                return $http.get(url)
                        .then(
                        function(response) {
                            return response.data;
                        },
                        function(errResponse) {
                            console.error('Error while fetching Score Details');
                        }
                );
            },
             fetchAddScoreTypes: function (appID) {
                        var url = baseURL + 'scoretype/'+appID;
                        return $http.get(url)
                                .then(
                                        function (response) {
                                            return response.data;
                                        },
                                        function (errResponse) {
                                            console.error('Error while fetching App Scores Types');
                                        }
                                );
                    },
                    getEditAppScore: function (scoreGUID) {
                        var url = baseURL + 'score/'+scoreGUID;
                        return $http.get(url)
                                .then(
                                        function (response) {
                                            return response.data;
                                        },
                                        function (errResponse) {
                                            console.error('Error while fetching App Scores');
                                        }
                                );
                    },
                    deleteAppScore: function (scoreID, appID) {
                        var url = baseURL + 'score/'+scoreID;
                        var deleteData = {'score_type_guid':scoreID,'application_id': appID};
                        return $http({
                            method: 'DELETE',
                            url: url,
                            data: deleteData,
                            headers: {
                                'Content-Type': 'application/json'
                            }
                        }).then(
                                function (response) {
                                    return response.data;
                                },
                                function (errResponse) {
                                    console.error('Error while Deleting Score');
                                }
                        );

                    },
                   postAppScore: function (postData, appID) {
                        var url = baseURL + 'appscore';

                        return  $http.post(url, postData).then(
                                function (response) {
                                    toastr.clear();
                                    toastr.success('App Score Added successfully', 'Success');
                                    return response.data;
                                },
                                function (errResponse) {
                                    toastr.clear();
                                    toastr.error('Bad Connectivity / Server Error', 'Error while posting App Score');
                                }
                        );

                    },putAppScore: function (putData, appID, scoreGUID) {
                        var url = baseURL + 'score/'+scoreGUID;
                        return  $http.put(url, putData).then(
                                function (response) {
                                    toastr.clear();
                                    toastr.success('App Score updated successfully', 'Success');
                                    return response.data;
                                },
                                function (errResponse) {
                                    toastr.clear();
                                    toastr.error('Bad Connectivity / Server Error', 'Error while editing App Score');
                                }
                        );

                    },
                    fetchScoreStatus: function (appID) {
                        var url = baseURL + 'scorestatus';
                        return $http.get(url)
                                .then(
                                        function (response) {
                                            return response.data;
                                        },
                                        function (errResponse) {
                                            console.error('Error while fetching App Scores');
                                        }
                                );
                    },
                     fetchAppContacts: function(appID){
                        var url = baseURL + 'appcontact/'+ appID;
                        return $http.get(url)
                                .then(
                                        function (response) {
                                            return response.data;
                                        },
                                        function (errResponse) {
                                            console.error('Error while fetching App Contacts');
                                            //return $q.reject(errResponse);
                                        }
                                );

                    },
                    deleteAppContacts: function(contactGUID){
                        var url = baseURL + 'appcontact';
                        var deleteData = {'application_contact_guid': contactGUID};
                        return $http({
                            method: 'DELETE',
                            url: url,
                            data: deleteData,
                            headers: {
                                'Content-Type': 'application/json'
                            }
                        }).then(
                                function (response) {
                                    return response.data;
                                },
                                function (errResponse) {
                                    console.error('Error while Deleting App Contacts');
                                    //return $q.reject(errResponse);
                                }
                        );

                    },
                     fetchAppContactsUsers: function () {
                        var url = baseURL+'users';
                        return $http.get(url)
                                .then(
                                        function (response) {
                                            return response.data;
                                        },
                                        function (errResponse) {
                                            console.error('Error while fetching App Contacts users');
                                            //return $q.reject(errResponse);
                                        }
                                );
                    },
                    fetchAppContactsTypes: function () {
                        var url = baseURL + 'appcontacttype';
                        return $http.get(url)
                                .then(
                                        function (response) {
                                            return response.data;
                                        },
                                        function (errResponse) {
                                            console.error('Error while fetching App Contacts Types');
                                            //return $q.reject(errResponse);
                                        }
                                );
                    },
                    postAppNewContact: function (postData) {
                        var url = baseURL + 'appcontact';

                        return  $http.post(url, postData).then(
                                function (response) {
                                    toastr.clear();
                                    toastr.success('App Contact Added successfully', 'Success');
                                    return response.data;
                                },
                                function (errResponse) {
                                    toastr.clear();
                                    toastr.error('Bad Connectivity / Server Error', 'Error while posting App Contact');
                                    //return $q.reject(errResponse);
                                }
                        );

                    },
                     putAppContact: function (putData) {
                        var url = baseURL + 'appcontact';

                        return  $http.put(url, putData).then(
                                function (response) {
                                    toastr.clear();
                                    toastr.success('App Contact Edited successfully', 'Success');
                                    return response.data;
                                },
                                function (errResponse) {
                                    toastr.clear();
                                    toastr.error('Bad Connectivity / Server Error', 'Error while editing App Contact');
                                    //return $q.reject(errResponse);
                                }
                        );

                    },
                    checkAppID: function (appID) {
                        console.log(appID);
                        if (appID != '' && appID != null && appID != undefined) {
                            return true;
                        } else {
                            return false;
                        }

            }
        };
    }]);
