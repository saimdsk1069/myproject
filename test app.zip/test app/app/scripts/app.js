(function () {
    'use strict';
}());

angular.module('agSADCeFarms', ['ui.router', 'ui.grid', 'ui.grid.selection','ui.grid.exporter', 'ui.grid.expandable','ui.grid.cellNav',
    'ui.grid.saveState', 'ngResource', 'ui.bootstrap', 'ui.grid.pagination','ui.grid.resizeColumns',
    'ui.grid.moveColumns','ui.grid.pinning','ui.grid.edit','ui.mask', 'angular-clipboard', 'esri.map',
    'ng-currency','ngCsv','ui.select','ngSanitize', 'xeditable','hc.marked', 'ngIdle'])
    .config( ['$stateProvider', '$urlRouterProvider','markedProvider', '$logProvider', 'KeepaliveProvider',
            function($stateProvider, $urlRouterProvider, markedProvider, $logProvider, KeepaliveProvider ) {

        // Session management stuff
        //KeepaliveProvider.interval(600); // Time in seconds to check for heartbeat default is 10 minutes
        //KeepaliveProvider.http('/AG_SADCeFarms/keepalive'); // URL that makes sure session is alive

        // Do allow debugging via $log
        $logProvider.debugEnabled(true);
        $stateProvider
            // route for the home page
            .state('app', {
                url:'/',
                views: {
                    'header': {
                        templateUrl : 'views/header.html',
                        controller  : 'HeaderController'
                    },
                    'content': {
                        templateUrl : 'views/mainpages/home.html'
                    }
                },
                permdata: {
                    'auth_access': false,
                    'ui_access': []
                }

            })
            .state('app.home', {
                url:'home',
                views: {
                    'content@': {
                        templateUrl: 'views/mainpages/home.html'
                    }
                },
                permdata: {
                    'auth_access': false,
                    'ui_access': []
                }
            })
            .state('app.mapping', {
                url:'map',
                views: {
                    'content@': {
                        templateUrl: 'views/mapping/mapbase.html',
                        controller  : 'MapController',
                        controllerAs: 'appMapCtrl'
                    }
                },
                permdata: {
                    'auth_access': false,
                    'ui_access': []
                }
            })
            .state('app.about', {
                url:'about',
                views: {
                    'content@': {
                        templateUrl: 'views/mainpages/about.html',
                        controller  : 'AboutPageController'
                    }
                },
                permdata: {
                    'auth_access': false,
                    'ui_access': []
                }
            })
            .state('app.search', {
                url:'search',
                views: {
                    'content@': {
                        templateUrl: 'views/search/search.html',
                        controller  : 'searchController',
                        controllerAs : 'SrchCtrl'
                    }
                },
                 params: {
                    filterObjs: {}
                },
                permdata: {
                    'auth_access': false,
                    'ui_access': ['ui_mydashboard']
                }
            })
            .state('app.searchResults', {
                url:'searchResults',
                views: {
                    'content@': {
                        templateUrl: 'views/search/searchResults.html',
                        controller  : 'searchResultsController',
                        controllerAs : 'SrchRsltsCtrl'
                    }
                },
                params: {
                    filtersAndObjs : {}
                },
                 permdata: {
                    'auth_access': false,
                    'ui_access': []
                }
            })
            // FUTURE FOR TESING
            //.state('app.workflows', {
            //    url:'workflows',
            //    views: {
            //        'content@': {
            //            templateUrl: 'views/workflows/workflows.html',
            //            controller  : 'workflowcontroller'
            //        }
            //    },
            //    permdata: {
            //        'auth_access': false,
            //        'ui_access': []
            //    }
            //})

            //route for finance portal
            .state('app.finance', {
                url:'finance',
                views: {
                    'content@': {
                        templateUrl: 'views/finance/finance.html',
                        controller  : 'FinanceController'
                    },
                    'financeCommands@app.finance': {
                        templateUrl: 'views/finance/commands.html',
                        controller  : 'FinanceController'
                    }

                },
                permdata: {
                    'auth_access': true,
                    'ui_access': ['ui_fiscal']
                }
            })

            .state('app.finance.funds', {
                url:'/funds',
                views: {
                    'financeContent@app.finance': {
                        templateUrl: 'views/finance/funds.html',
                        controller  : 'FundsController'
                    }
                },
                permdata: {
                    'auth_access': true,
                    'ui_access': ['ui_fiscal']
                }
            })
            .state('app.finance.appropriations', {
                url:'/appropriations',
                views: {
                    'financeContent@app.finance': {
                        templateUrl: 'views/finance/appropriations.html',
                        controller  : 'AppropriationController'
                    }
                },
                permdata: {
                    'auth_access': true,
                    'ui_access': ['ui_fiscal']
                }
            })
            .state('app.finance.reappropriations', {
                url:'/reappropriations',
                views: {
                    'financeContent@app.finance': {
                        templateUrl: 'views/finance/reappropriations.html',
                        controller  : 'ReappropController'
                    }
                },
                permdata: {
                    'auth_access': true,
                    'ui_access': ['ui_fiscal']
                }
            })
            .state('app.finance.grants', {
                url:'/grants',
                views: {
                    'financeContent@app.finance': {
                        templateUrl: 'views/finance/grants.html',
                        controller  : 'GrantsController'
                    }
                },
                permdata: {
                    'auth_access': true,
                    'ui_access': ['ui_fiscal']
                }
            })

            .state('app.finance.pools', {
                url:'/pools',
                views: {
                    'financeContent@app.finance': {
                        templateUrl: 'views/finance/pools.html',
                        controller  : 'PoolController'
                    }
                },
                permdata: {
                    'auth_access': true,
                    'ui_access': ['ui_fiscal']
                }
            })

            .state('app.finance.expenses', {
                url:'/expenses',
                views: {
                    'financeContent@app.finance': {
                        templateUrl: 'views/finance/expenses.html',
                        controller  : 'ExpenseController'
                    }
                },
                permdata: {
                    'auth_access': true,
                    'ui_access': ['ui_fiscal']
                }
            })

            .state('app.finance.payments', {
                url:'/payments',
                views: {
                    'financeContent@app.finance': {
                        templateUrl: 'views/finance/payments.html',
                        controller  : 'PaymentController'
                    }
                },
                permdata: {
                    'auth_access': true,
                    'ui_access': ['ui_fiscal']
                }
            })

            .state('app.finance.reports', {
                url:'/reports',
                views: {
                    'financeContent@app.finance': {
                        templateUrl: 'views/finance/reports.html',
                        controller  : 'ReportsController'
                    }
                },
                permdata: {
                    'auth_access': true,
                    'ui_access': ['ui_fiscal']
                }
            })
            .state('app.finance.grants.grantdetail', {
                url:'/grantdetail/:partner_grant_guid',
                views: {
                    'financeContent@app.finance': {
                        templateUrl: 'views/finance/grantdetail.html',
                        controller  : 'GrantsController'
                    }
                },
                permdata: {
                    'auth_access': true,
                    'ui_access': ['ui_fiscal']
                }
            })
            .state('app.finance.newcompetitivepool', {
                url:'/newcompetitivepool',
                views: {
                    'financeContent@app.finance': {
                        templateUrl: 'views/finance/newcompetitivepool.html',
                        controller  : 'PoolController'
                    }
                },
                permdata: {
                    'auth_access': true,
                    'ui_access': ['ui_fiscal']
                }
            })
            .state('app.finance.pools.pooldetails', {
                url:'/pooldetails/:competitive_pool_guid',
                views: {
                    'financeContent@app.finance': {
                        templateUrl: 'views/finance/pooldetails.html',
                        controller  : 'PoolController'
                    }
                },
                permdata: {
                    'auth_access': true,
                    'ui_access': ['ui_fiscal']
                }
            })
            .state('app.finance.funds.funddetail', {
                url:'/detail/:fund_guid',
                views: {
                    'financeContent@app.finance': {
                        templateUrl: 'views/finance/funddetail.html',
                        controller  : 'FundsController'
                    }
                },
                permdata: {
                    'auth_access': true,
                    'ui_access': ['ui_fiscal']
                }
            })

            .state('app.finance.appropriations.appropdetail', {
                url:'/appropdetail/:appropriation_guid',
                views: {
                    'financeContent@app.finance': {
                        templateUrl: 'views/finance/appropdetail.html',
                        controller  : 'AppropriationController'
                    }
                },
                permdata: {
                    'auth_access': true,
                    'ui_access': ['ui_fiscal']
                }
            })
            .state('app.finance.payments.paydetail', {
                url:'/paydetail/:expense_payment_guid',
                views: {
                    'financeContent@app.finance': {
                        templateUrl: 'views/finance/paydetail.html',
                        controller  : 'PaymentController'
                    }
                },
                permdata: {
                    'auth_access': true,
                    'ui_access': ['ui_fiscal']
                }
            })

            .state('app.finance.reappropriations.reappropdetails', {
                url:'/reappropdetails/:reappropriation_guid',
                views: {
                    'financeContent@app.finance': {
                        templateUrl: 'views/finance/reappropdetails.html',
                        controller  : 'ReappropController'
                    }
                },
                permdata: {
                    'auth_access': true,
                    'ui_access': ['ui_fiscal']
                }
            })
            .state('app.finance.fundreapdetails', {
                url:'/fundreapdetails/:fund_guid',
                views: {
                    'financeContent@app.finance': {
                        templateUrl: 'views/finance/fundreapdetails.html',
                        controller  : 'FundsController'
                    }
                },
                permdata: {
                    'auth_access': true,
                    'ui_access': ['ui_fiscal']
                }
            })
            .state('app.finance.expenses.expensedetail',{
                url:'/expensedetail/:expense_guid',
                views: {
                    'financeContent@app.finance':{
                        templateUrl:'views/finance/expensedetail.html',
                        controller  : 'ExpenseController'
                    }
                },
                permdata: {
                    'auth_access': true,
                    'ui_access': ['ui_fiscal']
                }
            })

            .state('app.finance.payments.paymentdetail',{
                url:'/paymentdetail/:expense_payment_guid',
                views: {
                    'financeContent@app.finance':{
                        templateUrl:'views/finance/paymentdetail.html',
                        controller  : 'PaymentController'
                    }
                },
                permdata: {
                    'auth_access': true,
                    'ui_access': ['ui_fiscal']
                }
            })
            //route for public farm portal
             .state('app.publicfarm', {
                url:'publicfarm/:farm_id',
                views: {
                    'content@': {
                        templateUrl: 'views/publicfarm/publicfarm.html',
                        controller  : 'publicfarmctrl'
                    },
                    'publicfarmContent@app.publicfarm': {
                        templateUrl: 'views/publicfarm/farminfo.html',
                        controller  : 'PublicFarmInfoController',
                        controllerAs: 'PFICtrl'

                    }
                },
                permdata: {
                    'auth_access': false,
                    'ui_access': []
                }
            })
            .state('app.publicfarm.information', {
                url:'/information',
                views: {
                    'publicfarmContent@app.publicfarm': {
                        templateUrl: 'views/publicfarm/farminfo.html',
                        controller  : 'PublicFarmInfoController',
                        controllerAs: 'PFICtrl'

                    }
                },
                permdata: {
                    'auth_access': false,
                    'ui_access': ['ui_farmdashboard_information']
                }
            })
            .state('app.publicfarm.documents', {
                url:'/farmdocs',
                views: {
                    'publicfarmContent@app.publicfarm': {
                        templateUrl: 'views/publicfarm/farmdocs.html',
                        controller  : 'PublicFarmDocsController'
                    }
                },
                permdata: {
                    'auth_access': false,
                    'ui_access': ['ui_farmdashboard_documents']
                }
            })


                //route for farm portal
            .state('app.farm', {
                url:'farm/:farm_id',
                views: {
                    'content@': {
                        templateUrl: 'views/farm/farm.html',
                        controller  : 'FarmController'
                    },
                    'farmCommands@app.farm': {
                        templateUrl: 'views/farm/commands.html',
                        controller  : 'FarmController'
                    },
                    'farmContent@app.farm': {
                        templateUrl: 'views/farm/information.html',
                        controller  : 'FarmInfoController',
                        controllerAs: 'FICtrl'

                    }
                },
                permdata: {
                    'auth_access': false,
                    'ui_access': []
                }
            })
            .state('app.farm.information', {
                url:'/information',
                views: {
                    'farmContent@app.farm': {
                        templateUrl: 'views/farm/information.html',
                        controller  : 'FarmInfoController',
                        controllerAs: 'FICtrl'

                    }
                },
                permdata: {
                    'auth_access': false,
                    'ui_access': ['ui_farmdashboard_information']
                }
            })
            .state('app.farm.contacts', {
                url:'/contacts',
                views: {
                    'farmContent@app.farm': {
                        templateUrl: 'views/farm/contacts.html',
                        controller  : 'FarmContactsController',
                    }
                },
                permdata: {
                    'auth_access': false,
                    'ui_access': ['ui_farmdashboard_contacts']
                }
            })
            .state('app.farm.applications', {
                url:'/applications',
                views: {
                    'farmContent@app.farm': {
                        templateUrl: 'views/farm/applications.html',
                        controller  : 'FarmApplicationsCtrl',
                        controllerAs : 'FAC'
                    }
                },
                permdata: {
                    'auth_access': false,
                    'ui_access': ['ui_farmdashboard_applications']
                }
            })
            .state('app.farm.todoitems', {
                url:'/todoitems',
                views: {
                    'farmContent@app.farm': {
                        templateUrl: 'views/farm/farmtodo.html',
                        controller  : 'FarmToDoController',
                    }
                },
                permdata: {
                    'auth_access': false,
                    'ui_access': ['ui_farmdashboard_todo']
                }
            })
             .state('app.farm.edittodoitem', {
                 url:'/edittodoitem/:itemID',
                views: {
                    'farmContent@app.farm': {
                        templateUrl: 'views/farm/farmtodo.html',
                        controller  : 'FarmToDoController'
                    }
                },
                 permdata: {
                    'auth_access': false,
                    'ui_access': ['ui_farmdashboard_todo']
                }
            })
            .state('app.farm.notes_documents', {
                url:'/notes_documents',
                views: {
                    'farmContent@app.farm': {
                        templateUrl: 'views/farm/notes_documents.html',
                        controller  : 'FarmNotesAndDocumentsCtrl',
                        controllerAs : 'FNADC'
                    }
                },
                permdata: {
                    'auth_access': false,
                    'ui_access': ['']
                }
            })
            .state('app.farm.documents', {
                url:'/farmdocs',
                views: {
                    'farmContent@app.farm': {
                        templateUrl: 'views/farm/farmdocs.html',
                        controller  : 'FarmDocsController'
                    }
                },
                permdata: {
                    'auth_access': false,
                    'ui_access': ['ui_farmdashboard_documents']
                }
            })
            .state('app.farm.Scores', {
                url:'/Scores',
                views: {
                    'farmContent@app.farm': {
                        templateUrl: 'views/farm/farmScores.html',
                        controller  : 'FarmScoreController'
                    }
                },
                permdata: {
                    'auth_access': false,
                    'ui_access': ['ui_farmdashboard_scores']
                }
            })
            .state('app.farm.Expenses', {
                url:'/Expenses',
                views: {
                    'farmContent@app.farm': {
                        templateUrl: 'views/farm/Expenses.html',
                        controller  : 'FarmExpenseController'
                    }
                },
                permdata: {
                    'auth_access': false,
                    'ui_access': ['ui_farmdashboard_expenses']
                }
            })

            .state('app.farm.ExpensesDetails', {
                url:'/expense_details/:expense_guid',
                views: {
                    'farmContent@app.farm': {
                        templateUrl: 'views/farm/expensedetails.html',
                        controller  : 'FarmExpenseController'
                    }
                },
                permdata: {
                    'auth_access': false,
                    'ui_access': ['ui_farmdashboard_expenses']
                }
            })

            .state('app.farm.map', {
                url:'/map',
                views: {
                    'farmContent@app.farm': {
                        templateUrl: 'views/farm/map.html',
                        controller  : 'FarmMapController',
                        controllerAs : 'farmMapCtrl'
                    }
                },
                permdata: {
                    'auth_access': false,
                    'ui_access': []
                }
            })
             //route for application portal
            .state('app.application', {
                url:'application/:ID',
                //params:{'GUID':'d3e48b84-af47-4767-b2b2-bbed7ee1bde3'},
                 redirectTo: 'app.application.appinfo',
                views: {
                    'content@': {
                        templateUrl: 'views/application/application.html',
                        controller  : 'AppInfoController'
                    },
                    'applicationContent@app.application': {
                        templateUrl: 'views/application/appinfo.html',
                        controller  : 'AppInfoController'
                    },
                    'applicationCommands@app.application': {
                        templateUrl: 'views/application/commands.html'
                    }
                },
                permdata: {

                    'auth_access': true,
                    'ui_access': ['ui_appdashboard']

                }
            })
            .state('app.application.appinfo', {
                url:'/appinfo',
                views: {
                    'applicationContent@app.application': {
                        templateUrl: 'views/application/appinfo.html',
                        controller  : 'AppInfoController'
                    }
                },
                permdata: {

                    'auth_access': true,
                    'ui_access': ['ui_appdashboard']

                }
            })
            .state('app.application.viewedit', {
                url:'/questionnaire',
                views: {
                    'applicationContent@app.application': {
                        templateUrl: 'views/application/viewedit.html',
                        controller  : 'AppDashboardController'
                    }
                },
                permdata: {

                    'auth_access': true,
                    'ui_access': ['ui_appdashboard']

                }
            })
            .state('app.application.contacts', {
                 url:'/contacts',
                views: {
                    'applicationContent@app.application': {
                        templateUrl: 'views/application/appContacts.html',
                        controller  : 'AppContactsController'
                    }
                },
                 permdata: {

                    'auth_access': false,
                    'ui_access': ['ui_appdashboard']

                }
            })
            .state('app.application.apptasks', {
                url:'/apptasks',
                views: {
                    'applicationContent@app.application': {
                        templateUrl: 'views/application/apptasks.html',
                        controller  : 'AppTasksController'
                    }
                },
                permdata: {
                    'auth_access': true,
                    'ui_access': ['ui_appdashboard']

                }
            })
            .state('app.application.todoitems', {
                 url:'/todoitems',
                views: {
                    'applicationContent@app.application': {
                        templateUrl: 'views/application/todoitems.html',
                        controller  : 'AppToDoItemsController'
                    }
                },
                permdata: {
                    'auth_access': false,
                    'ui_access': ['ui_appdashboard_todo']
                }
            })
             .state('app.application.edittodoitem', {
                 url:'/edittodoitem/:itemID',
                views: {
                    'applicationContent@app.application': {
                        templateUrl: 'views/application/todoitems.html',
                        controller  : 'AppToDoItemsController'
                    }
                },
                 permdata: {
                    'auth_access': false,
                    'ui_access': ['ui_appdashboard_todo']
                }
            })
            .state('app.application.appnotes', {
                 url:'/notes',
                views: {
                    'applicationContent@app.application': {
                        templateUrl: 'views/application/appnotes.html',
                        controller  : 'AppNotesController',
                        controllerAs : 'appNtndDc'

                    }
                },
                permdata: {
                    'auth_access': true,
                    'ui_access': ['ui_appdashboard']
                }
            })
            .state('app.application.appdocs', {
                 url:'/documents',
                views: {
                    'applicationContent@app.application': {
                        templateUrl: 'views/application/appdocs.html',
                        controller  : 'AppDocsController'
                    }
                },
                permdata: {
                    'auth_access': true,
                    'ui_access': ['ui_appdashboard']

                }
            })
            .state('app.application.map', {
                 url:'/map',
                views: {
                    'applicationContent@app.application': {
                        templateUrl: 'views/application/map.html',
                        controller  : 'AppMapController',
                        controllerAs: 'appMapCtrl'
                    }
                },
                permdata: {
                    'auth_access': true,
                    'ui_access': ['ui_appdashboard']

                }
            })
            .state('app.application.scores', {
                 url:'/scores',
                views: {
                    'applicationContent@app.application': {
                        templateUrl: 'views/application/appScores.html',
                        controller  : 'AppScoreController'
                    }
                },
                permdata: {

                    'auth_access': true,
                    'ui_access': ['ui_appdashboard']

                }
            })
             .state('app.application.expenses', {
                 url:'/expenses',
                views: {
                    'applicationContent@app.application': {
                        templateUrl: 'views/application/appexpenses.html',
                        controller  : 'AppExpenseController'
                    }
                },
                 permdata: {

                     'auth_access': true,
                     'ui_access': ['ui_appdashboard']

                 }
            })

            .state('app.application.expensedetails', {
                 url:'/expense_details/:expense_guid',
                views: {
                    'applicationContent@app.application': {
                        templateUrl: 'views/application/expensedetails.html',
                        controller  : 'AppExpenseController'
                    }
                },
                permdata: {
                    'auth_access': true,
                    'ui_access': ['ui_appdashboard']

                }
            })

            //dashboard here
            .state('app.mydashboard', {
                url:'mydashboard',
                redirectTo: 'app.mydashboard.myaccount',
                views: {
                    'content@': {
                        templateUrl: 'views/mydashboard/mydashboard.html',
//                        controller  : 'MyDashboardController'
                    },
                    'dashboardContent@app.mydashboard':{
                        templateUrl: 'views/mydashboard/myaccount.html',
                         controller  : 'MyAccountController'
                    }
                },
                permdata: {
                    'auth_access': true,
                    'ui_access': ['ui_mydashboard']
                }
            })
            .state('app.mydashboard.myaccount', {
                url:'/myaccount',
                views: {
                    'dashboardContent@app.mydashboard': {
                        templateUrl: 'views/mydashboard/myaccount.html',
                        controller  : 'MyAccountController'

                    }
                },
                permdata: {
                    'auth_access': true,
                    'ui_access': ['ui_mydashboard']
                }
            })
            .state('app.mydashboard.notifications', {
                url:'/notifications',
                views: {
                    'dashboardContent@app.mydashboard': {
                        templateUrl: 'views/mydashboard/notifications.html',
                         controller  : 'MyNotificationsController'
                    }
                },
                permdata: {
                    'auth_access': true,
                    'ui_access': ['ui_mydashboard']
                }
            })
            .state('app.mydashboard.todo', {
                url:'/todo',
                views: {
                    'dashboardContent@app.mydashboard': {
                        templateUrl: 'views/mydashboard/todo.html',
                        controller  : 'MyToDoController'
                    }
                },
                permdata: {
                    'auth_access': true,
                    'ui_access': ['ui_mydashboard']
                }
            })
            .state('app.mydashboard.currentapplication', {
                url:'/currentapplication',
                views: {
                    'dashboardContent@app.mydashboard': {
                        templateUrl: 'views/mydashboard/myapplications.html',
                         controller  : 'MyApplicationsController'
                    }
                },
                permdata: {
                    'auth_access': true,
                    'ui_access': ['ui_mydashboard']
                }
            })

            .state('app.planning', {
                url:'planning',
                views: {
                    'content@': {
                        templateUrl: 'views/mainpages/planning.html'
                    }
                },
                permdata: {
                    'auth_access': false,
                    'ui_access': []
                }
            })
            .state('app.acquisitions', {
                url:'acquisitions',
                views: {
                    'content@': {
                        templateUrl: 'views/mainpages/acquisitions.html'
                    }
                },
                permdata: {
                    'auth_access': false,
                    'ui_access': []
                }
            })
            .state('app.stewardship', {
                url:'stewardship',
                views: {
                    'content@': {
                        templateUrl: 'views/mainpages/stewardship.html'
                    }
                },
                permdata: {
                    'auth_access': false,
                    'ui_access': []
                }
            })

            .state('app.righttofarm', {
                url:'righttofarm',
                views: {
                    'content@': {
                        templateUrl: 'views/mainpages/righttofarm.html'
                        //controller  : ''
                    }
                },
                permdata: {
                    'auth_access': false,
                    'ui_access': []
                }
            })
            .state('app.agmediation', {
                url:'agmediation',
                views: {
                    'content@': {
                        templateUrl: 'views/mainpages/agmediation.html'
                        //controller  : ''
                    }
                },
                permdata: {
                    'auth_access': false,
                    'ui_access': []
                }
            })
            .state('app.soilandwater', {
                url:'soilandwater',
                views: {
                    'content@': {
                        templateUrl: 'views/mainpages/soilandwater.html'
                        //controller  : ''
                    }
                },
                permdata: {
                    'auth_access': false,
                    'ui_access': []
                }
            })
            .state('app.reports', {
                url:'reports',

                views: {
                    'content@': {
                        templateUrl: 'views/mainpages/reports.html'
                    }
                },
                permdata: {
                    'auth_access': false,
                    'ui_access': []
                }
            })

            .state('app.manageusers', {
                url:'manageusers',
                views: {
                    'content@': {
                        templateUrl : 'views/authadmin/useradmin.html',
                        controller  : 'UserAdminController'
                    }
                },
                permdata: {
                    'auth_access': true,
                    'ui_access': ['ui_sysadmin', 'ui_useradmin']
                }
            })
            .state('app.manageresources', {
                url:'manageresources',
                views: {
                    'content@': {
                        templateUrl : 'views/authadmin/resourceadmin.html'
                    }
                },
                permdata: {
                    'auth_access': true,
                    'ui_access': ['ui_sysadmin']
                }

            })
            .state('app.manageuicomponents', {
                url:'manageuicomponents',
                views: {
                    'content@': {
                        templateUrl : 'views/authadmin/uiadmin.html'
                    }
                },
                permdata : {
                    'auth_access': true,
                    'ui_access': ['ui_sysadmin']
                }
            })

            // route for the Admin Tasklist Management
            .state('app.todolistmanager', {
                url:'todomanager',
                views: {
                    'content@': {
                        templateUrl : 'views/todolistadmin/todomanager.html'
                        //controller  : 'UserAdminController'
                    }
                },
                permdata : {
                    'auth_access': true,
                    'ui_access': ['ui_appadmin', 'ui_sysadmin','ui_todolistadmin']
                }
            })

            // route for the pre-register page
            .state('app.preregister', {
                url:'preregister',
                views: {
                    'header@': {
                        templateUrl : 'views/header_no_menu.html'
                    },
                    'content@': {
                        templateUrl: 'views/authadmin/preregister.html',
                        controller  : 'PreregisterController'
                    }
                },
                permdata: {
                    'auth_access': false,
                    'ui_access': []
                }
            })

            .state('app.register', {
                url:'register',
                views: {
                    'header@': {
                        templateUrl: 'views/header_no_menu.html'
                    },
                    'content@': {
                        templateUrl: 'views/authadmin/register.html',
                        controller  : 'RegisterController'
                    }
                },
                permdata: {
                    'auth_access': false,
                    'ui_access': []
                }
            })
            .state('app.autherror', {
            url:'autherror',
            views: {
                'content@': {
                    templateUrl: 'views/authadmin/autherror.html'
                }
                },
            permdata: {
                'auth_access': false,
                'ui_access': []
            }

            });

        $urlRouterProvider.otherwise('/');

        markedProvider.setOptions({
            gfm: true,
            tables: true
            //highlight: function (code) {
            //    return prettyPrintOne(code);
            //}
        });
    }])

.run(function(editableOptions) {
  editableOptions.theme = 'bs3';
});