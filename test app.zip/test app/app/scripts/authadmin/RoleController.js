(function () {
    'use strict';
}());

angular.module('agSADCeFarms')
    .controller('RoleController', ['$scope', '$log', '$state', 'role_filterFilter', 'get_selectedFilter',
        'rolesFactory', 'partnersFactory', 'tiersFactory', 'groupsFactory', 'subgroupsFactory',
        'countiesFactory', 'municipalitiesFactory', 'SharedRoleService', 'modalMessageService',
        function($scope, $log, $state, role_filterFilter, get_selectedFilter,
        rolesFactory, partnersFactory, tiersFactory, groupsFactory, subgroupsFactory,
        countiesFactory, municipalitiesFactory, SharedRoleService, modalMessageService) {

            var contName = 'RoleController';
            //$log.debug("--------------Running RoleController");
            //$log.debug("IN RoleController, manageThisResource:", $scope.manageThisResource);

            var initRoleSelectors = function() {
                $scope.roleSelection = {
                    rolesFrom: [],
                    rolesTo: []
                };
                $scope.roleFilter = {
                    tier: '',
                    group: '',
                    subgroup: '',
                    partner: '',
                    county: '',
                    municipality: ''
                };
            };
            //****************** Watch Section **************************************
            $scope.$watchCollection('role_filter', function() {
                $log.debug(">>>> FILTER CHANGED:", $scope.role_filter);
            });

            // When the selected roles in rolesTo changes, update the service
            $scope.$watchCollection('roleSelection.rolesTo', function() {
                // Start with list of selected Roles and use that to get the role names
                $scope.selectedRoles = get_selectedFilter($scope.roles);
                var selectedRoleNames = [];
                angular.forEach($scope.roleSelection.rolesTo, function(role_guid){
                    for (var i = 0; i < $scope.selectedRoles.length; i++) {
                        if ($scope.selectedRoles[i].auth_role_guid ==  role_guid ) {
                            selectedRoleNames.push($scope.selectedRoles[i].auth_role_name);
                        }
                    }
                });
                SharedRoleService.selectedRoleNames = selectedRoleNames;
                //$log.debug("+++selected Role Names:",selectedRoleNames);
                //$log.debug("+++RoleTo Changed", $scope.roleSelection.rolesTo);
                SharedRoleService.selectedRoleGuids = $scope.roleSelection.rolesTo;
            });

            // Check for changes in selected roles to init the assigned roles box
            $scope.$watchCollection(function(){
                return SharedRoleService.initialRoleGuids;
            }, function() {
                //$log.debug("+++Init roles changed in role controller", SharedRoleService.initialRoleGuids);
                $scope.roleSelection.rolesFrom = SharedRoleService.initialRoleGuids;
                $scope.roleSelection.rolesTo = [];
                setAllRolesUnselectedStatus();
                setRoleSelectedStatus();
                updateSharedRoleServiceWithSelectedRoles();

            });

            var updateSharedRoleServiceWithSelectedRoles = function() {
                SharedRoleService.allSelectedRoleGuids = [];
                angular.forEach($scope.roles, function(role){
                    if ( role.selected ) {
                        //$log.debug("+++Role", role.auth_role_guid, "is selected");
                        SharedRoleService.allSelectedRoleGuids.push(role.auth_role_guid);
                    }
                });
            };

            // ******************** GET ROLE RELATED STUFF *************************************
            $scope.getRoleRelatedStuff = function() {

                rolesFactory.getRoles().query()
                    .$promise.then(
                    function(response){
                        $scope.roles = response;
                        //$log.debug("ROLES:", $scope.roles);
                    },
                    function(response) {
                        if ( response.status == 403 ) {
                            $state.go('app.autherror');
                            modalMessageService.showMessage( "Error:", "You do not have permission to access this page.");
                        }
                        $log.debug("Error: "+response.status + " " + response.statusText);
                    }
                );
                partnersFactory.getPartners().query()
                    .$promise.then(
                    function(response){
                        $scope.rolePartners = response;
                        //$log.debug("ROLE PARTNERS:", $scope.rolePartners);
                    },
                    function(response) {
                        if ( response.status == 403 ) {
                            $state.go('app.autherror');
                            modalMessageService.showMessage( "Error:", "You do not have permission to access this page.");
                        }
                        $log.debug("Error: "+response.status + " " + response.statusText);
                    }
                );
                tiersFactory.getTiers().query()
                    .$promise.then(
                    function(response){
                        $scope.roleTiers = response;
                        //$log.debug("ROLE TIERS:", $scope.roleTiers);
                    },
                    function(response) {
                        if ( response.status == 403 ) {
                            $state.go('app.autherror');
                            modalMessageService.showMessage( "Error:", "You do not have permission to access this page.");
                        }
                        $log.debug("Error: "+response.status + " " + response.statusText);
                    }
                );
                groupsFactory.getGroups().query()
                    .$promise.then(
                    function(response){
                        $scope.roleGroups = response;
                        //$log.debug("ROLE GROUPS:", $scope.roleGroups);
                    },
                    function(response) {
                        if ( response.status == 403 ) {
                            $state.go('app.autherror');
                            modalMessageService.showMessage( "Error:", "You do not have permission to access this page.");
                        }
                        $log.debug("Error: "+response.status + " " + response.statusText);
                    }
                );
                subgroupsFactory.getSubgroups().query()
                    .$promise.then(
                    function(response){
                        $scope.roleSubgroups = response;
                        //$log.debug("ROLE SUBGROUPS:", $scope.roleSubgroups);
                    },
                    function(response) {
                        if ( response.status == 403 ) {
                            $state.go('app.autherror');
                            modalMessageService.showMessage( "Error:", "You do not have permission to access this page.");
                        }
                        $log.debug("Error: "+response.status + " " + response.statusText);
                    }
                );
                countiesFactory.getCounties().query()
                    .$promise.then(
                    function(response){
                        $scope.roleCounties = response;
                        //$log.debug("ROLE COUNTIES:", $scope.roleCounties);
                    },
                    function(response) {
                        if ( response.status == 403 ) {
                            $state.go('app.autherror');
                            modalMessageService.showMessage( "Error:", "You do not have permission to access this page.");
                        }
                        $log.debug("Error: "+response.status + " " + response.statusText);
                    }
                );
                municipalitiesFactory.getMunicipalities().query()
                    .$promise.then(
                    function(response){
                        $scope.roleMunicipalities= response;
                        //$log.debug("ROLE MUNIS:", $scope.roleMunicipalities);
                    },
                    function(response) {
                        if ( response.status == 403 ) {
                            $state.go('app.autherror');
                            modalMessageService.showMessage( "Error:", "You do not have permission to access this page.");
                        }
                        $log.debug("Error: "+response.status + " " + response.statusText);
                    }
                );

            };

            // For displaying loading icon while data is being fetched.
            $scope.loading_data = true;
            // To display role filter button
            $scope.role_filter_active = false;

            $scope.clearRoleFilter = function(){
                $scope.role_filter_active = false;
                // TODO: Restore data to unfiltered by role!!!!
                $scope.role_filter = {'filter_value': [] };
            };
            // Initialize the filterer
            $scope.role_filter = {
                'filter_value': []
            };


            // ********************* Supporting functions ***********************************

            // Clear filter functions
            $scope.clearPartnerFilter = function(){
                $scope.roleFilter.partner = '';
            };
            $scope.clearCountyFilter = function(){
                $scope.roleFilter.county = '';
            };
            $scope.clearMunicipalityFilter = function(){
                $scope.roleFilter.municipality= '';
            };
            $scope.clearTierFilter = function(){
                $scope.roleFilter.tier = '';
            };
            $scope.clearGroupFilter = function(){
                $scope.roleFilter.group = '';
            };
            $scope.clearSubgroupFilter = function(){
                $scope.roleFilter.subgroup = '';
            };

            // For each role, check to see if it's guid is in the selected 'From' roles.  If it is,
            // change the selected value to true so it gets filtered out
            var setRoleSelectedStatus = function() {
                angular.forEach($scope.roles, function(role){
                    if ( $scope.roleSelection.rolesFrom.indexOf(role.auth_role_guid) != -1 ) {
                        role.selected = true;
                    }
                });
            };
            // For each role, check to see if it's guid is in the selected 'To' roles.  If it is,
            // change the selected value to false so it gets filtered out
            var setRoleUnselectedStatus = function() {
                angular.forEach($scope.roles, function(role){
                    if ( $scope.roleSelection.rolesTo.indexOf(role.auth_role_guid) != -1 ) {
                        role.selected = false;
                    }
                });
                //$log.debug("ROLES AFTER SETTING STATUS TO TRUE:", $scope.roles);
            };

            // Change selected status to true for all roles in the 'From' roles
            var setAllRolesSelectedStatus = function() {
                angular.forEach($scope.filteredRolesFrom, function(role){
                    role.selected = true;
                });

            };
            // Change selected status to true for all roles in the 'From' roles
            var setAllRolesUnselectedStatus = function() {
                angular.forEach($scope.roles, function(role){
                    role.selected = false;
                });

            };

            // ****************************** UI Functions and values**********************************

            //// prevent permissions from being changed
            //$scope.permChangeDisabled = true;
            //// edit permission button disabled
            ////$scope.disableEditButton = true;

            $scope.clearFilter = function(){
                $log.debug("CLEARING FILTER");
                initRoleSelectors();
            };

            $scope.selectLimited = function() {
                if ( $scope.roleSelection.rolesFrom.length === 0 ) {
                    $log.debug("NO ROLES SELECTED");
                } else {
                    $log.debug("MOVING ROLES:", $scope.roleSelection.rolesFrom);
                    setRoleSelectedStatus();
                    updateSharedRoleServiceWithSelectedRoles();
                }
            };

            $scope.selectAll = function() {
                // First filter out so not all roles are selected.
                $scope.filteredRolesFrom = role_filterFilter( $scope.roles, $scope.roleFilter);
                $log.debug("ALL SELECTED ROLES TO MOVE:", $scope.filteredRolesFrom);
                setAllRolesSelectedStatus();
                updateSharedRoleServiceWithSelectedRoles();
            };

            $scope.unselectLimited = function() {
                if ( $scope.roleSelection.rolesTo.length === 0 ) {
                    $log.debug("NO ROLES SELECTED");
                } else {
                    $log.debug("MOVING ROLES:", $scope.roleSelection.rolesTo);
                    setRoleUnselectedStatus();
                    updateSharedRoleServiceWithSelectedRoles();
                }
            };

            $scope.unselectAll = function() {
                setAllRolesUnselectedStatus();
                updateSharedRoleServiceWithSelectedRoles();
            };

            // *****************************Initial Load of Data ******************************
            $scope.getRoleRelatedStuff();
            initRoleSelectors();
        }])
;
