(function () {
    'use strict';
}());

angular.module('agSADCeFarms')
    .controller('URLRolePermissionModalController', ['$scope', '$log', '$uibModalInstance', 'urls_and_perms',
        function($scope, $log, $uibModalInstance, urls_and_perms ) {

            $scope.today = new Date();

            $scope.urls_and_perms = urls_and_perms;

            $scope.Close = function () {
                $uibModalInstance.dismiss();
            };

            $scope.print = function () {
                window.print();
            };
        }]);

