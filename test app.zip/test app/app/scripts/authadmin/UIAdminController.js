(function () {
    'use strict';
}());

angular.module('agSADCeFarms')
    .controller('UIAdminController', ['$scope', '$log', '$state', '$timeout', '$uibModal', '$sce',
            'userFactory', 'uiComponentFactory', 'uiComponentPermissionFactory', 'allUiPermissionFactory',
            'allRoleAndUiPermissionFactory', 'statusFactory',
            'orgtypeFactory', 'rolesFactory', 'partnersFactory', 'tiersFactory', 'groupsFactory', 'subgroupsFactory',
            'countiesFactory', 'municipalitiesFactory', 'userSkeleton', 'uiGridConstants', 'modalService',
            'modalMessageService', 'agSupportEmail', 'SharedRoleService',
        function($scope, $log, $state, $timeout, $uibModal, $sce,
            userFactory, uiComponentFactory, uiComponentPermissionFactory, allUiPermissionFactory,
            allRoleAndUiPermissionFactory, statusFactory,
            orgtypeFactory, rolesFactory, partnersFactory, tiersFactory, groupsFactory, subgroupsFactory,
            countiesFactory, municipalitiesFactory, userSkeleton, uiGridConstants, modalService,
            modalMessageService, agSupportEmail, SharedRoleService ) {

            var error_message = '';

            $scope.UIComponent = { 'UIComponent_name': '', 'UIComponent_desc': ''};
            $scope.message = "";
            $scope.loading_data = true;

            $log.debug("Inside UIAdminController");
            // **************************************************************************************************
            //**************************** WATCHED VARIABLE FUNCTIONS *******************************************
            // **************************************************************************************************

            // Check for changes in selected roles to init the assigned roles box
            $scope.$watchCollection(function(){
                return SharedRoleService.selectedRoleGuids;
            }, function() {
                $scope.disableEditButton = true;
                $scope.permChangeDisabled = true;
                $log.debug("+++Selected Role Change in UIComponentAdminController", SharedRoleService.selectedRoleGuids);
                if ( SharedRoleService.selectedRoleGuids.length > 1 ) {
                    $scope.selectedRoleMessage = "Only one Assigned Role should be selected in order to edit permissions.";
                } else if ( SharedRoleService.selectedRoleGuids.length == 0 ) {
                    $scope.selectedRoleMessage = "";
                } else {
                    // Only one selected so get the permissions
                    $scope.selectedRoleMessage = "";
                    $scope.disableEditButton = false;
                    setUIComponentPermsInUi();
                }
            });
            // Check for changes as roles are added to selected roles from all roles and add them to roles
            $scope.$watchCollection(function(){
                return SharedRoleService.allSelectedRoleGuids;
            }, function() {
                var new_roles = [];
                // Create new array of roles based the selected roles.  If a selected
                // role is already in $scope.roles move it to the new array
                angular.forEach( SharedRoleService.allSelectedRoleGuids, function(new_role_guid) {
                    // Search existing $scope.roles and move over any existing roles
                    existingRoleIndex = getGuidIndexInExistingRoles(new_role_guid);
                    if (existingRoleIndex != -1){
                        new_roles.push($scope.roles[existingRoleIndex]);
                    } else {
                        new_roles.push({'role_guid': new_role_guid});
                    }
                });
                // Disable edit permission button and permissions
                //$scope.disableEditButton = true;
                //$scope.permChangeDisabled = true;
                $log.debug("+-+-+New Roles and Permissions:", new_roles);
                $scope.roles = new_roles;
            });

            var getGuidIndexInExistingRoles = function(role_guid) {
                for ( var i = 0; i < $scope.roles.length; ++i) {
                    if ( role_guid == $scope.roles[i].role_guid) {
                        return i;
                    }
                }
                return -1;
            };

            // Set the permissions in the UI for editing
            var setUIComponentPermsInUi = function() {
                angular.forEach( $scope.roles, function(role_perm) {
                    if ( role_perm.role_guid == SharedRoleService.selectedRoleGuids[0] ){
                        $log.debug("Matched selected role with role permission response");
                        angular.forEach( role_perm.permission, function(permission) {
                            $log.debug("Permission for Role GUID", role_perm.role_guid,permission);
                            // Set the permission in the UI
                            $scope.chkbox_perms[permission] = true;
                        });
                    }
                });
                $log.debug("CURRENT STATUS OF permission checkboxes:", $scope.chkbox_perms);
            };

            // **************************************************************************************************
            //********************************* UI Functions and variables **************************************
            // **************************************************************************************************

            $scope.manageUIComponent = false;
            $scope.modUIComponent = false;
            $scope.showmessage = false;
            $scope.disableEditButton = true;
            $scope.permChangeDisabled = true;
            $scope.selectedRoleMessage = '';

            $scope.showAllUiRolesAndPermissions = function() {
                $scope.loading_data = true;
                allUiPermissionFactory.getAllUiComponentPermissions().query()
                    .$promise.then(
                    function(response){
                        $scope.loading_data = false;
                        //$log.debug("RESPONSE:",response);
                        $scope.ui_components_and_perms = response;
                        var modalInstance = $uibModal.open({
                            templateUrl: 'templates/authadmin/allUIPermissions.html',
                            controller: 'UIPermissionModalController',
                            backdrop: 'static',
                            size: 'lg',
                            resolve: {
                                ui_components_and_perms: function () {
                                    return $scope.ui_components_and_perms;
                                }
                            }
                        });
                        modalInstance.result.then(function (modalResponse) {
                            $log.debug("RESOURCE PERMISSION FILTER MODAL RESPONSE:", modalResponse);
                        }, function () {
                            $log.debug("CANCELED ROLE FILTER MODAL:");
                        });
                    },
                    function(response) {
                        $scope.loading_data = false;
                        if ( response.status == 403 ) {
                            $state.go('app.autherror');
                            modalMessageService.showMessage( "Error:", "You do not have permission to access this page.");
                        } else {
                            // If there is an error getting resources from database,
                            // this will have an error as well.  If so, put the message in the error modal.
                            $log.debug("Error getting resource permissions");
                            $log.debug("Error: "+response.status + " " + response.statusText);
                            modalMessageService.showMessage( "Error:", response.status + " " +
                                response.statusText + '. Please contact ' + agSupportEmail);
                        }
                    }
                );

            };

            $scope.showAllRoleAndUiPermissions = function() {
                $scope.loading_data = true;
                allRoleAndUiPermissionFactory.getAllRoleAndUiComponentPermissions().query()
                    .$promise.then(
                    function(response){
                        $scope.loading_data = false;
                        $log.debug("RESPONSE:",response);
                        $scope.ui_roles_and_components = response;
                        var modalInstance = $uibModal.open({
                            templateUrl: 'templates/authadmin/allRoleAndUIPermissions.html',
                            controller: 'RoleUIPermissionModalController',
                            backdrop: 'static',
                            size: 'lg',
                            resolve: {
                                ui_roles_and_components: function () {
                                    return $scope.ui_roles_and_components;
                                }
                            }
                        });
                        modalInstance.result.then(function (modalResponse) {
                            $log.debug("RESOURCE PERMISSION FILTER MODAL RESPONSE:", modalResponse);
                        }, function () {
                            $log.debug("CANCELED ROLE FILTER MODAL:");
                        });
                    },
                    function(response) {
                        $scope.loading_data = false;
                        if ( response.status == 403 ) {
                            $state.go('app.autherror');
                            modalMessageService.showMessage( "Error:", "You do not have permission to access this page.");
                        } else {
                            // If there is an error getting resources from database,
                            // this will have an error as well.  If so, put the message in the error modal.
                            $log.debug("Error getting resource permissions");
                            $log.debug("Error: "+response.status + " " + response.statusText);
                            modalMessageService.showMessage( "Error:", response.status + " " +
                                response.statusText + '. Please contact ' + agSupportEmail);
                        }
                    }
                );

            };

            $scope.manageUIComponentPermissions = function() {
                var selectedCount = $scope.gridApiUIComponent.selection.getSelectedCount();
                $log.debug("SELECTED COUNT:", selectedCount);
                if (selectedCount == 0) {
                    $scope.message = 'No UI Component was selected. Please select one.';
                } else {
                    var selectedRows = $scope.gridApiUIComponent.selection.getSelectedRows();
                    $scope.manageThisUIComponent = selectedRows[0].auth_ui_component_name;
                    $log.debug("Requesting permissions associated with UIComponent", selectedRows[0].auth_ui_component_guid);
                    uiComponentPermissionFactory.doUIComponents().get({auth_ui_component_guid:selectedRows[0].auth_ui_component_guid})
                        .$promise.then(
                        function(response){
                            $log.debug("RESPONSE FOR UIComponent PERMISSION:",response);
                            $scope.roles = response.roles;
                            $scope.currently_managed_UIComponent = response.auth_ui_component_guid;
                            var init_role_guids = [];
                            angular.forEach( $scope.roles, function(role) {
                                init_role_guids.push(role.role_guid);
                            });
                            $log.debug("+++SETTING VALUE FOR ROLE CONTROLLER:", init_role_guids);
                            // First clear them out, then reset them.
                            SharedRoleService.initialRoleGuids = init_role_guids;
                        },
                        function(response) {
                            if ( response.status == 403 ) {
                                $state.go('app.autherror');
                                modalMessageService.showMessage( "Error:", "You do not have permission to access this page.");
                            } else {
                                $log.debug("ERROR RESPONSE:", response);
                                // If there is an error getting UIComponents from datbase,
                                // this will have an error as well.  If so, put the message in the error modal.
                                $log.debug("Error: "+response.status + " " + response.statusText);
                                modalMessageService.showMessage( "Error:", response.status + " " +
                                    response.statusText + '. Please contact ' + agSupportEmail);
                            }
                            // Turn off loading data image
                            $scope.loading_data = false;
                        }
                    );
                    $scope.manageUIComponent = true;
                }
                $scope.showmessage = true;

            };


            $scope.addUIComponent = function() {
                $scope.state = 'add';
                $scope.clearUIComponentSelection();
                $scope.message = '';
                $scope.modUIComponent = true;
                $scope.showmessage = true;
                $scope.UIComponent = { 'UIComponent_name': '', 'UIComponent_desc': ''};
                $scope.addOrUpdate = 'Add';
                $scope.doModal();
            };

            $scope.updateUIComponent = function() {
                $scope.state = 'update';
                var selectedCount = $scope.gridApiUIComponent.selection.getSelectedCount();
                $log.debug("SELECTED COUNT:", selectedCount);
                if (selectedCount == 0) {
                    $scope.message = 'No UIComponent was selected. Please select one.';
                } else {
                    $scope.message = '';
                    $scope.modUIComponent = true;
                    var selectedRows = $scope.gridApiUIComponent.selection.getSelectedRows();
                    $log.debug("SELECTED ROWS:", selectedRows);
                    $scope.UIComponent.UIComponent_name = selectedRows[0].auth_ui_component_name;
                    $scope.UIComponent.UIComponent_desc = selectedRows[0].auth_ui_component_desc;
                    $scope.addOrUpdate = 'Update';
                    $scope.doModal();
                }
                $scope.showmessage = true;

            };

            $scope.disableUIComponent = function() {
            };

            $scope.enableUIComponent = function() {
            };

            $scope.submitCommand = function() {
                $scope.message = '';
                $scope.modUIComponent = false;
                $scope.showmessage = false;
                if ( $scope.state == 'add' ) {
                    $scope.doUIComponentAdd();

                } else if ( $scope.state == 'update') {
                    $scope.doUIComponentUpdate();
                }
                $scope.UIComponent.UIComponent_name = '';

            };

            $scope.cancelCommand = function() {
                $scope.message = '';
                $scope.modUIComponent = false;
                $scope.showmessage = false;
                $scope.UIComponent.UIComponent_name = '';

            };

            // Function to handle editing permission on a UIComponent
            $scope.editPermissions = function(){
                // Only allow setting of permissions if one role is selected
                if ( SharedRoleService.selectedRoleGuids.length > 1 ) {
                    $scope.selectedRoleMessage = "Only one Assigned Role should be selected in order to edit permissions.";
                    $scope.permChangeDisabled = true;
                } else if ( SharedRoleService.selectedRoleGuids.length == 0 ) {
                    $scope.selectedRoleMessage = "One Assigned Role should be selected in order to edit permissions.";
                    $scope.permChangeDisabled = true;
                } else {
                    $log.debug("NUMBER OF SELECTED ROLES:", SharedRoleService.selectedRoleGuids.length);
                    $log.debug("Selected Role::", SharedRoleService.selectedRoleGuids);
                    $log.debug("Current Roles and Perms:", $scope.roles);
                    $scope.selectedRoleMessage = 'Edit permisssions for ' + SharedRoleService.selectedRoleNames[0];
                    $scope.permChangeDisabled = false;
                }
            };

            // Saves the updated roles and permissions to database for a UIComponent
            $scope.savePermissions = function(){
                $log.debug("savePermission executed",$scope.currently_managed_UIComponent);
                //Create a new object to hold updated roles and permissions
                $scope.updated_UIComponent_roles = {'auth_ui_component_guid': $scope.currently_managed_UIComponent, 'roles': [] };
                // Loop through each role_and_perm and if permissions are empty, don't include it when saving
                $log.debug("GETTING ROLES FOR UPDATE:", $scope.roles);
                angular.forEach( $scope.roles, function(role) {
                    $log.debug("ADING ROLE:", role);
                    $scope.updated_UIComponent_roles.roles.push(role);
                });
                $log.debug("REQUEST FOR UPDATE", $scope.updated_UIComponent_roles);
                $scope.updateUIComponentPermissions();
            };

            // Cancels the updating of UIComponent permissions
            $scope.cancelUpdatePermissions = function() {
                // Disable edit permission button and permissions
                $scope.disableEditButton = true;
                $scope.permChangeDisabled = true;
                // Clear selected roles
                SharedRoleService.selectedRoleGuids = [];
                SharedRoleService.selectedRoleNames = [];
                SharedRoleService.initialRoleGuids = [];
                $log.debug("cancelUpdatePermissions executed");
                // Hide permission stuff
                $scope.manageThisUIComponent = '';
                $scope.manageUIComponent = false;

            };

            $scope.doModal = function() {
                var modalInstance = $uibModal.open({
                    templateUrl: 'templates/authadmin/uiInput.html',
                    controller: 'UIModalController',
                    backdrop: 'static',
                    size: 'sm',
                    resolve: {
                        ui_component_stuff: function () {
                            return $scope.UIComponent;
                        },
                        addOrUpdate: function () {
                            return $scope.addOrUpdate;
                        }
                    }

                });
                modalInstance.result.then(function (modalResponse) {
                    $log.debug("Got back from UI Modal");
                    $log.debug("UI COMPONENT MODAL RESPONSE:", modalResponse);
                    $scope.UIComponent = modalResponse.user_returned;
                    $log.debug("Returned:", $scope.UIComponent);
                    $log.debug("Returned Component Name:", $scope.UIComponent.UIComponent_name);
                    $log.debug("Returned Component Desc:", $scope.UIComponent.UIComponent_desc);
                    if ( $scope.addOrUpdate === 'Update' ) {
                        $log.debug("Updating the component");
                        $scope.doUIComponentUpdate();
                    } else if ( $scope.addOrUpdate === 'Add' ) {
                        $log.debug("Adding a component");
                        $scope.doUIComponentAdd();
                    } else {
                        $log.debug("Invalid choice for add or update state");
                    }
                }, function () {
                    $log.debug("CANCELED UI Modal:");
                });
                $log.debug("AT END OF doModal");
            };

            // **************************************************************************************************
            // ********************* SUPPORTING FUNCTIONS *******************************************************
            // **************************************************************************************************

            //********************* UPDATE UIComponent *******************************
            $scope.doUIComponentUpdate = function(){
                // Get the value for the url from the form text field
                $log.debug("UPDATED FIELD:", $scope.UIComponent.UIComponent_name);
                var UIComponent_url = { "auth_ui_component_name": $scope.UIComponent.UIComponent_name,
                    "auth_ui_component_desc": $scope.UIComponent.UIComponent_desc  };
                // Get the url guid from the currently selected row
                var auth_ui_component_guid = $scope.gridApiUIComponent.selection.getSelectedRows()[0].auth_ui_component_guid;
                $log.debug("Updating", auth_ui_component_guid, "with", UIComponent_url);
                uiComponentFactory.doUIComponents().update( {auth_ui_component_guid:auth_ui_component_guid}, UIComponent_url )
                    .$promise.then(
                    function(response){
                        $log.debug("RESPONSE FROM doUIComponents", response);
                        // Update field on grid ( only one row can be selected )
                        var selectedRow = $scope.gridApiUIComponent.selection.getSelectedRows()[0];
                        updateGridWithResponse( selectedRow, response);
                        $scope.clearUIComponentSelection();
                        $scope.loading_data = false;
                    },
                    function(response) {
                        if ( response.status == 403 ) {
                            $state.go('app.autherror');
                            modalMessageService.showMessage( "Error:", "You do not have permission to access this page.");
                        } else {
                            $log.debug("AFTER GETTING ERROR FROM UPDATE:", response);
                            $log.debug("Error: "+response.status + " " + response.statusText);
                            $log.debug("ERROR DATA MESSAGE:", response.data.message );
                            if ( response.data.message == 'err-a016') {
                                $log.debug("match with err-a016:", response.data.message );
                                error_message = "A UIComponent with that name already exists.";
                            } else {
                                $log.debug("no match with err-a016:", response.data.message );
                                error_message = "An error occurred updating the UIComponent.";
                            }
                            modalMessageService.showMessage( "Error:", error_message);
                        }
                        $scope.loading_data = false;
                    }
                );
            };

            // ********************** ADD UIComponent **************************************
            $scope.doUIComponentAdd = function() {
                // Save currently selected rows
                $log.debug("Inside doAddUIComponent:");
                var UIComponent_url = { "auth_ui_component_name": $scope.UIComponent.UIComponent_name,
                    "auth_ui_component_desc": $scope.UIComponent.UIComponent_desc  };
                $log.debug("POST BODY TO SEND:", UIComponent_url);
                uiComponentFactory.doUIComponents().save( UIComponent_url )
                    .$promise.then(
                    function(response){
                        $log.debug("RESPONSE FROM doAddUIComponent", response);
                        // Add user to grid
                        $scope.gridUIComponent.data.push(response);
                        refreshGrid();
                    },
                    function(response) {
                        if ( response.status == 403 ) {
                            $state.go('app.autherror');
                            modalMessageService.showMessage( "Error:", "You do not have permission to access this page.");
                        } else {
                            $log.debug("AFTER GETTING ERROR FROM ADD:", response);
                            $log.debug("Error: "+response.status + " " + response.statusText);
                            if ( response.data.message == 'err-a024') {
                                error_message = "A UI Component with that name already exists.";
                            } else {
                                error_message = "An error occurred creating the UIComponent.";
                            }
                            modalMessageService.showMessage( "Error:", error_message);
                        }
                        $scope.loading_data = false;
                    }
                );
            };

            // Take a permission array containing GET, PUT, POST, and/or DELETE and update the permission element
            // of the current role_and_permission object
            var updateUIComponentPermission = function(permArray){
                // Current role being edited is: SharedRoleService.selectedRoleGuids
                // All currently selected roles and perms are stored in:$scope.roles
                angular.forEach( $scope.roles, function(role_and_perm) {
                    if ( role_and_perm.role_guid == SharedRoleService.selectedRoleGuids ) {
                        role_and_perm.permission = permArray;
                    }
                });
            };

            // ******************************* UPDATE PERMISSIONS *********************************************
            $scope.updateUIComponentPermissions = function() {
                $scope.loading_data = true;
                $log.debug("+++MANAGED UI COMPONENT:",$scope.currently_managed_UIComponent);
                $log.debug("+++UPDATED UICOMPONENT ROLES:", $scope.updated_UIComponent_roles);
                uiComponentPermissionFactory.doUIComponents().update({auth_ui_component_guid:$scope.currently_managed_UIComponent}, $scope.updated_UIComponent_roles)
                    .$promise.then(
                    function(response){
                        $log.debug("RESPONSE FOR UPDATE UIComponent PERMISSION:",response);
                        modalMessageService.showMessage( "Success:", "Permissions updated successfully");
                        $scope.loading_data = false;
                        $scope.selectedRoleMessage = '';
                        $scope.permChangeDisabled = true;
                    },
                    function(response) {
                        if ( response.status == 403 ) {
                            $state.go('app.autherror');
                            modalMessageService.showMessage( "Error:", "You do not have permission to access this page.");
                        } else {
                            $log.debug("Error: ",response);
                            modalMessageService.showMessage( "Error:", response.status + " " +
                                response.statusText + '. Please contact ' + agSupportEmail + ' and mention Error ' + response.data.message + '.');
                        }
                        // Turn off loading data image
                        $scope.loading_data = false;
                    }
                );
            };

            // **************************************************************************************************
            // ********************* GRID RELATED FUNCTIONS *****************************************************
            // **************************************************************************************************

            var updateGridWithResponse = function( gridRow, response ){
                $log.debug("RESPONSE FROM UPDATE:",response);
                $log.debug("ROW TO UPDATE:", gridRow);
                var entityKeys = Object.keys(gridRow);
                $log.debug("ENTITY KEYS:", entityKeys);
                angular.forEach( entityKeys, function(key) {
                    //$log.debug("ENTITY KEY:", key);
                    if ( ! key.startsWith('$$') ) {
                        gridRow[key] = response[key];
                    }
                });
                //Refresh grid to keep sort intact
                refreshGrid();
            };


            // ***************** DEFINE SORT ORDER *************************************************
            var setInitSort = function(){
                $log.debug("INSIDE setInitSort");
                var url_col = $scope.gridApiUIComponent.grid.getColumn('auth_ui_component_name');
                $scope.gridApiUIComponent.grid.sortColumn(url_col, uiGridConstants.ASC );
            };

            // **************** GRID REFRESH ****************************************************
            var refreshGrid = function() {
                $log.debug("Inside refreshGrid()");
                $scope.gridApiUIComponent.grid.notifyDataChange(uiGridConstants.dataChange.ALL);
            };

            // Executed when row is selected
            var rowUIComponentSelectionWasChanged = function(row){
                // Clear message and hide UIComponent text box
                $scope.message = '';
                $scope.showmessage = false;
                $scope.modUIComponent = false;
                var selected_count = $scope.gridApiUIComponent.selection.getSelectedCount();
                if ( selected_count == 0 ) {
                    $log.debug("++SELECTED COUNT = 0");
                    $scope.rows_selected = false;
                } else {
                    $log.debug("++SELECTED COUNT > 0");
                    $scope.rows_selected = true;
                }
            };

            //******************** UIComponent GRID *************************************
            $scope.gridUIComponent = {
                enablePaginationControls: false,
                //paginationPageSize: 5,
                enableFiltering: true,
                saveSelection: true,
                enableRowHeaderSelection: true,
                selectionRowHeaderWidth: 30,
                multiSelect: false,
                rowHeight: 30,
                showGridFooter:false,
                columnDefs: [
                    {field: 'auth_ui_component_guid', visible: false },
                    {field: 'auth_ui_component_name', displayName: 'UI Component Name', width: 200, enableHiding: false, pinnedLeft:true },
                    {field: 'auth_ui_component_desc', displayName: 'UI Component Description', width: 400, enableHiding: false }
                ]
            };
            // Register the grid for API calls like clearSelectedRows() and getSelectedRows()
            $scope.gridUIComponent.onRegisterApi = function(gridApiUIComponent){
                $log.debug("INSIDE onRegisterApi call");
                $scope.gridApiUIComponent = gridApiUIComponent;
                // Register callback function for when a single row selection or all row selection toggles
                gridApiUIComponent.selection.on.rowSelectionChanged($scope,rowUIComponentSelectionWasChanged);
                gridApiUIComponent.selection.on.rowSelectionChangedBatch($scope,rowUIComponentSelectionWasChanged);
            };

            $scope.clearUIComponentSelection = function(){
                $scope.gridApiUIComponent.selection.clearSelectedRows();
            };

            // ****************** FETCH ALL ROWS AND FILL THE GRID *********************************
            $scope.getUIComponentDetails = function() {
                // Display loading image while fetching data
                $log.debug("INSIDE getUIComponentDetails");
                $scope.loading_data = true;
                uiComponentFactory.doUIComponents().query()
                    .$promise.then(
                    function(response){
                        $log.debug("RESPONSE FROM GETTING UIComponentS:", response);
                        $scope.gridUIComponent.data = response;
                        setInitSort();
                        //$log.debug("gridUIComponent.data:",$scope.gridUIComponent.data );
                        // Turn off loading data image
                        $scope.loading_data = false;

                    },
                    function(response) {
                        if ( response.status == 403 ) {
                            $state.go('app.autherror');
                            modalMessageService.showMessage( "Error:", "You do not have permission to access this page.");
                        } else {
                            // If there is an error getting UIComponents from database,
                            // this will have an error as well.  If so, put the message in the error modal.
                            $log.debug("ERROR RESPONSE:", response);
                            $log.debug("Error: "+response.status + " " + response.statusText);
                            modalMessageService.showMessage( "Error:", response.status + " " +
                                response.statusText + '. Please contact ' + agSupportEmail);
                        }
                        // Turn off loading data image
                        $scope.loading_data = false;
                    }
                );
            };

            // *********************************************************************************
            // ************************ Initial load of data to start it all off ***************
            // *********************************************************************************
            $scope.getUIComponentDetails();

        }])
;
