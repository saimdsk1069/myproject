(function () {
    'use strict';
}());

angular.module('agSADCeFarms')
    .controller('UIModalController', ['$scope', '$log','$uibModalInstance', 'ui_component_stuff', 'addOrUpdate',
        function($scope, $log, $uibModalInstance, ui_component_stuff, addOrUpdate ) {

            $scope.addOrUpdate = addOrUpdate;
            $scope.ui_component_stuff = angular.copy(ui_component_stuff);
            $log.debug("Inside UI Modal Controller");
            $log.debug("Component Stuff:", ui_component_stuff);

            $scope.Submit = function () {
                $log.debug("Submit Button Hit");
                var response = {'user_returned': $scope.ui_component_stuff, 'addOrUpdate': $scope.addOrUpdate };
                $uibModalInstance.close(response);
            };
            $scope.Cancel = function () {
                $log.debug("Cancel Button Hit");
                $uibModalInstance.dismiss();
            };

        }])
;
