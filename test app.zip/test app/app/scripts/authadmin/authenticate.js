angular.module('agSADCeFarms')
    .run(function ($rootScope, $state, $location, AuthService, $uibModalStack, $log, agSupportEmail, modalService, modalMessageService, Idle, Title) {

        $rootScope.$on('IdleStart', function() {
            $log.debug("++++IdleStart");
            var modalOptions = {
                closeButtonText: 'Cancel',
                closeButtonVisible: true,
                actionButtonText: 'Continue',
                actionButtonVisible: true,
                headerText: 'Warning:',
                bodyText: "Your session is about to expire. Press 'Continue' to stay logged in or 'Cancel' to log out."
            };
            modalService.showModal( {}, modalOptions, {})
                .then( function(response){
                    //TODO Maybe call to reset session timer on server?
                }, function(response){
                    // User hit cancel so display this modal.  Otherwise, timeout occurred so don't show this modal.
                    if (response){
                        $log.debug("Logging user off with response:", response);
                        AuthService.logoff();
                        $uibModalStack.dismissAll();
                        modalMessageService.showMessage( "Warning:", "You have been logged off.");
                        Idle.unwatch();
                    }
                });
        });
        $rootScope.$on('IdleTimeout', function() {
            $log.debug('++++Logging User Out');
            AuthService.logoff();
            $uibModalStack.dismissAll();
            Idle.unwatch();
            modalMessageService.showMessage( "Warning:", "Your session has been terminated.");
            $state.go('app');

        });
        $rootScope.$on("$stateChangeStart", function(event, toState, toParams, fromState, fromParams){
            // Check to see if an authentication check has been made.  If it is not checked, call the Auth service
            // to get current credentials
            $log.debug("toState:",toState);
            $log.debug("toParams:",toParams);
            if ( !AuthService.authChecked ){
                $log.debug("======AuthService.authChecked is false");
                AuthService.authenticate()
                    .then(
                    function(response) {
                        //$log.debug("======AUTHENTICATE RESPONSE:", response);
                        // Valid call to authenticate.  So set the AuthService response.
                        AuthService.setAuthenticateResponse(response);
                        if (response.status == 'AUTHENTICATED'){
                            // User is authenticated via portal
                            AuthService.setAuthenticatedState(true);
                        } else {
                            // User is not authenticated via portal
                            AuthService.setAuthenticatedState(false);
                        }
                        //$log.debug("======State Change Start");
                        //$log.debug("======toState",toState);
                       // $log.debug("======AuthService.isAuthenticated()",AuthService.isAuthenticated());
                        AuthService.authChecked = true;
                        if ( toState.name != 'app' ){ // Public access is allowed to app state
                            if (!AuthService.checkAccess(toState)) {
                                $log.debug("Access is Denied!");
                                $location.path('autherror');
                            }
                        } else {
                            $log.debug("Access is public for this state");
                        }
                    },
                    function(response) {
                        $log.debug("ERROR FROM AUTHENTICATE SERVICE:", response.status);
                        $log.debug("Error:", response.status + " " + response.statusText + " Please contact " + agSupportEmail + " and mention this message.");
                        modalMessageService.showMessage( "Error:", response.status + " " + response.statusText + ". Please contact " + agSupportEmail + " and mention this message");
                    }
                );
            } else {
                // Authorization has been called
                //$log.debug("======Authorization has been checked");
                //$log.debug("======State Change Start");
                //$log.debug("======toState",toState);
                $log.debug("======AuthService.isAuthenticated()",AuthService.isAuthenticated());
                if ( toState.name != 'app' ){
                    if (!AuthService.checkAccess(toState)) {
                        $log.debug("Access is Denied!");
                        $location.path('autherror');
                    }
                } else {
                    $log.debug("Access is public for this state");
                }
            }

        });
});
