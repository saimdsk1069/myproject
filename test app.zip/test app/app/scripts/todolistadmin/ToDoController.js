(function() {
    'use strict';
}());
angular.module('agSADCeFarms')
        .controller('authAdminToDoCtrl', ['$rootScope', '$scope', '$state', '$log', '$uibModal', 'authAdminToDoService', '$sce', '$http', '$window', '$filter', 'modalService', function($rootScope, $scope, $state, $log, $uibModal, authAdminToDoService, $sce, $http, $window, $filter, modalService) {

        authAdminToDoService.fetchGetAppType().then(
                function(response) {
                    $scope.adminToDoListAppType = response;
                    //$scope.toDoItemslist = response;
                },
                function(errResponse) {
                    toastr.clear();
                    toastr.error('Bad Connectivity / Server Down', 'Error while fetching ToDo List Application Type');
                }
        );

        $scope.getAppName = function(appTypeGUID) {
            return $filter('filter')($scope.adminToDoListAppType, {application_type_guid: appTypeGUID})[0].application_name;
        };

        var appTypeGUIDTemplate = "<div class='ui-grid-cell-contents'> {{ grid.appScope.getAppName(row.entity.application_type_guid) }} </div>";
        $rootScope.adminToDoListGrid = {
            paginationPageSizes: false,
            enableFiltering: true,
            enableRowSelection: true,
            multiSelect: false,
            resizable: true,
            enableFullRowSelection: true,
            paginationPageSize: 25,
            appScopeProvider: $scope,
            rowTemplate: '<div ng-click="grid.appScope.viewToDo(row)" ng-repeat="(colRenderIndex, col) in colContainer.renderedColumns track by col.uid" class="ui-grid-cell " ng-class="col.colIndex()" ui-grid-cell></div>',
            columnDefs: [
                {name: 'todo_list_title', displayName: 'Title', width: '25%', cellTooltip: true},
                {name: 'todo_list_desc', displayName: 'Description', width: '50%', cellTooltip: true},
                {name: 'application_type_guid', displayName: 'Application Type', cellTooltip: true, width: '24.5%', cellTemplate: appTypeGUIDTemplate}
            ]
        };


        $rootScope.adminToDoListGrid.onRegisterApi = function(gridApiAdminToDo) {
            $rootScope.gridApiAdminToDo = gridApiAdminToDo;
        };

        authAdminToDoService.fetchGetToDoList().then(
                function(response) {
                    $rootScope.adminToDoListGrid.data = response;
                    //$scope.toDoItemslist = response;
                },
                function(errResponse) {
                    toastr.clear();
                    toastr.error('Bad Connectivity / Server Down', 'Error while fetching ToDo Items List');
                }
        );

        $scope.deleteToDoList = function() {
            var selectedRow = $rootScope.gridApiAdminToDo.selection.getSelectedRows();
            if (selectedRow.length > 0) {
//                $scope.confirmDel = confirDelService.DelConfirmation("Are you Sure, You want Delete ..?",
//                'Please note, Deleted Item cannot be Undo');

                var modalOptions = {
                    closeButtonText: 'No',
                    actionButtonText: 'Yes',
                    headerText: 'Warning',
                    bodyText: 'Are you sure you want to delete this item?'
                };
                modalService.showModal({}, modalOptions)
                        .then(function(result) {
                    $.each(selectedRow, function(index, value) {
                        authAdminToDoService.deleteToDoList(value, value.todo_list_guid).then(
                                function(response) {
                                    authAdminToDoService.fetchGetToDoList().then(
                                            function(response) {
                                                $rootScope.adminToDoListGrid.data = response;
                                                //$scope.toDoItemslist = response;
                                            },
                                            function(errResponse) {
                                                toastr.clear();
                                                toastr.error('Bad Connectivity / Server Down', 'Error while fetching ToDo Items List');
                                            }
                                    );
                                    toastr.clear();
                                    toastr.success('ToDo Items List deleted successfully');
                                    //$scope.toDoItemslist = response;
                                },
                                function(errResponse) {
                                    toastr.clear();
                                    toastr.error('Bad Connectivity / Server Down', 'Error while fetching ToDo Items List');
                                }
                        );
                    });
                });
            }
        };


        $scope.viewToDo = function(rowData) {
            var modalInstance = $uibModal.open({
                templateUrl: 'showToDoList.html',
                controller: 'showToDoListCtrl',
                windowClass: "confirmDelAdminToDo",
                backdrop: 'static',
                size: 'lg',
                resolve: {
                    toDoItems: function() {
                        return rowData.entity;
                    }
                }
            });

            modalInstance.result.then(function(selectedItem) {
                //$scope.selected = selectedItem;
            }, function() {
                $log.info('Modal dismissed at: ' + new Date());
            });
        };

        $scope.addToDoList = function() {
            var modalInstance = $uibModal.open({
                templateUrl: 'addToDoList.html',
                controller: 'addToDoListCtrl',
                windowClass: "confirmDelAdminToDo",
                backdrop: 'static',
                size: 'lg',
                resolve: {
                }
            });

            modalInstance.result.then(function(selectedItem) {
                //$scope.selected = selectedItem;
            }, function() {
                $log.info('Modal dismissed at: ' + new Date());
            });
        };

    }]).controller('showToDoListCtrl', function($scope, $rootScope, $uibModal, $log, authAdminToDoService, $filter, $window, $uibModalInstance, toDoItems, $state, modalService) {
    $scope.adminToDoListSel = toDoItems;

    var phaseResults = '';
    authAdminToDoService.fetchToDoPhaseDetails().then(
            function(response) {
                //return response;
                phaseResults = response;
            },
            function(errResponse) {
                toastr.clear();
                toastr.error('Bad Connectivity / Server Down', 'Error while fetching ToDo Phase Details');
                return {};
            }
    );
        $scope.getPhaseName = function(phaseId){
            if(phaseId == '' || phaseId == null || phaseId == undefined || phaseResults == "" || phaseResults == null || phaseResults == undefined){
                return '';
            }else{
                return $filter('filter')(phaseResults, {application_phase_guid: phaseId})[0].application_phase_name;

            }
        };


    var stateTemplate = "<div class='ui-grid-cell-contents'> <span class='todoItemCondition todoItemCondition-{{row.entity.todo_item_conditional_flg ? row.entity.todo_item_conditional_flg : \"false\" }}'></span> </div>";
    var phaseTemplate = "<div class='ui-grid-cell-contents'> {{grid.appScope.getPhaseName(row.entity.application_phase_guid)}} </div>";

    $rootScope.ToDoListGrid = {
        paginationPageSizes: false,
        enableFiltering: true,
        enableRowSelection: true,
        multiSelect: false,
        resizable: true,
        enableFullRowSelection: true,
        paginationPageSize: 25,
        appScopeProvider: $scope,
        rowTemplate: '<div ng-click="grid.appScope.viewToDoItem(row, rowRenderIndex)" ng-repeat="(colRenderIndex, col) in colContainer.renderedColumns track by col.uid" class="ui-grid-cell " ng-class="col.colIndex()" ui-grid-cell></div>',
        columnDefs: [
            {name: 'todo_item_title', displayName: 'Title', width: '25%', cellTooltip: true},
            {name: 'todo_item_desc', displayName: 'Description', width: '45.5%', cellTooltip: true},
            {name: 'todo_item_conditional_flg', displayName: 'Conditional', width: '15%', cellTooltip: true, cellTemplate: stateTemplate},
            {name: 'application_phase_guid', displayName: 'Phase Due', width: '14.5%', cellTooltip: true,cellTemplate: phaseTemplate}
        ]
    };


    $rootScope.ToDoListGrid.onRegisterApi = function(gridApiToDoList) {
        $rootScope.gridApiToDoList = gridApiToDoList;
    };

    $rootScope.ToDoListGrid.data = toDoItems.todo_list_json;

    authAdminToDoService.fetchGetAppType().then(
            function(response) {
                $scope.adminToDoListAppTypeEdit = response;
                //$scope.toDoItemslist = response;
            },
            function(errResponse) {
                toastr.clear();
                toastr.error('Bad Connectivity / Server Down', 'Error while fetching ToDo List Application Type');
            }
    );

    $scope.saveAdminToDoList = function() {
        var putData = {
            "todo_list_guid": $scope.editAdminToDo.listGUID,
            "todo_list_title": $scope.editAdminToDo.title,
            "todo_list_desc": $scope.editAdminToDo.desc,
            "application_type_guid": $scope.editAdminToDo.appType.application_type_guid,
            "todo_list_json": $rootScope.ToDoListGrid.data
        };


        authAdminToDoService.putToDoList(putData, $scope.editAdminToDo.listGUID).then(
                function(response) {
                    $uibModalInstance.close('Edit Save');
                    //$window.location.reload();
                    authAdminToDoService.fetchGetToDoList().then(
                            function(response) {
                                $rootScope.adminToDoListGrid.data = response;
                                //$scope.toDoItemslist = response;
                            },
                            function(errResponse) {
                                toastr.clear();
                                toastr.error('Bad Connectivity / Server Down', 'Error while fetching ToDo Items List');
                            }
                    );
                    //$scope.toDoItemslist = response;
                },
                function(errResponse) {
                    toastr.clear();
                    toastr.error('Bad Connectivity / Server Down', 'Error while fetching ToDo List Application Type');
                }
        );
    };

    $scope.cancelAdminToDoList = function() {
        $uibModalInstance.close('cancel');
    };

    $scope.viewToDoItem = function(row, rowIndex) {
        var modalInstance = $uibModal.open({
            templateUrl: '../app/views/todolistadmin/showToDoItems.html',
            controller: 'showToDoItemCtrl',
            windowClass: "adminToDoItem",
            backdrop: 'static',
            size: 'lg',
            resolve: {
                toDoItem: function() {
                    return row.entity;
                },
                rowIndex: function() {
                    return rowIndex;
                }
            }
        });

        modalInstance.result.then(function(selectedItem) {
            //$scope.selected = selectedItem;
        }, function() {
            $log.info('Modal dismissed at: ' + new Date());
        });
    };

    $scope.addToDoItem = function() {

        var modalInstance = $uibModal.open({
            templateUrl: '../app/views/todolistadmin/addToDoItem.html',
            controller: 'addToDoItemCtrl',
            backdrop: 'static',
            size: 'lg',
            resolve: {
            }
        });

        modalInstance.result.then(function(selectedItem) {
            //$scope.selected = selectedItem;
        }, function() {
             toastr.clear();
             toastr.success('Item added Successfully');
            $log.info('Modal dismissed at: ' + new Date());
        });
    };

    $scope.deleteToDoItems = function() {
        var selectedRow = $rootScope.gridApiToDoList.selection.getSelectedRows();
        if (selectedRow.length > 0) {
//                $scope.confirmDel = confirDelService.DelConfirmation("Are you Sure, You want Delete ..?",
//                'Please note, Deleted Item cannot be Undo');
            var modalOptions = {
                closeButtonText: 'No',
                actionButtonText: 'Yes',
                headerText: 'Warning',
                bodyText: 'Are you sure you want to delete this item?'
            };
            modalService.showModal({}, modalOptions)
                    .then(function(result) {
                $.each(selectedRow, function(index, value) {
                    var rowIndex = $rootScope.ToDoListGrid.data.indexOf(value);
                    $rootScope.ToDoListGrid.data.splice(rowIndex, 1);

                    toastr.clear();
                    toastr.success('Item deleted Successfully');
                });
            });
        }
    };


}).controller('addToDoListCtrl', function($scope, $rootScope, $uibModal, $log, authAdminToDoService, $filter, $window, $uibModalInstance, $state) {

 var phaseResults = '';
    authAdminToDoService.fetchToDoPhaseDetails().then(
            function(response) {
                //return response;
                phaseResults = response;
            },
            function(errResponse) {
                toastr.clear();
                toastr.error('Bad Connectivity / Server Down', 'Error while fetching ToDo Phase Details');
                return {};
            }
    );
        $scope.getPhaseName = function(phaseId){
            if(phaseId == '' || phaseId == null || phaseId == undefined || phaseResults == "" || phaseResults == null || phaseResults == undefined){
                return '';
            }else{
                return $filter('filter')(phaseResults, {application_phase_guid: phaseId})[0].application_phase_name;

            }
        };
    var stateTemplate = "<div class='ui-grid-cell-contents'> <span class='todoItemCondition todoItemCondition-{{row.entity.todo_item_conditional_flg ? row.entity.todo_item_conditional_flg : \"false\" }}'></span> </div>";
    var phaseTemplate = "<div class='ui-grid-cell-contents'> {{grid.appScope.getPhaseName(row.entity.application_phase_guid)}} </div>";
    $rootScope.ToDoListGrid = {
        paginationPageSizes: false,
        enableFiltering: true,
        enableRowSelection: true,
        multiSelect: false,
        resizable: true,
        enableFullRowSelection: true,
        paginationPageSize: 25,
        appScopeProvider: $scope,
        rowTemplate: '<div ng-click="grid.appScope.viewToDoItem(row, rowRenderIndex)" ng-repeat="(colRenderIndex, col) in colContainer.renderedColumns track by col.uid" class="ui-grid-cell " ng-class="col.colIndex()" ui-grid-cell></div>',
        columnDefs: [
            {name: 'todo_item_title', displayName: 'Title', width: '25%', cellTooltip: true},
            {name: 'todo_item_desc', displayName: 'Description', width: '45.5%', cellTooltip: true},
            {name: 'todo_item_conditional_flg', displayName: 'Conditional', width: '15%', cellTooltip: true, cellTemplate: stateTemplate},
            {name: 'application_phase_guid', displayName: 'Phase Due', width: '14.5%', cellTooltip: true,cellTemplate: phaseTemplate}
        ]
    };


    $rootScope.ToDoListGrid.onRegisterApi = function(gridApiToDoList) {
        $rootScope.gridApiToDoList = gridApiToDoList;
    };

    $rootScope.ToDoListGrid.data = [];

    authAdminToDoService.fetchGetAppType().then(
            function(response) {
                $scope.adminToDoListAppTypeEdit = response;
                //$scope.toDoItemslist = response;
            },
            function(errResponse) {
                toastr.clear();
                toastr.error('Bad Connectivity / Server Down', 'Error while fetching ToDo List Application Type');
            }
    );

    $scope.saveAdminToDoList = function() {
        var postData = {
            "todo_list_guid": $scope.editAdminToDo.listGUID,
            "todo_list_title": $scope.editAdminToDo.title,
            "todo_list_desc": $scope.editAdminToDo.desc,
            "application_type_guid": $scope.editAdminToDo.appType.application_type_guid,
            "todo_list_json": $rootScope.ToDoListGrid.data
        };


        authAdminToDoService.postToDoList(postData).then(
                function(response) {
                    //$window.location.reload();
                    authAdminToDoService.fetchGetToDoList().then(
                            function(response) {
                                $rootScope.adminToDoListGrid.data = response;
                                //$scope.toDoItemslist = response;
                            },
                            function(errResponse) {
                                toastr.clear();
                                toastr.error('Bad Connectivity / Server Down', 'Error while fetching ToDo Items List');
                            }
                    );
                    $uibModalInstance.close('Add Save');
                    //$scope.toDoItemslist = response;
                },
                function(errResponse) {
                    toastr.clear();
                    toastr.error('Bad Connectivity / Server Down', 'Error while fetching ToDo List Application Type');
                }
        );
    };

    $scope.cancelAdminToDoList = function() {
        $uibModalInstance.close('cancel');
    };

    $scope.viewToDoItem = function(row, rowIndex) {
        var modalInstance = $uibModal.open({
            templateUrl: '../app/views/todolistadmin/showToDoItems.html',
            controller: 'showToDoItemCtrl',
            windowClass: "adminToDoItem",
            backdrop: 'static',
            size: 'lg',
            resolve: {
                toDoItem: function() {
                    return row.entity;
                },
                rowIndex: function() {
                    return rowIndex;
                }
            }
        });

        modalInstance.result.then(function(selectedItem) {
            //$scope.selected = selectedItem;
        }, function() {
            $log.info('Modal dismissed at: ' + new Date());
        });
    };

    $scope.addToDoItem = function() {

        var modalInstance = $uibModal.open({
            templateUrl: '../app/views/todolistadmin/addToDoItem.html',
            controller: 'addToDoItemCtrl',
            backdrop: 'static',
            size: 'lg',
            resolve: {
            }
        });

        modalInstance.result.then(function(selectedItem) {
            //$scope.selected = selectedItem;
        }, function() {
            toastr.clear();
            toastr.success('Item added Successfully');
            $log.info('Modal dismissed at: ' + new Date());
        });
    };

    $scope.deleteToDoItems = function() {
        var selectedRow = $rootScope.gridApiToDoList.selection.getSelectedRows();
        $.each(selectedRow, function(index, value) {
            var rowIndex = $rootScope.ToDoListGrid.data.indexOf(value);
            $rootScope.ToDoListGrid.data.splice(rowIndex, 1);

            toastr.clear();
            toastr.success('Item deleted Successfully');
        },
                function(errResponse) {
                    toastr.clear();
                    toastr.error('Bad Connectivity / Server Down', 'Error while fetching ToDo Items List');
                }
        );


        console.log(selectedRow);

    };


}).controller('showToDoItemCtrl', function($scope, $rootScope, applicationService, authAdminToDoService, $state, $uibModal, $filter, $uibModalInstance, toDoItem, rowIndex) {

    $scope.adminToDoItemSel = toDoItem;

    $scope.dateOptions = {
        formatYear: 'yy',
        maxDate: new Date(2020, 5, 22),
        minDate: new Date(),
        startingDay: 1
    };

    $scope.today = function() {
        if (toDoItem && toDoItem.todo_item_due_date != null && toDoItem.todo_item_due_date != undefined) {
            $scope.dt = new Date(toDoItem.todo_item_due_date);
        }
    };
    $scope.today();
    $scope.datePick = {};
    $scope.openDate = false;

    authAdminToDoService.fetchToDoPhaseDetails().then(
            function(response) {
                //return response;
                $scope.phaseList = response; //console.log(dataObj);
            },
            function(errResponse) {
                toastr.clear();
                toastr.error('Bad Connectivity / Server Down', 'Error while fetching ToDo Phase Details');
                return {};
            }
    );

    $scope.addUser = function() {

        var modalInstance = $uibModal.open({
            templateUrl: 'views/application/appAddUser.html',
            controller: 'addUserToDoItemCtrl',
            backdrop: 'static',
            size: 'lg',
            resolve: {
                userData: function() {
                    return $scope.adminToDoItemSel.users;
                }
            }
        });

        modalInstance.result.then(function(selectedItem) {
            //$scope.selected = selectedItem;
        }, function() {
            console.log('Modal dismissed at: ' + new Date());
        });
    };

    $scope.deleteUser = function(userIndex) {
        delete  $scope.editToDo.user[userIndex];
        $scope.appToDoSingleItem.users.splice(userIndex, 1);
        //console.log($scope.editToDo.user);
    };

    $scope.addRole = function() {

        var modalInstance = $uibModal.open({
            templateUrl: 'views/application/appAddRole.html',
            controller: 'addRoleToDoItemCtrl',
            backdrop: 'static',
            size: 'lg',
            resolve: {
                roleData: function() {
                    return $scope.adminToDoItemSel.roles;
                }
            }
        });

        modalInstance.result.then(function(selectedItem) {
            //$scope.selected = selectedItem;
        }, function() {
            console.log('Modal dismissed at: ' + new Date());
        });
    };

    $scope.deleteRole = function(roleIndex) {
        //$scope.editToDo.role.splice(roleIndex,1);
        delete  $scope.editToDo.role[roleIndex];
        //console.log($scope.editToDo.role);
        $scope.appToDoSingleItem.roles.splice(roleIndex, 1);
    };


    $scope.saveAdminToDoItem = function() {

        var putData = {
            "todo_item_guid": $scope.editToDo.ItemGUID,
            "todo_item_title": $scope.editToDo.title,
            "todo_item_desc": $scope.editToDo.desc,
            "todo_item_due_date": $scope.editToDo.dueDate ? $filter('date')($scope.editToDo.dueDate, "yyyy-MM-dd") : null,
            "todo_item_conditional_flg": $scope.editToDo.conditional ? true : false,
            "farm_guid": $scope.editToDo.farmGUID,
            "application_guid": $state.params.ID,
            "application_phase_guid": $scope.editToDo.phaseDate.application_phase_guid,
            "users": [],
            "roles": []
        };
        angular.forEach($scope.editToDo.user, function(value, index) {
            var tempUser = {
                "auth_user_guid": value.guid,
                "salutation": value.salutation,
                "first_name": value.first_name,
                "last_name": value.last_name,
                "title": value.title,
                "organization": value.organization
            };
            putData.users.push(tempUser);
        });
        angular.forEach($scope.editToDo.role, function(value, index) {
            var tempRole = {
                "auth_role_guid": value.guid,
                "auth_role_name": value.name
            };
            putData.roles.push(tempRole);
        });


        $rootScope.ToDoListGrid.data.splice(rowIndex, 1, putData);

        $uibModalInstance.dismiss('Save');

    };

    $scope.cancelAdminToDoItem = function() {
        $uibModalInstance.close('Cancel');
    };
}).controller('addToDoItemCtrl', function($scope, $rootScope, $uibModal, $filter, $window, $uibModalInstance, authAdminToDoService, applicationService, $state) {
    $scope.toDoItem = {
        users: [],
        roles: []
    };

    $scope.dateOptionsAddItem = {
        formatYear: 'yy',
        maxDate: new Date(2020, 5, 22),
        minDate: new Date(),
        startingDay: 1
    };

    $scope.today = function() {
        $scope.presentDate = new Date();
    };
    $scope.today();
    $scope.datePick = {};

    authAdminToDoService.fetchToDoPhaseDetails().then(
            function(response) {
                //return response;
                $scope.phaseList = response; //console.log(dataObj);
            },
            function(errResponse) {
                toastr.clear();
                toastr.error('Bad Connectivity / Server Down', 'Error while fetching ToDo Phase Details');
                return {};
            }
    );

    $scope.addUser = function() {

        var modalInstance = $uibModal.open({
            templateUrl: 'views/application/appAddUser.html',
            controller: 'addUserToDoItemCtrl',
            size: 'lg',
            resolve: {
                userData: function() {
                    return $scope.toDoItem.users;
                }
            }
        });

        modalInstance.result.then(function(selectedItem) {
            //$scope.selected = selectedItem;
        }, function() {
            console.log('Modal dismissed at: ' + new Date());
        });
    };

    $scope.deleteUser = function(userIndex) {
        delete  $scope.toDoItem.users[userIndex];
        $scope.toDoItem.users.splice(userIndex, 1);
    };

    $scope.addRole = function() {

        var modalInstance = $uibModal.open({
            templateUrl: 'views/application/appAddRole.html',
            controller: 'addRoleToDoItemCtrl',
            size: 'lg',
            resolve: {
                roleData: function() {
                    return $scope.toDoItem.roles;
                }
            }
        });

        modalInstance.result.then(function(selectedItem) {
            //$scope.selected = selectedItem;
        }, function() {
            console.log('Modal dismissed at: ' + new Date());
        });
    };

    $scope.deleteRole = function(roleIndex) {
        delete  $scope.toDoItem.roles[roleIndex];
        $scope.toDoItem.roles.splice(roleIndex, 1);
    };


    $scope.createItem = function() {
        var postData = {
            "todo_item_title": $scope.toDoItem.title,
            "todo_item_desc": $scope.toDoItem.desc,
            "todo_item_due_date": $scope.toDoItem.dueDate ? $filter('date')($scope.toDoItem.dueDate, "yyyy-MM-dd") : null,
            "todo_item_conditional_flg": $scope.toDoItem.conditional ? true : false,
            "farm_guid": "",
            "application_guid": $state.params.ID,
            "application_phase_guid": null,
            "users": [],
            "roles": []
        };

        angular.forEach($scope.toDoItem.user, function(value, index) {
            var tempUser = {
                "auth_user_guid": value.guid,
                "salutation": value.salutation,
                "first_name": value.first_name,
                "last_name": value.last_name,
                "title": value.title,
                "organization": value.organization
            };
            postData.users.push(tempUser);
        });
        angular.forEach($scope.toDoItem.role, function(value, index) {
            var tempRole = {
                "auth_role_guid": value.guid,
                "auth_role_name": value.name
            };
            postData.roles.push(tempRole);
        });

        if ($scope.toDoItem.desc == null || $scope.toDoItem.desc == undefined || $scope.toDoItem.desc == ''  ||
                $scope.toDoItem.title == null || $scope.toDoItem.title == undefined || $scope.toDoItem.title == '') {

            toastr.clear();
            toastr.error('Please add all mandatory Fields', 'Error posting Data');
        } else {
            $rootScope.ToDoListGrid.data.push(postData);
        }
        $uibModalInstance.dismiss('Save');

    };

    $scope.cancel = function() {
        $uibModalInstance.dismiss('Cancel');
    };
}).controller('addUserToDoItemCtrl', function($scope, $filter, $window, $uibModalInstance, applicationService, $state, userData) {
    //console.log(userData);
    $scope.usersGrid = {
        paginationPageSizes: false,
        enableFiltering: true,
        enableRowSelection: true,
        multiSelect: true,
        enableFullRowSelection: true,
        paginationPageSize: 25,
        columnDefs: [
            {name: 'first_name'},
            {name: 'last_name'},
            {name: 'title'},
            {name: 'organization'},
            {name: 'email_primary'},
            {name: 'phone_primary'}
        ]
    };

    $scope.usersGrid.onRegisterApi = function(gridApi) {
        $scope.gridApi2 = gridApi;
    };

    $scope.addUserDetails = function() {
        var selectedData = $scope.gridApi2.selection.getSelectedRows();

        angular.forEach(selectedData, function(value, index) {
            var tempUser = {
                "auth_user_guid": value.auth_user_guid,
                "salutation": value.salutation,
                "first_name": value.first_name,
                "last_name": value.last_name,
                "title": value.title,
                "organization": value.organization
            };
            userData.push(tempUser);
        });
        $uibModalInstance.dismiss('Cancel');
        //console.log(userData);
    };

    $scope.userCancel = function() {
        $uibModalInstance.dismiss('Cancel');
    };
    applicationService.fetchUsersList($state.params.ID).then(
            function(response) {
                //return response;
                $scope.usersGrid.data = response; //console.log(dataObj);
            },
            function(errResponse) {
                console.error('Error while fetching ToDo Item User List');
                return {};
            }
    );
}).controller('addRoleToDoItemCtrl', function($scope, $filter, $window, $uibModalInstance, applicationService, $state, roleData) {

    $scope.rolesGrid = {
        paginationPageSizes: false,
        enableFiltering: true,
        enableRowSelection: true,
        multiSelect: true,
        enableFullRowSelection: true,
        paginationPageSize: 25,
        columnDefs: [
            {name: 'auth_role_name'},
            {name: 'description'},
            {name: 'tier_desc'},
            {name: 'tier_group_desc'},
            {name: 'tier_subgroup_desc'}
        ]
    };

    $scope.rolesGrid.onRegisterApi = function(gridApi) {
        $scope.gridApi2 = gridApi;
    };

    $scope.addRoleDetails = function() {
        var selectedData = $scope.gridApi2.selection.getSelectedRows();

        angular.forEach(selectedData, function(value, index) {
            var tempRole = {
                "auth_role_guid": value.auth_role_guid,
                "auth_role_name": value.auth_role_name
            };
            roleData.push(tempRole);
        });
        $uibModalInstance.dismiss('Cancel');
        //console.log(roleData);
    };

    $scope.roleCancel = function() {
        $uibModalInstance.dismiss('Cancel');
    };

    applicationService.fetchRolesList($state.params.ID).then(
            function(response) {
                //return response;
                $scope.rolesGrid.data = response; //console.log(response);
            },
            function(errResponse) {
//                return {};
                console.error('Error while fetching ToDo Item Roles List');
            }
    );
});