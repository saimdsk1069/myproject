(function () {
    'use strict';
}());

angular.module('agSADCeFarms')
    .controller('AppropriationController', ['$scope','$stateParams','$location','$filter', '$uibModal','uiGridConstants','GetTransferStatus','AuthService','GetAppropInfo','AppropDataService','ReappropDataService','GetAppropn','UpdateApprop','UpdateReapprop','DeleteAppropriation','GetRelatedappropn','GetTransactiontype','GetReappropn','GetAppropPayHistory','Getfund','GetProgramtype','GetGranttype','AddApprop', '$state', '$log','modalService','modalMessageService', function($scope,$stateParams,$location,$filter,$uibModal,uiGridConstants,GetTransferStatus,AuthService,GetAppropInfo,AppropDataService,ReappropDataService,GetAppropn,UpdateApprop,UpdateReapprop,DeleteAppropriation,GetRelatedappropn,GetTransactiontype,GetReappropn,GetAppropPayHistory,Getfund,GetProgramtype,GetGranttype,AddApprop,$state,$log,modalService,modalMessageService) {






// Appropriation Details
    $scope.viewSelectedApprop = function(){
      AppropDataService.setSelectedApprop($scope.gridApiApprops.selection.getSelectedRows());
      $scope.selectedRows = $scope.gridApiApprops.selection.getSelectedRows()[0];
      $scope.selectedguidapprop = $scope.selectedRows.appropriation_guid;

        var appropriation_guid = $scope.selectedguidapprop;
        $location.path('/finance/appropriations/appropdetail/'+appropriation_guid);
          };
         $scope.selectedAppropData = AppropDataService.getSelectedApprop()[0];
         $scope.selectedAppropPayment = _.get($scope.selectedAppropData, 'payments');
         $scope.selectedAppropReapprop = _.get($scope.selectedAppropData, 'reappropriations');



// Delete Appropriation here
        $scope.deleteapprop = function(){
            $scope.currentselectedapprop = getAppropSelection();
            $scope.delappropid =   Object.values($scope.currentselectedapprop.selectedApprop)[0];
            $scope.aguid = $scope.delappropid.appropriation_guid;
            console.log($scope.aguid);
            var modalOptions = {
                            closeButtonText: 'No',
                            actionButtonText: 'Yes',
                            headerText: 'Warning',
                            bodyText: 'Are you sure you want to delete this item?'
                         };
                             modalService.showModal({}, modalOptions)
                                .then(function (result) {
             DeleteAppropriation.deleteappropriation().delete({appropriation_guid:$scope.aguid})
                .$promise.then(
                   function(){
                      console.log("Deleted from server");
                      modalMessageService.showMessage( "Success:","Appropriation deleted Successfully");
                      $state.reload();
                   },
                   function(response) {
                        $log.debug("ERROR Deleting Appropriation:", response);
                       if (response.data.result === 'error' ) {
                           modalMessageService.showMessage( "Error:", response.data.message);
                        } else {
                            modalMessageService.showMessage( "Error:", "This appropriation cannot be deleted.");
                        }
                        $log.debug("Error: "+response.status + " " + response.statusText);
                    }
              );
              });
        };





// Add New Approp here
    $scope.appropModal = function() {
         var modalInstance = $uibModal.open({
            templateUrl:'views/finance/newapprop.html',
            controller:'AppropsModalCtrl',
            backdrop: 'static',
          });
           modalInstance.result.then(function (modalResponse) {
                    console.log("modalResponse", modalResponse);
                }, function () {
                            $log.debug("cancelled the Appropriation entry");
                });
          $scope.isDisabled = false;
    };
    $scope.isDisabled = true;



// Reappropriation here
    $scope.reapporpModal = function(){
        var modalInstance = $uibModal.open({
            templateUrl:'views/finance/reappropriate.html',
            controller:'AppropsModalCtrl',
            backdrop: 'static',
        });
        modalInstance.result.then(function (modalResponse) {
                    console.log("modalResponse", modalResponse);
                }, function () {
                            $log.debug("cancelled the reappropriation entry");
                });
        $scope.isDisabled = false;
    };

// Reappropriation here
    $scope.reapporpModal2 = function(){
        var modalInstance = $uibModal.open({
            templateUrl:'views/finance/appropreapprop.html',
            controller:'AppropsModalCtrl',
            backdrop: 'static',
        });
        modalInstance.result.then(function (modalResponse) {
                    console.log("modalResponse", modalResponse);
                }, function () {
                            $log.debug("cancelled the reappropriation entry");
                });
        $scope.isDisabled = false;
    };




// Transfer Status
 var transferstatus  = GetTransferStatus.gettransferstatus().query()
      .$promise.then(
        function(response){
            $scope.transferstatuslist = response;
        });


 // Get Appropriation Details here
 var appropslist = GetAppropn.getappropn().query()
      .$promise.then(
        function(response){
            $scope.appropslist = response;
        });


//ui components
    $scope.ui_components = {
            'ui_fiscal_admin': false,
        };

//Check the AuthService here
if ( AuthService.isAuthenticated() ) {
    $log.debug("++++++User is authenticated");
    $log.debug("++++++Users ui access:", AuthService.getUserUIAccess());
    $scope.ui_components = {
            'ui_fiscal_admin':true
        };
} else {
    $log.debug("++++++User is not authenticated");
}


// Appropriations
$scope.gridApprops = {
            enableSorting :true,
            enablePaginationControls: true,
            paginationPageSizes: [25,50,100],
            paginationPageSize: 25,
            enableFiltering: true,
            saveSelection: true,
            enableRowHeaderSelection: true,
            selectionRowHeaderWidth: 50,
            multiSelect: false,
            rowHeight: 35,
            enableGridMenu: true,
            exporterPdfPageSize: 'LETTER',
            exporterPdfMaxGridWidth: 550,
            showGridFooter:false,
            selectedItems: [],
            exporterMenuVisibleData : true,
            exporterCsvFilename: 'Appropriations.csv',
            exporterPdfDefaultStyle: {fontSize: 12},
            exporterPdfTableStyle: {margin: [30, 30, 30, 30]},
            exporterPdfTableHeaderStyle: {fontSize: 12, bold: true, italics: true, color: 'black'},
            exporterPdfHeader: { text: "Appropriations Details", style: 'headerStyle' },
            exporterPdfFooter: function ( currentPage, pageCount ) {
              return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' };
            },
            exporterPdfCustomFormatter: function ( docDefinition ) {
              docDefinition.styles.headerStyle = { fontSize: 22, bold: true };
              docDefinition.styles.footerStyle = { fontSize: 10, bold: true };
              return docDefinition;
            },
            exporterPdfOrientation: 'landscape',
            exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
            exporterExcelFilename: 'Appropriations.xlsx',
            exporterExcelSheetName: 'Sheet1',
            minRowsToShow:999,
            //Row Selection Enhancement
            enableRowSelection: true,
            enableFullRowSelection: true,
            appScopeProvider: $scope,
            rowTemplate: '<div ng-click="grid.appScope.viewAppropDetails(row)" ng-repeat="(colRenderIndex, col) in colContainer.renderedColumns track by col.uid" class="ui-grid-cell" ng-class="col.colIndex()" ui-grid-cell></div>',
            //
            //
            columnDefs: [
                  { name:'Appropriation Name', field: 'appropriation_name', width: 250, pinnedLeft:false, sort: {
                      direction: uiGridConstants.ASC,
                      priority: 0,
                  }},
                  { name:'Appropriation Unit', field: 'appropriation_unit', width: 170,  pinnedLeft:false},
                  { name:'Fund Name', field: 'fund_name', width: 250,  pinnedLeft:false },
                  { name:'Grant Type', field: 'grant_type_desc', width: 125, pinnedLeft:false },
                  { name:'Program  Name', field: 'program_name', width: 250,  pinnedLeft:false},
                  { name:'Appropriation Date', field: 'appropriation_date', width: 170,cellFilter: 'date:medium',  pinnedLeft:false },
                  { name:'Initial Amount', field: 'initial_amount', width: 125,  cellFilter:'currency', pinnedLeft:false },
                  { name:'Balance', field: 'balance', width: 125,cellFilter:'currency',pinnedLeft:false },
                  { name:'Pending', field: 'pending', width: 125,cellFilter:'currency', pinnedLeft:false },
                  { name:'Encumbered', field: 'encumbered', width: 125,cellFilter:'currency', pinnedLeft:false },
                  { name:'Spent', field: 'spent', width: 125, cellFilter:'currency', pinnedLeft:false },
                  { name:'Reappropriated Out', field: 'reappropriated_out_balance', width: 170, cellFilter:'currency', pinnedLeft:false },
                  { name:'Reappropriated In', field: 'reappropriated_in_balance', width: 170,cellFilter:'currency', pinnedLeft:false },
        ],

    };

    //Row Selection Enhancement
    $scope.viewAppropDetails = function(row) {
        var itemguid = row.entity.appropriation_guid;
        if (itemguid) {
             $location.path('/finance/appropriations/appropdetail/'+itemguid);
        }
    };
    //
    //
    $scope.tableHeight = 'height: ' + ($scope.gridApprops.paginationPageSize * 35 + 150) + 'px';

// Register the grid for API calls like clearSelectedRows() and getSelectedRows()
    $scope.gridApprops.onRegisterApi = function(gridApiApprops){
        $scope.gridApiApprops = gridApiApprops;
        changegridHeight($scope.gridApprops.data.length,5);
        $scope.gridApiApprops.pagination.on.paginationChanged($scope, function(newPage,pageSize){
            changegridHeight($scope.gridApprops.data.length,pageSize);
        });

        gridApiApprops.selection.on.rowSelectionChanged($scope,function(row){
        var msg = 'row selected'+row.isSelected;
         $scope.selectedRows = $scope.gridApiApprops.selection.getSelectedRows()[0];
         $scope.selectedguidaprop = $scope.selectedRows.appropriation_guid;
        // console.log($scope.selectedguidfund);
        });
    };
    function changegridHeight(newlength,pgsize){
        console.log(newlength,pgsize);
        $scope.tableHeight = 'height: ' + ($scope.gridApprops.paginationPageSize * 35 + 150) + 'px';
        $scope.gridApiApprops.grid.handleWindowResize();
        $scope.gridApiApprops.core.refresh();
    }


// Get Appropriations from service
$scope.getAppropDetails = function() {
        // Display loading image while fetching data
        $scope.loading_data = true;
        GetAppropn.getappropn().query()
            .$promise.then(
            function(response){
                $scope.appropdetails = response;
                $scope.gridApprops.data = response;
                $log.debug("gridFunds.data:",$scope.gridApprops.data );
                $scope.loading_data = false;
            },
            function(response) {
                // If there is an error getting user statuses from datbase,
                // this will have an error as well.  If so, put the message in the error modal.
                $log.debug("AFTER GETING ERROR FROM DETAILS:", $scope.fundsdetails);
                $log.debug("Error: "+response.status + " " + response.statusText);
                modalMessageService.showMessage( "Error:", response.status + " " +
                    response.statusText + '. Please contact ' + agSupportEmail);
            }
        );
    };


// Do Initial Appropriation load
$scope.getAppropDetails();

 // Selected Appropriation
      var getAppropSelection = function(){
            var selectedRows = $scope.gridApiApprops.selection.getSelectedRows();
             var appropSelection = { selectedApprop: {}};
            angular.forEach( selectedRows, function(row){
                var approp_guid = row.appropriation_guid;
                var approp_id = row.appropriation_id;
                var approp_name = row.approp_name;
                appropSelection.selectedApprop[approp_guid] = row;

            });
            $log.debug("NEW SELECTED USERS:", appropSelection);
            return appropSelection;

        };


// Selected Approp details based on the guid
    $scope.viewSelectedapprop = function(){

    if(!!$scope.selecteddataapprop && !!$scope.selecteddataapprop.appropriation_guid){
        var appropguid = $scope.selecteddataapprop.appropriation_guid;
        $scope.appropguid = $scope.selecteddataapprop;
        var appropdetailsid = GetAppropInfo.getappropinfo(appropguid).get()
                              .$promise.then(
                                function(response){
                                    $scope.selectedappropdetails = response;
                                        $location.path('/finance/appropriations/appropdetail/'+appropguid);
                                },
                                function(err){
                                  modalMessageService.showMessage( "Error:", "Cannot go to this path location");
                                }
                             );
                }
        };
    $scope.viewSelectedapprop();
          if(!!$stateParams){
              $scope.selecteddataapprop = $stateParams;
            }



// Get Approp details grid table data from the guid
$scope.getAppropidDetails = function() {
//                loading image
//                $scope.loading_data = true;
                if(!!$scope.selecteddataapprop && !!$scope.selecteddataapprop.appropriation_guid){
                    var appropguid = $scope.selecteddataapprop.appropriation_guid;
                    $scope.appropguid = $scope.selecteddataapprop;
                    var appropdetailsid = GetAppropInfo.getappropinfo(appropguid).get()
                                      .$promise.then(
                                        function(response){
                                            $scope.selectedappropdetails = response;
                                            $scope.selecteddatadetailpayments = _.get($scope.selectedappropdetails, 'payments');
                                            $scope.selecteddatadetailreappropin = _.get($scope.selectedappropdetails, 'reappropriated_in');
                                            $scope.selecteddatadetailreappropout = _.get($scope.selectedappropdetails, 'reappropriated_out');
                                            $scope.gridAppropPayments.data = $scope.selecteddatadetailpayments;
                                            $scope.gridAppropReappropIn.data= $scope.selecteddatadetailreappropin;
                                            $scope.gridAppropReappropOut.data= $scope.selecteddatadetailreappropout;


                                        },
                                        function(err){
                                           modalMessageService.showMessage( "Error:", "An error occurred. ");
                                        }
                                     );
                        }
            };

            // Do Initial Approps   load
            $scope.getAppropidDetails();







// Get the Appropriation Payments here
$scope.gridAppropPayments = {
            minRowsToShow: 3,
            enableSorting :true,
            enablePaginationControls: true,
            paginationPageSize: 25,
            enableFiltering: true,
            saveSelection: true,
            enableRowHeaderSelection: true,
            selectionRowHeaderWidth: 50,
            multiSelect: false,
            rowHeight: 35,
            exporterPdfPageSize: 'LETTER',
            exporterPdfMaxGridWidth: 500,
            showGridFooter:false,
            selectedItems: [],
            enableGridMenu: true,
            exporterMenuVisibleData : true,
            exporterCsvFilename: 'Appropriation_Payments.csv',
            exporterPdfDefaultStyle: {fontSize: 12},
            exporterPdfTableStyle: {margin: [30, 30, 30, 30]},
            exporterPdfTableHeaderStyle: {fontSize: 12, bold: true, italics: true, color: 'black'},
            exporterPdfHeader: { text: "Appropriation Payments Details", style: 'headerStyle' },
            exporterPdfFooter: function ( currentPage, pageCount ) {
              return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' };
            },
            exporterPdfCustomFormatter: function ( docDefinition ) {
              docDefinition.styles.headerStyle = { fontSize: 22, bold: true };
              docDefinition.styles.footerStyle = { fontSize: 10, bold: true };
              return docDefinition;
            },
            exporterPdfOrientation: 'landscape',
            exporterPdfPageSize: 'LETTER',
            exporterPdfMaxGridWidth: 500,
            exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
            exporterExcelFilename: 'Appropriation_Payments.xlsx',
            exporterExcelSheetName: 'Sheet1',
            //
            //Row Selection Enhancement
            enableRowSelection: true,
            enableFullRowSelection: true,
            appScopeProvider: $scope,
            rowTemplate: '<div ng-click="grid.appScope.viewrelPay(row)" ng-repeat="(colRenderIndex, col) in colContainer.renderedColumns track by col.uid" class="ui-grid-cell" ng-class="col.colIndex()" ui-grid-cell></div>',
            //
            //
            columnDefs: [
                  { name:'Expense Payment ID', field: 'expense_payment_guid', width: 250,  pinnedLeft:false,visible:false},
                  { name:'Expense Type', field: 'expense_type', width: 125, pinnedLeft:false },
                  { name:'Payment  Status', field: 'payment_status_desc', width: 150,  pinnedLeft:false},
                  { name:'Payment Amount', field: 'payment_amount', width: 170,cellFilter:'currency',pinnedLeft:false },
                  { name:'Farm ID ', field: 'farm_id', width: 125,pinnedLeft:false },
                  { name:'Farm Name ', field: 'farm_name', width: 125, pinnedLeft:false },
                  { name:'Partner ', field: 'partner_name', width: 125, pinnedLeft:false },
                  { name:'Application ID', field: 'application_id', width: 150, pinnedLeft:false },
        ],
    };

        //
        //Row Selection Enhancement
        $scope.viewrelPay = function(row) {
        var itemguid = row.entity.expense_payment_guid;
        if (itemguid) {
            $location.path('/finance/payments/paymentdetail/'+itemguid);
        }
        };
        //
        //


// Register the grid for API calls like clearSelectedRows() and getSelectedRows()
    $scope.gridAppropPayments.onRegisterApi = function(gridApiAppropsPay){
        $scope.gridApiAppropsPay = gridApiAppropsPay;

        gridApiAppropsPay.selection.on.rowSelectionChanged($scope,function(row){
        var msg = 'row selected'+row.isSelected;
         $scope.selectedRows = $scope.gridApiAppropsPay.selection.getSelectedRows()[0];
         $scope.selectedguidaprop = $scope.selectedRows.appropriation_guid;
        });
    };




// Get the Appropriation's Reappropriated In here
$scope.gridAppropReappropIn = {
        minRowsToShow: 3,
        enableSorting :true,
        enablePaginationControls: true,
        paginationPageSize: 25,
        enableFiltering: true,
        saveSelection: true,
        enableRowHeaderSelection: true,
        selectionRowHeaderWidth: 50,
        multiSelect: false,
        rowHeight: 35,
        showGridFooter:false,
        selectedItems: [],
        enableGridMenu: true,
        exporterMenuVisibleData : true,
        exporterCsvFilename: 'Appropriation_Reappropriations.csv',
        exporterPdfDefaultStyle: {fontSize: 12},
        exporterPdfTableStyle: {margin: [30, 30, 30, 30]},
        exporterPdfTableHeaderStyle: {fontSize: 12, bold: true, italics: true, color: 'black'},
        exporterPdfHeader: { text: "Appropriation Payments Details", style: 'headerStyle' },
        exporterPdfFooter: function ( currentPage, pageCount ) {
          return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' };
        },
        exporterPdfCustomFormatter: function ( docDefinition ) {
          docDefinition.styles.headerStyle = { fontSize: 22, bold: true };
          docDefinition.styles.footerStyle = { fontSize: 10, bold: true };
          return docDefinition;
        },
        exporterPdfOrientation: 'landscape',
        exporterPdfPageSize: 'LETTER',
        exporterPdfMaxGridWidth: 500,
        exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
        exporterExcelFilename: 'Appropriation_Reappropriations.xlsx',
        exporterExcelSheetName: 'Sheet1',
        //Row Selection Enhancement
        enableRowSelection: true,
        enableFullRowSelection: true,
        appScopeProvider: $scope,
        rowTemplate: '<div ng-click="grid.appScope.viewreApprop(row)" ng-repeat="(colRenderIndex, col) in colContainer.renderedColumns track by col.uid" class="ui-grid-cell" ng-class="col.colIndex()" ui-grid-cell></div>',

        columnDefs: [
              { name:'Reappropriation GUID', field: 'reappropriation_guid', width: 250,pinnedLeft:false,visible:false},
              { name:'Source Appropriation Name', field: 'source_appropriation_name', width: 250, pinnedLeft:false },
              { name:'Source Fund Name', field: 'source_fund_name', width: 250,  pinnedLeft:false},
              { name:'Source Fund GUID', field: 'source_fund_guid', width: 250,  pinnedLeft:false,visible:false },
              { name:'Reappropriation Date', field: 'reappropriation_date', cellFilter: 'date:medium', width: 250,  pinnedLeft:false, sort: {
                  direction: uiGridConstants.ASC,
                  priority: 0,
              } },
              { name:'Transfer Amount', field: 'transfer_amount', width: 170, cellFilter:'currency', pinnedLeft:false },
              { name:'Status', field: 'status_transfer_desc', width: 170, pinnedLeft:false },
              { name:'Balance', field: 'balance', width: 125, cellFilter:'currency', pinnedLeft:false },
    ],

};

            //Row Selection Enhancement
            $scope.viewreApprop = function(row) {
                var itemguid = row.entity.reappropriation_guid;
                if (itemguid) {
                    $location.path('/finance/reappropriations/reappropdetails/'+itemguid);
                }
            };


// Register the grid for API calls like clearSelectedRows() and getSelectedRows()
    $scope.gridAppropReappropIn.onRegisterApi = function(gridApiAppropsReapprop){
        $scope.gridApiAppropsReapprop = gridApiAppropsReapprop;
        gridApiAppropsReapprop.selection.on.rowSelectionChanged($scope,function(row){
        var msg = 'row selected'+row.isSelected;
         $scope.selectedRows = $scope.gridApiAppropsReapprop.selection.getSelectedRows()[0];
         $scope.selectedguidaprop = $scope.selectedRows.appropriation_guid;
        });
    };


// Get the Appropriation's Reappropriated Out here
$scope.gridAppropReappropOut = {
    minRowsToShow: 3,
    enableSorting :true,
    enablePaginationControls: true,
    paginationPageSize: 25,
    enableFiltering: true,
    saveSelection: true,
    enableRowHeaderSelection: true,
    selectionRowHeaderWidth: 50,
    multiSelect: false,
    rowHeight: 35,
    showGridFooter:false,
    selectedItems: [],
    enableGridMenu: true,
    exporterMenuVisibleData : true,
    exporterCsvFilename: 'Appropriation_ReappropriationsOut.csv',
    exporterPdfDefaultStyle: {fontSize: 12},
    exporterPdfTableStyle: {margin: [30, 30, 30, 30]},
    exporterPdfTableHeaderStyle: {fontSize: 12, bold: true, italics: true, color: 'black'},
    exporterPdfHeader: { text: "AppropriationReappropriationsOut Details", style: 'headerStyle' },
    exporterPdfFooter: function ( currentPage, pageCount ) {
      return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' };
    },
    exporterPdfCustomFormatter: function ( docDefinition ) {
      docDefinition.styles.headerStyle = { fontSize: 22, bold: true };
      docDefinition.styles.footerStyle = { fontSize: 10, bold: true };
      return docDefinition;
    },
    exporterPdfOrientation: 'landscape',
    exporterPdfPageSize: 'LETTER',
    exporterPdfMaxGridWidth: 500,
    exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
    exporterExcelFilename: 'Appropriation_ReappropriationsOut.xlsx',
    exporterExcelSheetName: 'Sheet1',
    //Row Selection Enhancement
    enableRowSelection: true,
    enableFullRowSelection: true,
    appScopeProvider: $scope,
    rowTemplate: '<div ng-click="grid.appScope.viewreApprop(row)" ng-repeat="(colRenderIndex, col) in colContainer.renderedColumns track by col.uid" class="ui-grid-cell" ng-class="col.colIndex()" ui-grid-cell></div>',

    columnDefs: [
        { name:'Reappropriation GUID', field: 'reappropriation_guid', width: 250,pinnedLeft:false,visible:false},
        { name:'Target Appropriation Name', field: 'target_appropriation_name', width: 250, pinnedLeft:false },
        { name:'Source Fund Name', field: 'source_fund_name', width: 250,  pinnedLeft:false},
        { name:'Source Fund GUID', field: 'source_fund_guid', width: 250,  pinnedLeft:false,visible:false },
        { name:'Reappropriation Date', field: 'reappropriation_date', cellFilter: 'date:medium', width: 250,  pinnedLeft:false, sort: {
            direction: uiGridConstants.ASC,
            priority: 0,
        } },
        { name:'Transfer Amount', field: 'transfer_amount', width: 170, cellFilter:'currency', pinnedLeft:false },
        { name:'Status', field: 'status_transfer_desc', width: 170, pinnedLeft:false },
        { name:'Balance', field: 'balance', width: 125, cellFilter:'currency', pinnedLeft:false },
    ],

};

//Add New Grant Details for the reappropriation
// $scope.addGrant = function(){
//      var data={
//          "reappropriation_guid": $scope.selectedFundData.fund_guid,
//          "fund_id": $scope.selectedFundData.fund_id,
//          "fund_name": $scope.selectedFundData.fund_name,
//          "fund_description": $scope.selectedFundData.fund_description,
//          "balance":$scope.selectedFundData.balance,
//          "encumbered":$scope.selectedFundData.encumbered,
//          "spent":$scope.selectedFundData.spent
//      };
//      console.log(data);
//      UpdateFund.updatefund().update({guid:data.fund_guid},data);
//
//};


// Register the grid for API calls like clearSelectedRows() and getSelectedRows()
    $scope.gridAppropReappropOut.onRegisterApi = function(gridApiAppropsReappropOut){
        $scope.gridApiAppropsReappropOut = gridApiAppropsReappropOut;

        gridApiAppropsReappropOut.selection.on.rowSelectionChanged($scope,function(row){
            var msg = 'row selected'+row.isSelected;
            $scope.selectedRows = $scope.gridApiAppropsReappropOut.selection.getSelectedRows()[0];
            $scope.selectedguidaprop = $scope.selectedRows.appropriation_guid;
        });
    };

//// Get Appropriation Transaction details API
//$scope.getAppropReappropDetails = function() {
//     $scope.gridAppropReappropIn.data = $scope.selectedAppropReapprop;
//};
//
//// Do Initial Apropriation load
//    $scope.getAppropReappropDetails();


//Edit the Appropriation  here
    $scope.EditApprop = function(){
    var modalInstance = $uibModal.open({
        templateUrl:'views/finance/appropedit.html',
        controller:'AppropsModalCtrl',
        backdrop: 'static',
    });
    modalInstance.result.then(function (modalResponse) {
                console.log("modalResponse", modalResponse);
            }, function () {
                        $log.debug("cancelled the Appropriation  entry");
            });
    };


}])







.controller('AppropsModalCtrl', function($rootScope,$scope,$log,$state,$stateParams,$filter,$uibModalInstance,GetTransferStatus,GetAppropInfo,GetPartnerGrant,GetCompetitiveGrant,AppropDataService ,UpdateApprop,GetAppropn,GetTransactiontype,AddReapprop,GetReappropn,AddApprop,Getfund,GetProgramtype,GetGranttype,modalService,modalMessageService){




//Selected appropriation in the reappropriate
$rootScope.reapprop_source = $scope.selectedappropdetails;
//console.log($rootScope.reapprop_source);






// Selected Appropriation details
$scope.viewSelectedApprop = function(){
      AppropDataService.setSelectedApprop($scope.gridApiApprops.selection.getSelectedRows());
      $scope.selectedRows = $scope.gridApiApprops.selection.getSelectedRows()[0];
      $scope.selectedguidapprop = $scope.selectedRows.appropriation_guid;
        var appropriation_guid = $scope.selectedguidapprop;
        $location.path('/finance/appropriations/appropdetail/'+appropriation_guid);
          };

         $scope.selectedAppropData = AppropDataService.getSelectedApprop()[0];
         $scope.selectedAppropPayment = _.get($scope.selectedAppropData, 'payments');
         $scope.selectedAppropReapprop = _.get($scope.selectedAppropData, 'reappropriations');


//Reappropriations here
    var reappropriate  = GetReappropn.getreappropn().query()
      .$promise.then(
        function(response){
            $scope.reappropriatelist = response;
        });

// Transaction types here
    var transactiontypes  = GetTransactiontype.gettransactiontype().query()
          .$promise.then(
            function(response){
                $scope.transactiontypeslist = response;
            });

// Transfer Status
    var transferstatus  = GetTransferStatus.gettransferstatus().query()
      .$promise.then(
        function(response){
            $scope.transferstatuslist = response;
        });


//Selected Appropriation in edit mode
$scope.viewSelectedapprop = function(){
    if(!!$scope.selecteddataapprop && !!$scope.selecteddataapprop.appropriation_guid){
        var appropguid = $scope.selecteddataapprop.appropriation_guid;
        $scope.appropguid = $scope.selecteddataapprop;
        var appropdetailsid = GetAppropInfo.getappropinfo(appropguid).get()
                              .$promise.then(
                                function(response){
                                    $scope.selectedappropdetails = response;
                                    $scope.selectedappropdetails.appropriation_date = convertoDate($scope.selectedappropdetails.appropriation_date);
                                        $location.path('/finance/appropriations/appropdetail/'+appropguid);
                                },
                                function(err){
                                  modalMessageService.showMessage( "Error:", "Cannot go to this path location");
                                }
                             );
                }
        };

    $scope.viewSelectedapprop();
          if(!!$stateParams){
              $scope.selecteddataapprop = $stateParams;
            }




// Get Approp details grid table data from the guid
$scope.getAppropidDetails = function() {
//                loading image

                if(!!$scope.selecteddataapprop && !!$scope.selecteddataapprop.appropriation_guid){
                    var appropguid = $scope.selecteddataapprop.appropriation_guid;
                    $scope.appropguid = $scope.selecteddataapprop;
                    var appropdetailsid = GetAppropInfo.getappropinfo(appropguid).get()
                                      .$promise.then(
                                        function(response){
                                            $scope.selectedappropdetails = response;
                                            var appropdate =  $scope.selectedappropdetails.appropriation_date.split("-");

                                            $scope.selectedappropdetails.appropriation_date = new Date(appropdate[0], appropdate[1]-1, appropdate[2]);
                                           

                                        },
                                        function(err){
                                           modalMessageService.showMessage( "Error:", "An error occurred. ");
                                        }
                                     );
                        }
            };

            // Do Initial Approps   load
            $scope.getAppropidDetails();





// Get Appropriation Details here
 var appropslist = GetAppropn.getappropn().query()
      .$promise.then(
        function(response){
            $scope.appropslist = response;
        });


//Fund list
var fundrecs = Getfund.getfundlist().query()
    .$promise.then(
        function(response){
            $scope.fundslist = response;
        },
        function(response) {
            $log.debug("ERROR GETTING Funds List:", response);
            if (response.data.result === 'error' ) {
                modalMessageService.showMessage( "Error:", response.data.message);
            } else {
                modalMessageService.showMessage( "Error:", "An error occurred. ");
            }
            $log.debug("Error: "+response.status + " " + response.statusText);

        });


//Grant type list
var granttyp = GetGranttype.getgranttype().query()
    .$promise.then(
        function(response){
            $scope.granttype = response;
        },
        function(response) {
            $log.debug("ERROR GETTING Grant Type List:", response);
            if (response.data.result === 'error' ) {
                modalMessageService.showMessage( "Error:", response.data.message);
            } else {
                modalMessageService.showMessage( "Error:", "An error occurred. ");
            }
            $log.debug("Error: "+response.status + " " + response.statusText);

        });


//Program type list
    var program = GetProgramtype.getprogramtype().query()
      .$promise.then(
        function(response){
            $scope.programtypelist = response;
        },
        function(response) {
            $log.debug("ERROR GETTING Program Type List:", response);
            if ( response.data === '{ "error": "Bad Request UE" }' ) {
                modalMessageService.showMessage( "Error:", "Check the service");
            } else {
                modalMessageService.showMessage( "Error:", "An error occurred. ");
            }
            $log.debug("Error: "+response.status + " " + response.statusText);

        });


//Partner Grants list
var partnergrant = GetPartnerGrant.getpartnergrant().query()
    .$promise.then(
        function(response){
            $scope.partnergrantslist = response;
        });


//Competitive Pools list
    var comppools = GetCompetitiveGrant.getcompetitivegrant().query()
        .$promise.then(
            function(response){
                $scope.competitivegrantslist = response;
            });

$scope.close = function(){
    $uibModalInstance.dismiss();
};



// Post request for new appropriation
$scope.submitapr = function(){
    var response = {"appropriation_unit":$scope.appropunit, "year":$scope.appropyear,"program_type_guid":$scope.program_type_guid,"fund_guid":$scope.source_fund,"pl_type":$scope.pltype,"grant_type_desc":$scope.grant_type_desc.trim(),"appropriation_date":$scope.appropdate,"initial_amount":$scope.initial_amount,};
    response.appropriation_date = $filter('date')($scope.appropdate,'yyyy-MM-dd');
    AddApprop.addapprop().save(response)
    .$promise.then(
       function(response){
          console.log(response);
          $state.reload();
          $uibModalInstance.close(response);
          modalMessageService.showMessage( "Success:","Appropriation Added Successfully");
       },
       function(response) {
            $log.debug("ERROR ADDING New Appropriation:", response);
           if (response.data.result === 'error' ) {
               modalMessageService.showMessage( "Error:", response.data.message);
            } else {
                modalMessageService.showMessage( "Error:", "An error occurred. ");
            }
            $log.debug("Error: "+response.status + " " + response.statusText);
        }
    );
//     $uibModalInstance.close(response);
};



// Submit Edited Appropriation
   $scope.submitEditApprop = function(){
    var data={
      "appropriation_guid": $scope.selectedappropdetails.appropriation_guid,
      "appropriation_unit": $scope.selectedappropdetails.appropriation_unit,
      "pl_type": $scope.selectedappropdetails.pl_type,
      "appropriation_date": $scope.selectedappropdetails.appropriation_date,
    };
    data.appropriation_date = $filter('date')($scope.selectedappropdetails.appropriation_date,'yyyy-MM-dd');
    console.log(data);
    UpdateApprop.updateapprop().update({guid:data.appropriation_guid},data)
       .$promise.then(
           function(){

               modalMessageService.showMessage( "Success:","Appropriation Edited Successfully");
               $state.reload();
           },
           function(response) {
               $log.debug("ERROR Updating Approp:", response);
               if (response.data.result === 'error' ) {
                   modalMessageService.showMessage( "Error:", response.data.message);
               } else {
                   modalMessageService.showMessage( "Error:", "Unable to update appropriation.");
               }
               $log.debug("Error: "+response.status + " " + response.statusText);
           }
       );

    $state.reload();
    $uibModalInstance.dismiss();
    };



// Condition for disabling on source appropriation selection
        $scope.isDisableCompetitive = true;
        $scope.isDisableBase = true;

        $scope.sourceChange = function(){
    //                alert("Selected Source " + $scope.appropriation_source_guid.grant_type_desc);
            $scope.isDisableCompetitive = true;
            $scope.isDisableBase = true;

                    console.log($scope.appropriation_source_guid.grant_type_desc);

            if($scope.appropriation_source_guid.grant_type_desc == "BASE")
            {
                $scope.isDisableBase = false;
            }

            if ($scope.appropriation_source_guid.grant_type_desc == "COMPETITIVE")
            {
                $scope.isDisableCompetitive = false;
            }
         };



// Post request for reappropriate competitive in appropriation detail view
    $scope.submitreapcomp = function(){
          $scope.reap_guid = $scope.selectedappropdetails.appropriation_guid;
          console.log('reap_guid',$scope.reap_guid);
          var response = {"appropriation_source_guid":$scope.selectedappropdetails.appropriation_guid,"appropriation_target_guid":$scope.appropriation_target_guid,"status_transfer_desc":"PENDING","transfer_amount":$scope.transfer_amount,"note":$scope.note,"detail":$scope.grantdetail};
         AddReapprop.addarepprop().save(response)
            .$promise.then(
               function(response){
                  console.log(response);
                  $state.reload();
                  $uibModalInstance.close(response);
                  modalMessageService.showMessage( "Success:","Reappropriation Added Successfully");
               },
               function(response) {
                    $log.debug("ERROR  Reappropriation:", response);
                   if (response.data.result === 'error' ) {
                       modalMessageService.showMessage( "Error:", response.data.message);
                    } else {
                        modalMessageService.showMessage( "Error:", "Error submitting Reappropriation.");
                    }
                    $log.debug("Error: "+response.status + " " + response.statusText);
                }
          );
//         $uibModalInstance.close(response);
    };

// Post request for reappropriate competitive in appropriations home view
    $scope.submitreapcompetitive = function(){
          $scope.reap_guid = $scope.appropriation_source_guid.appropriation_guid;
          console.log('reap_guid',$scope.reap_guid);
          var response = {"appropriation_source_guid":$scope.appropriation_source_guid.appropriation_guid,"appropriation_target_guid":$scope.appropriation_target_guid,"status_transfer_desc":"PENDING","transfer_amount":$scope.transfer_amount,"note":$scope.note,"detail":$scope.grantdetail};
         AddReapprop.addarepprop().save(response)
            .$promise.then(
               function(response){
                  console.log(response);
                  $state.reload();
                  $uibModalInstance.close(response);
                  modalMessageService.showMessage( "Success:","Reappropriation Added Successfully");
               },
               function(response) {
                    $log.debug("ERROR  Reappropriation:", response);
                   if (response.data.result === 'error' ) {
                       modalMessageService.showMessage( "Error:", response.data.message);
                    } else {
                        modalMessageService.showMessage( "Error:", "Error submitting Reappropriation.");
                    }
                    $log.debug("Error: "+response.status + " " + response.statusText);
                }
          );
//         $uibModalInstance.close(response);
    };





// Post request for reappropriate
    $scope.submitreap = function(){
              $scope.reap_guid = $scope.selectedappropdetails.appropriation_guid;
              console.log('reap_guid',$scope.reap_guid);
              var response = {"appropriation_source_guid":$scope.selectedappropdetails.appropriation_guid,"appropriation_target_guid":$scope.appropriation_target_guid,"status_transfer_desc":"PENDING","transfer_amount":$scope.transfer_amount,"note":$scope.note,"detail":$scope.cpdetail};
             AddReapprop.addarepprop().save(response)
                .$promise.then(
                   function(response){
                      console.log(response);
                      $uibModalInstance.close(response);
                      modalMessageService.showMessage( "Success:","Reappropriation Added Successfully");
                   },
                   function(response) {
                        $log.debug("ERROR  Reappropriation:", response);
                       if (response.data.result === 'error' ) {
                           modalMessageService.showMessage( "Error:", response.data.message);
                        } else {
                            modalMessageService.showMessage( "Error:", "Error submitting Reappropriation.");
                        }
                        $log.debug("Error: "+response.status + " " + response.statusText);
                    }
              );
//             $uibModalInstance.close(response);
        };

// Post request for reappropriate in appropriation home view
    $scope.submitreapriate = function(){
              $scope.reap_guid = $scope.appropriation_source_guid.appropriation_guid;
              console.log('reap_guid',$scope.reap_guid);
              var response = {"appropriation_source_guid":$scope.appropriation_source_guid.appropriation_guid,"appropriation_target_guid":$scope.appropriation_target_guid,"status_transfer_desc":"PENDING","transfer_amount":$scope.transfer_amount,"note":$scope.note,"detail":$scope.cpdetail};
             AddReapprop.addarepprop().save(response)
                .$promise.then(
                   function(response){
                      console.log(response);
                      $uibModalInstance.close(response);
                      modalMessageService.showMessage( "Success:","Reappropriation Added Successfully");
                   },
                   function(response) {
                        $log.debug("ERROR  Reappropriation:", response);
                       if (response.data.result === 'error' ) {
                           modalMessageService.showMessage( "Error:", response.data.message);
                        } else {
                            modalMessageService.showMessage( "Error:", "Error submitting Reappropriation.");
                        }
                        $log.debug("Error: "+response.status + " " + response.statusText);
                    }
              );
//             $uibModalInstance.close(response);
        };



////Add New Grant Details for the reappropriation
// $scope.addGrant = function(){
//      var data={
//          "reappropriation_guid": $scope.selectedFundData.fund_guid,
//          "fund_id": $scope.selectedFundData.fund_id,
//          "fund_name": $scope.selectedFundData.fund_name,
//          "fund_description": $scope.selectedFundData.fund_description,
//          "balance":$scope.selectedFundData.balance,
//          "encumbered":$scope.selectedFundData.encumbered,
//          "spent":$scope.selectedFundData.spent
//      };
//      console.log(data);
//      UpdateFund.updatefund().update({guid:data.fund_guid},data);
//
//};



 //Appropriation details list
var appropdetail = GetAppropn.getappropn().query()
  .$promise.then(
    function(response){
        $scope.appropdetail = response;
    });



//Add competitive pool detail in the modal
    $scope.cpdetail = [];
    $scope.addPool = function(){
        $scope.cpdetail.push({competitive_pool_guid:$scope.competitive_pool_reap.competitive_pool_guid,pool_name:$scope.competitive_pool_reap.pool_name, amount:$scope.amount1,});
        console.log($scope.cpdetail);
    };
    $scope.grantdetail = [];
    $scope.addGrant = function(){
        $scope.grantdetail.push({partner_grant_guid:$scope.partner_grant_detail.partner_grant_guid,grant_name:$scope.partner_grant_detail.grant_name, amount:$scope.amount1});
        console.log($scope.grantdetail);
    };



// removing the grant row in the modal
    $scope.removePool = function(i){
    $scope.cpdetail.splice(i, 1);
    };

    $scope.removeGrant = function(i){
    $scope.grantdetail.splice(i, 1);
    };





// Date picker
    $scope.today = function() {
    $scope.dt = new Date();
    };
    $scope.today();
    $scope.dateOptions = {
    formatYear: 'yy',
    maxDate: new Date(2070, 5, 22),
    startingDay: 1
    };
    $scope.open1 = function() {
    $scope.popup1.opened = true;
    };


    $scope.setDate = function(year, month, day) {
    $scope.dt = new Date(year, month, day);
    };

    $scope.clear = function() {
    $scope.dt = null;
    };
    $scope.formats = ['dd-MMM-yyyy', 'yyyy-mm-dd', 'dd.MM.yyyy', 'shortDate'];
    $scope.format = $scope.formats[1];
    $scope.altInputFormats = ['M!/d!/yyyy'];

    $scope.popup1 = {
    opened: false
    };

    $scope.popup2 = {
    opened: false
    };

    var tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    var afterTomorrow = new Date();
    afterTomorrow.setDate(tomorrow.getDate() + 1);
    $scope.events = [
    {
      date: tomorrow,
      status: 'full'
    },
    {
      date: afterTomorrow,
      status: 'full'
    }
    ];

});
