(function () {
    'use strict';
}());

angular.module('agSADCeFarms')
    .controller('FinanceBaseController',function($scope) {
        $scope.toggleCollapse = false;
    });


angular.module('agSADCeFarms')
    .controller('FinanceController', ['$scope','$stateParams','$location','$filter', '$uibModal','GetTransferStatus','DeleteFund','GetReapproprData','UpdateExpense','DeletePool','DeleteGrant','DeletePayment','DeleteExpense','FundDataService','AppropDataService','PartnerDataService','PoolDataService','ReappropDataService','ExpensePayDataService','PaymentDataService','GetAppropn','UpdateApprop','UpdateReapprop','DeleteAppropriation','GetRelatedappropn','GetTransactiontype','GetReappropn','DeleteReappropn','GetExpense','GetPayment','GetPaymentSource','GetPartnerGrant','AddPartnerGrant','AddCompetitivePool','GetPaymentsHistory','GetAppropPayHistory','GetProgramtype','GetGranttype','AddFund','UpdateFund','UpdatePayment','AddApprop','GetCompetitiveGrant','ExpenseDataService','GetPaymentInfo','GetExpenseData','GetPartner','GetPayStatus','AddPayment','$state', '$log','modalService','modalMessageService', function($scope,$stateParams,$location,$filter,$uibModal,GetTransferStatus,DeleteFund,GetReapproprData,UpdateExpense,DeletePool,DeleteGrant,DeletePayment,DeleteExpense,FundDataService,AppropDataService,PartnerDataService,PoolDataService,ReappropDataService,ExpensePayDataService,PaymentDataService,GetAppropn,UpdateApprop,UpdateReapprop,DeleteAppropriation,GetRelatedappropn,GetTransactiontype,GetReappropn,DeleteReappropn,GetExpense,GetPayment,GetPaymentSource,GetPartnerGrant,AddPartnerGrant,AddCompetitivePool,GetPaymentsHistory,GetAppropPayHistory,GetProgramtype,GetGranttype,AddFund,UpdateFund,UpdatePayment,AddApprop,GetCompetitiveGrant,ExpenseDataService,GetPaymentInfo,GetExpenseData,GetPartner,GetPayStatus,AddPayment,$state,$log,modalService,modalMessageService) {




// Reappropriations  Details
    $scope.viewSelectedReapprop = function(){
      ReappropDataService.setSelectedReapprop($scope.gridApiReapprops.selection.getSelectedRows());
      $scope.selectedRows = $scope.gridApiReapprops.selection.getSelectedRows()[0];
      $scope.selectedguidreapprop = $scope.selectedRows.reappropriation_guid;
        var reappropriation_guid = $scope.selectedguidreapprop;
        $location.path('/finance/reappropriations/reappropdetails/'+reappropriation_guid);
    };

     $scope.selectedReappropData = ReappropDataService.getSelectedReapprop()[0];
     $scope.selectedReappropDetails = _.get($scope.selectedReappropData, 'detail');
     if(!!$stateParams){
      $scope.selecteddataexpense = $stateParams;
    }



//Expenses  Details
    $scope.viewSelectedExpense = function(){
    if(!!$scope.selecteddataexpense && !!$scope.selecteddataexpense.expense_guid){
        var expguid = $scope.selecteddataexpense.expense_guid;
        $scope.expguid = $scope.selecteddataexpense.expense_guid;
    //                        console.log($scope.expguid);
        var expensedetailsid = GetExpenseData.getexpensedata(expguid).get()
                              .$promise.then(
                                function(response){

                                    $scope.selectedexpensedetails = response;
//                                    console.log($scope.selectedexpensedetails);
                                    $location.path('/finance/expenses/expensedetail/'+expguid);
                                },
                                function(err){
                                  alert("Service error");
                                }
                             );
        }
    };
    $scope.viewSelectedExpense();
    $scope.selectedExpenseData = ExpenseDataService.getSelectedExpense()[0];
    $scope.selectedExpensePayment = _.get($scope.selectedExpenseData, 'expense_payments');
    $scope.selectedExpenseCostshare = _.get($scope.selectedExpenseData, 'cost_share_json');




// Selected Payment details based on the guid
    $scope.viewSelectedPaymentd = function(){
        if(!!$stateParams){
            $scope.selecteddatapayment = $stateParams;
        }
    if(!!$scope.selecteddatapayment && !!$scope.selecteddatapayment.expense_payment_guid){
                        var paymentguid = $scope.selecteddatapayment.expense_payment_guid;
                        $scope.paymentguid = $scope.selecteddatapayment;
                        var paymentdetailsid = GetPaymentInfo.getpaymentinfo(paymentguid).get()
                                              .$promise.then(
                                                function(response){

                                                    $scope.selectedpaymentdetails = response;
                                                        $location.path('/finance/payments/paymentdetail/'+paymentguid);
                                                },
                                                function(err){
                                                  modalMessageService.showMessage( "Error:", "Cannot go to this path location");
                                                }
                                             );
                }
        };
    $scope.viewSelectedPaymentd();

      if(!!$stateParams){
          $scope.selecteddatapayment = $stateParams;
        }


// Selected Expense data
    $scope.viewSelectedExp = function(){
      ExpenseDataService.setSelectedExpense($scope.gridApiExpenses.selection.getSelectedRows());
      $scope.selectedRows = $scope.gridApiExpenses.selection.getSelectedRows()[0];
      $scope.selectedguidexpense = $scope.selectedRows.expense_guid;
        var expense_guid = $scope.selectedguidexpense;
        console.log("here2");
        $location.path('/finance/expenses/expensedetail/'+expense_guid);
    };


//Expenses Payment Details
    $scope.viewSelectedExpensePayment = function(){
      ExpensePayDataService.setSelectedExpensePay($scope.gridApiExpensePayments.selection.getSelectedRows());
      $scope.selectedRows = $scope.gridApiExpensePayments.selection.getSelectedRows()[0];
      $scope.selectedguidpayment = $scope.selectedRows.expense_payment_guid;
      var expense_payment_guid = $scope.selectedguidpayment;
      $location.path('/finance/payments/paymentdetail/'+expense_payment_guid);
  };
     $scope.selectedExpensePayData = ExpensePayDataService.getSelectedExpensePay()[0];



//Payments  Details
    $scope.viewSelectedPayment = function(){
      PaymentDataService.setSelectedPayment($scope.gridApiPayments.selection.getSelectedRows());
      $scope.selectedRows = $scope.gridApiPayments.selection.getSelectedRows()[0];
      $scope.selectedguidpayment = $scope.selectedRows.expense_payment_guid;
      var expense_payment_guid = $scope.selectedguidpayment;
      $location.path('/finance/payments/paymentdetail/'+expense_payment_guid);

    };
     $scope.selectedPaymentData = PaymentDataService.getSelectedPayment()[0];



// Selected Payment Expense details
   $scope.ViewSelectedPayExpense = function(){
        var expense_guid = $scope.selectedpaymentdetails.expense_guid;
        console.log("selected expense", expense_guid);
        $location.path('/finance/expenses/expensedetail/'+expense_guid);
  };


// Selected Payment Reappropriation details
   $scope.ViewSelectedPayReapprop = function(){
        var reappropriation_guid = $scope.selectedpaymentdetails.reappropriation_guid;
        console.log("selected reappropriation guid", reappropriation_guid);
        $location.path('/finance/reappropriations/reappropdetails/'+reappropriation_guid);
  };


// Add New Payment in track expense
     $scope.openTrackExpenseModal = function() {
         var modalInstance = $uibModal.open({
            templateUrl:'views/finance/trackexpensenewpayment.html',
            controller:'FundsModalInstanceCtrl',
            backdrop: 'static',
             resolve: {
                 fundtransitems: function () {
                     return null;
                 },
             },

          });
            modalInstance.result.then(function (modalResponse) {
                    console.log("modalResponse", modalResponse);
                }, function () {
                            $log.debug("cancelled the Payments entry");
                });
    };



//Edit the Payment  here
    $scope.EditPayment = function(){
    var modalInstance = $uibModal.open({
        templateUrl:'views/finance/paymentedit.html',
        controller:'FundsModalInstanceCtrl',
        backdrop: 'static',
        resolve: {
            fundtransitems: function () {
                return null;
            },
        },
    });
    modalInstance.result.then(function (modalResponse) {
                console.log("modalResponse", modalResponse);
            }, function () {
                        $log.debug("cancelled the Payment entry");
            });
    };





// Transfer Status
    var transferstatus  = GetTransferStatus.gettransferstatus().query()
      .$promise.then(
        function(response){
            $scope.transferstatuslist = response;
        });




// Submit Payment
    $scope.submitEditPayment = function(){
    if($scope.editable == true){
      var data={
          "expense_payment_guid": $scope.selectedReappropData.reappropriation_guid,
          "payment_amount": $scope.selectedReappropData.reappropriation_date,
          "payment_comment":$scope.selectedReappropData.status_transfer_desc,
      };
      console.log(data);
      UpdatePayment.updatepayment().update({guid:data.expense_payment_guid},data);
      $state.reload();
      }
    };




// Selected Pool/Grant row from the reappropriation table
   $scope.selectedCompetitiveGrant = GetCompetitiveGrant.getCompetitiveGrant();
     $scope.selectPoolReapprop = function(i){
        $scope.selectedIndex = i;
        $scope.selectedCompetitiveGrant = $scope.competitivegrantslist[i];
        GetCompetitiveGrant.setCompetitiveGrant($scope.competitivegrantslist[i]);
        $scope.isDisabled = false;
     };


// Expenses Payments details
//$scope.gridExpensePayments = {
//            enableSorting :true,
//            enablePaginationControls: true,
//            paginationPageSize: 25,
//            enableFiltering: true,
//            saveSelection: true,
//            enableRowHeaderSelection: true,
//            selectionRowHeaderWidth: 50,
//            multiSelect: false,
//            rowHeight: 35,
//            showGridFooter:false,
//            selectedItems: [],
//            enableGridMenu: true,
//            exporterCsvFilename: 'Expenses.csv',
//            exporterPdfDefaultStyle: {fontSize: 12},
//            exporterPdfTableStyle: {margin: [30, 30, 30, 30]},
//            exporterPdfTableHeaderStyle: {fontSize: 12, bold: true, italics: true, color: 'black'},
//            exporterPdfHeader: { text: "Expense Details", style: 'headerStyle' },
//            exporterPdfFooter: function ( currentPage, pageCount ) {
//              return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' };
//            },
//            exporterPdfCustomFormatter: function ( docDefinition ) {
//              docDefinition.styles.headerStyle = { fontSize: 22, bold: true };
//              docDefinition.styles.footerStyle = { fontSize: 10, bold: true };
//              return docDefinition;
//            },
//            exporterPdfOrientation: 'landscape',
//            exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
//            exporterExcelFilename: 'Expenses.xlsx',
//            exporterExcelSheetName: 'Sheet1',
//            enableRowSelection: true,
//            enableFullRowSelection: true,
//            appScopeProvider: $scope,
//            rowTemplate: '<div ng-click="grid.appScope.viewselPay(row)" ng-repeat="(colRenderIndex, col) in colContainer.renderedColumns track by col.uid" class="ui-grid-cell" ng-class="col.colIndex()" ui-grid-cell></div>',
//
//            columnDefs: [
//                  { name:'Payment Amount', field: 'payment_amount', width: 300,cellFilter:'currency', pinnedLeft:false},
//                  { name:'Payment Source', field: 'payment_source_type', width: 170,  pinnedLeft:false},
//                  { name:'Payment Status', field: 'payment_status_desc', width: 170,  pinnedLeft:false},
//                  { name:'Payment Comment', field: 'payment_comment', width: 250,  pinnedLeft:false },
//                  { name:'Appropriation', field: 'appropriation_name', width: 250,pinnedLeft:false },
//                  { name:'From Reappropriation', field: 'reapprop_flag', width: 170, pinnedLeft:false},
//                  { name:'Activity Code', field: 'activity_code', width: 170, pinnedLeft:false},
//                  { name:'Object Code', field: 'object_code', width: 170,  pinnedLeft:false},
//                  { name:'Vendor Code', field: 'vendor_code', width: 170,  pinnedLeft:false},
//                  { name:'Vendor Name', field: 'vendor_name', width: 170,  pinnedLeft:false},
//        ],
//
////    };
//        $scope.viewselPay = function(row) {
//            var itemguid = row.entity.expense_payment_guid;
//            if (itemguid) {
//                $location.path('/finance/payments/paymentdetail/'+itemguid);
//            }
//        };
//
//
//
//
//// Register the grid for API calls like clearSelectedRows() and getSelectedRows()
//    $scope.gridExpensePayments.onRegisterApi = function(gridApiExpensePayments){
//        $scope.gridApiExpensePayments = gridApiExpensePayments;
//        gridApiExpensePayments.selection.on.rowSelectionChanged($scope,function(row){
//        var msg = 'row selected'+row.isSelected;
//         $scope.selectedRows = $scope.gridApiExpensePayments.selection.getSelectedRows()[0];
//         $scope.selectedguidreapprops = $scope.selectedRows.reappropriation_guid;
//        });
//    };

//
//
// Expense Payments grid table data from the guid
$scope.gridExpenseCostshareDetails = function() {

        if(!!$scope.selecteddataexpense && !!$scope.selecteddataexpense.expense_guid){
        var expguid = $scope.selecteddataexpense.expense_guid;
        $scope.expguid = $scope.selecteddataexpense.expense_guid;
        var expensedetailsid = GetExpenseData.getexpensedata(expguid).get()
                              .$promise.then(
                                function(response){
                                    $scope.selectedexpensedetails = response;
                                    $scope.selecteddatapaymentexpense = _.get($scope.selectedexpensedetails, 'expense_payments');
                                    $scope.gridExpensePayments.data = $scope.selecteddatapaymentexpense;

                                },
                                function(err){
                                  alert("error");
                                }
                             );
        }
        };

            // Do Initial Cost share   load
            $scope.gridExpenseCostshareDetails();




// Payment Details
$scope.gridPayments = {
            enableSorting :true,
            enablePaginationControls: true,
            paginationPageSize: 25,
            enableFiltering: true,
            saveSelection: true,
            enableRowHeaderSelection: true,
            selectionRowHeaderWidth: 50,
            multiSelect: false,
            rowHeight: 35,
            showGridFooter:false,
            selectedItems: [],

            enableRowSelection: true,
            enableFullRowSelection: true,
            appScopeProvider: $scope,
            rowTemplate: '<div ng-click="grid.appScope.viewpaydet(row)" ng-repeat="(colRenderIndex, col) in colContainer.renderedColumns track by col.uid" class="ui-grid-cell" ng-class="col.colIndex()" ui-grid-cell></div>',

            columnDefs: [
                  { name:'Expense Type', field: 'expense_type', width: 200,  pinnedLeft:false},
                  { name:'Payment Source', field: 'payment_source_type', width: 200, pinnedLeft:false },
                  { name:'Payment Source Desc', field: 'payment_source_desc', width: 200, pinnedLeft:false },
                  { name:'Payment Amount', field: 'payment_amount', width: 200, cellFilter:'currency', pinnedLeft:false },
                  { name:'Payment Status', field: 'payment_status_desc', width: 250,  pinnedLeft:false},
                  { name:'Appropriation', field: 'appropriation_name', width: 250, pinnedLeft:false},
                  { name:'From Reappropriation', field: 'reapprop_flag', width: 250,  pinnedLeft:false },
                  { name:'Activity Code', field: 'activity_code', width: 170, pinnedLeft:false},
                  { name:'Object Code', field: 'object_code', width: 170,  pinnedLeft:false},
                  { name:'Vendor Code', field: 'vendor_code', width: 170,  pinnedLeft:false},
                  { name:'Vendor Name', field: 'vendor_name', width: 170,  pinnedLeft:false},
                  { name:'Farm Name', field: 'farm_name', width: 250, pinnedLeft:false },
                  { name:'Farm ID', field: 'farm_id', width: 200,  pinnedLeft:false },
                  { name:'Application ID', field: 'application_id', width: 200, pinnedLeft:false },
                  { name:'Created Date', field: 'created_date', type:'date',cellFilter: 'date:medium',width: 250,  pinnedLeft:false },
                  { name:'Paid Date', field: 'paid_date', type:'date',cellFilter: 'date:medium',width: 200, pinnedLeft:false },

        ],

    };

    $scope.viewpaydet = function(row) {
        var itemguid = row.entity.expense_payment_guid;
        if (itemguid) {

            $location.path('/finance/payments/paymentdetail/'+itemguid);
        }
    };


// Register the grid for API calls like clearSelectedRows() and getSelectedRows()
    $scope.gridPayments.onRegisterApi = function(gridApiPayments){
        $scope.gridApiPayments = gridApiPayments;
        gridApiPayments.selection.on.rowSelectionChanged($scope,function(row){
        var msg = 'row selected'+row.isSelected;
         $scope.selectedRows = $scope.gridApiPayments.selection.getSelectedRows()[0];
         $scope.selectedguidpayment = $scope.selectedRows.expense_payment_guid;
        });
    };




// Get Payment details  from service
$scope.getPaymentDetails = function() {
    GetPayment.getpayment().query()
        .$promise.then(
        function(response){
            $scope.paymentdetails = response;
            $scope.gridPayments.data = response;
            $log.debug("gridPayments.data:",$scope.gridPayments.data );
        },
        function(response) {
            // If there is an error getting user statuses from datbase,
            // this will have an error as well.  If so, put the message in the error modal.
            $log.debug("AFTER GETING ERROR FROM DETAILS:", $scope.paymentdetails);
            $log.debug("Error: "+response.status + " " + response.statusText);
            modalMessageService.showMessage( "Error:", response.status + " " +
                response.statusText + '. Please contact ' + agSupportEmail);
        }
    );
};

// Do Initial Payment   load
 $scope.getPaymentDetails();




//
//// Delete Reappropriation in the make payment modal
//    $scope.deleteTrackexp = function(){
//            $scope.reapid = $scope.selectedPayReap.reappropriation_guid;
//            console.log('delete expenseid:',$scope.reapid);
//             var modalOptions = {
//            closeButtonText: 'No',
//            actionButtonText: 'Yes',
//            headerText: 'Warning',
//            bodyText: 'Are you sure you want to delete this item?'
//         };
//             modalService.showModal({}, modalOptions)
//                .then(function (result) {
//             DeleteExpense.deleteexpense().delete({reappropriation_guid:$scope.reapid})
//                .$promise.then(
//                   function(){
//                      modalMessageService.showMessage( "Success:","Expense deleted Successfully");
//                      //console.log("Deleted from server");
//                      $state.reload();
//                   },
//                   function(response) {
//                        $log.debug("ERROR Deleting Expense:", response);
//                       if (response.data.result === 'error' ) {
//                           modalMessageService.showMessage( "Error:", response.data.message);
//                        } else {
//                            modalMessageService.showMessage( "Error:", "This Expense cannot be deleted.");
//                        }
//                        $log.debug("Error: "+response.status + " " + response.statusText);
//                    }
//              );
//               });
//        };
//


// Delete Payments in the expense details
    $scope.deletePayment = function(){
            $scope.currentselectedpayment = getPaymentSelection();
            $scope.delpayid =   Object.values($scope.currentselectedpayment.selectedPayment)[0];
            $scope.payguid = $scope.delpayid.expense_payment_guid;

                var modalOptions = {
                closeButtonText: 'No',
                actionButtonText: 'Yes',
                headerText: 'Warning',
                bodyText: 'Are you sure you want to delete this item?'
                    };
                 modalService.showModal({}, modalOptions)
                    .then(function (result) {
             DeletePayment.deletepayment().delete({expense_payment_guid:$scope.payguid})
                .$promise.then(
                   function(){
                      modalMessageService.showMessage( "Success:","Payment deleted Successfully");
                      console.log("Deleted from server");
                      $state.reload();
                   },
                   function(response) {
                        $log.debug("ERROR Deleting Payment:", response);
                       if (response.data.result === 'error' ) {
                           modalMessageService.showMessage( "Error:", response.data.message);
                        } else {
                            modalMessageService.showMessage( "Error:", "This Payment cannot be deleted.");
                        }
                        $log.debug("Error: "+response.status + " " + response.statusText);
                    }
              );
            });
        };



 //Payment Source Details
var paymentsourcedetail = GetPaymentSource.getpaymentsource().query()
  .$promise.then(
    function(response){
        $scope.paymentsourcelist = response;
    });


// Selected Payment
      var getPaymentSelection = function(){
            var selectedRows = $scope.gridApiPayments.selection.getSelectedRows();
             var paymentSelection = { selectedPayment: {}};
            angular.forEach( selectedRows, function(row){
                var expense_payment_guid = row.expense_payment_guid;

                paymentSelection.selectedPayment[expense_payment_guid] = row;

            });
            $log.debug("Payment Details:", paymentSelection);
            return paymentSelection;

        };


//Partner Grants list
var partnergrant = GetPartnerGrant.getpartnergrant().query()
  .$promise.then(
    function(response){
        $scope.partnergrantslist = response;
    });



//Grant type list
    var grant = GetGranttype.getgranttype().query()
      .$promise.then(
        function(response){
            $scope.granttype = response;
        },
        function(response) {
            $log.debug("ERROR GETTING Grants List:", response);
            if (response.data.result === 'error' ) {
                modalMessageService.showMessage( "Error:", response.data.message);
            } else {
                modalMessageService.showMessage( "Error:", "An error occurred. ");
            }
            $log.debug("Error: "+response.status + " " + response.statusText);

        }
     );


// Appropriation  is made editable
      $scope.editable = false;

       $scope.EditApprop = function(){
       $scope.editable = true;
       };

}])


.controller('FundsModalInstanceCtrl', function(fundtransitems,$scope,$log,$location,$state,$filter,$stateParams,FundDataService,$uibModalInstance,UpdateExpense,GetReapproprData,GetPaymentSource,PaymentDataService,DeletePayment,GetExpenseData,ExpenseDataService,ReappropDataService,AddPayment,GetPartner,Getfund,UpdateFund,UpdateReapprop,GetTransferStatus,UpdatePayment,GetAppropn,GetTransactiontype,GetExpensetype,GetPayStatus,GetExpensestatus,AddTrans,AddReapprop,GetPartnerGrant,GetCompetitiveGrant,GetReappropn, AddFund, AddApprop,AddPartnerGrant,AddCompetitivePool,ExpPayDataService,AddExpense,GetProgramtype,GetGranttype,GetPaymentInfo,modalService,modalMessageService){



//Competitive Grant
var competitivegrant = GetCompetitiveGrant.getcompetitivegrant().query()
  .$promise.then(
    function(response){
        $scope.competitivegrantslist = response;
    });


 //Competitive Grant
var appropdetail = GetAppropn.getappropn().query()
  .$promise.then(
    function(response){
        $scope.appropdetail = response;
    });

 //Payment Source Details
var paymentsourcedetail = GetPaymentSource.getpaymentsource().query()
  .$promise.then(
    function(response){
        $scope.paymentsourcelist = response;
    });




//Reappropriation based on guid Details
    $scope.viewSelectedReappropriation = function(){
    if(!!$scope.selecteddatareapprop && !!$scope.selecteddatareapprop.reappropriation_guid){
        var reappropguid = $scope.selecteddatareapprop.reappropriation_guid;
        var reappropriationdetailsid = GetReapproprData.getreappropdata(reappropguid).get()
                              .$promise.then(
                                function(response){

                                    $scope.selectedreapppropdetails = response;

                                    $location.path('/finance/reappropriations/reappropdetails/'+reappropriation_guid);
                                },
                                function(err){
                                  alert("error");
                                }
                             );
    }
    };
    $scope.viewSelectedReappropriation();
  if(!!$stateParams){
              $scope.selecteddataexpense = $stateParams;
            }




//Reappropriations here
var reappropriate  = GetReappropn.getreappropn().query()
  .$promise.then(
    function(response){
        $scope.reappropriatelist = response;
    });


//Partner Grants list
var partnergrant = GetPartnerGrant.getpartnergrant().query()
  .$promise.then(
    function(response){
        $scope.partnergrantslist = response;
    });


//Payment Status list
var paystatuslist = GetPayStatus.getpaystatus().query()
  .$promise.then(
    function(response){
        $scope.paystatuslist = response;
    });


// Get Expense Types
 var expensetype = GetExpensetype.getexpensetype().query()
      .$promise.then(
        function(response){
            $scope.expensetypelist = response;
        });


    $scope.viewselExp = function(row) {
        console.log('FROM FINANCE CONTROLLER');
        var itemguid = row.entity.expense_guid;
        if (itemguid) {
            console.log("here6");
            $location.path('/finance/expenses/expensedetail/'+itemguid);
        }
    };




// Get Appropriation Details here
 var appropslist = GetAppropn.getappropn().query()
      .$promise.then(
        function(response){
            $scope.appropslist = response;
        });


 // Get Partner List
 var partnerlist = GetPartner.getpartner().query()
      .$promise.then(
        function(response){
            $scope.partnerlist = response;
        });



//Grant type list
 var grant = GetGranttype.getgranttype().query()
      .$promise.then(
        function(response){
            $scope.granttype = response;
        },
        function(response) {
            $log.debug("ERROR GETTING Grants List:", response);
            if (response.data.result === 'error' ) {
                modalMessageService.showMessage( "Error:", response.data.message);
            } else {
                modalMessageService.showMessage( "Error:", "An error occurred. ");
            }
            $log.debug("Error: "+response.status + " " + response.statusText);
        }
     );


//Expenses  Details
     $scope.viewSelectedExpense = function(){
        if(!!$scope.selecteddataexpense && !!$scope.selecteddataexpense.expense_guid){
            var expguid = $scope.selecteddataexpense.expense_guid;
            $scope.expguid = $scope.selecteddataexpense.expense_guid;
            var expensedetailsid = GetExpenseData.getexpensedata(expguid).get()
                                  .$promise.then(
                                    function(response){
                                        $scope.selectedexpensedetails = response;
//                                        console.log("exp details",$scope.selectedexpensedetails);

                                        $location.path('/finance/expenses/expensedetail/'+expguid);
                                    },
                                    function(err){
                                      alert("error");
                                    }
                                 );
        }
        };
        $scope.viewSelectedExpense();

             $scope.selectedExpenseData = ExpenseDataService.getSelectedExpense()[0];
             //console.log("selected exp guid", $scope.expguid);
              $scope.selectedExpensePayment = _.get($scope.selectedExpenseData, 'expense_payments');
              $scope.selectedExpenseCostshare = _.get($scope.selectedExpenseData, 'cost_share_json');






//
// Reappropriated Money Available
$scope.gridReapPay = {
            enableSorting :true,
            enableFiltering: true,
            saveSelection: true,
            enableRowHeaderSelection: true,
            selectionRowHeaderWidth: 50,
            multiSelect: false,
            rowHeight: 35,
            showGridFooter:false,
            selectedItems: [],
            columnDefs: [
                  { name:'Reappropriation', field: 'reappropriation_guid', width: 200, pinnedLeft:false,},
                  { name:'Source Appropriation', field: 'source_appropriation_name', width: 200,  pinnedLeft:false },
                  { name:'Balance', field: 'balance', width: 250,  cellFilter:'currency', pinnedLeft:false},
        ],

    };


// Get  Payment Reappropriation details API
    $scope.getReapDetails = function() {
            // Display loading image while fetching data
//             $scope.loading_data = true;
             $scope.gridReapPay.data = [];//$scope.source_appropriation;
        };


// Do Initial User load
  $scope.getReapDetails();



// Get Expense Status
 var expensestatus = GetExpensestatus.getexpensestatus().query()
      .$promise.then(
        function(response){
            $scope.expenseststatuslist = response;
        });


// Transaction types here
var transactiontypes  = GetTransactiontype.gettransactiontype().query()
      .$promise.then(
        function(response){
            $scope.transactiontypeslist = response;
        });


// Transfer Status
 var transferstatus  = GetTransferStatus.gettransferstatus().query()
      .$promise.then(
        function(response){
            $scope.transferstatuslist = response;
        });

$scope.refresh = $scope.funddetails;



// Payment Drop down
$scope.payment_options = [
    {
        "payment_status_desc": "PENDING"
    },
    {
        "payment_status_desc": "ENCUMBERED"
    },
    {
        "payment_status_desc": "PAID"
    },
];




//Grant type list
    var granttyp = GetGranttype.getgranttype().query()
    .$promise.then(
        function(response){
            $scope.granttype = response;
        },
        function(response) {
            $log.debug("ERROR GETTING Grant Type List:", response);
            if (response.data.result === 'error' ) {
                modalMessageService.showMessage( "Error:", response.data.message);
            } else {
                modalMessageService.showMessage( "Error:", "An error occurred. ");
            }
            $log.debug("Error: "+response.status + " " + response.statusText);

        });



//Program type list
var program = GetProgramtype.getprogramtype().query()
  .$promise.then(
    function(response){
        $scope.programtypelist = response;
    },
    function(response) {
        $log.debug("ERROR GETTING Program Type List:", response);
        if (response.data.result === 'error' ) {
            modalMessageService.showMessage( "Error:", response.data.message);
        } else {
            modalMessageService.showMessage( "Error:", "An error occurred. ");
        }
        $log.debug("Error: "+response.status + " " + response.statusText);
    }
 );

$scope.close = function(){

    $uibModalInstance.dismiss();
};



// Reappropriations  Details
    $scope.viewSelectedReapprop = function(){
      ReappropDataService.setSelectedReapprop($scope.gridApiReapprops.selection.getSelectedRows());
      $scope.selectedRows = $scope.gridApiReapprops.selection.getSelectedRows()[0];
      $scope.selectedguidreapprop = $scope.selectedRows.reappropriation_guid;
        var reappropriation_guid = $scope.selectedguidreapprop;
        $location.path('/finance/reappropdetails/'+reappropriation_guid);
    };
     $scope.selectedReappropData = ReappropDataService.getSelectedReapprop()[0];
     $scope.selectedReappropDetails = _.get($scope.selectedReappropData, 'detail');




// Submit Edited Reapprop
    $scope.submitEditReapprop = function(){
      var data={
          "reappropriation_guid": $scope.selectedReappropData.reappropriation_guid,
          "reappropriation_date": $scope.selectedReappropData.reappropriation_date,
          "status_transfer_desc":$scope.selectedReappropData.status_transfer_desc,
          "note":$scope.selectedReappropData.note
      };
      console.log(data);
      UpdateReapprop.updatereapprop().update({guid:data.reappropriation_guid},data);
     $state.reload();
     $uibModalInstance.dismiss();
     modalMessageService.showMessage( "Success:","Reappropriation Edited Successfully");
    };



// Payments  Details
    $scope.viewSelectedPayment = function(){
      PaymentDataService.setSelectedPayment($scope.gridApiPayments.selection.getSelectedRows());
      $scope.selectedRows = $scope.gridApiPayments.selection.getSelectedRows()[0];
      $scope.selectedguidpayment = $scope.selectedRows.expense_payment_guid;
      var expense_payment_guid = $scope.selectedguidpayment;
      $location.path('/finance/payments/paymentdetail/'+expense_payment_guid);

    };


    $scope.viewSelectedPaymentd = function(){
        console.log('modalinstancectrl-viewSelectedPaymentd');
        if(!!$stateParams){
            $scope.selecteddatapayment = $stateParams;
        }
        if(!!$scope.selecteddatapayment && !!$scope.selecteddatapayment.expense_payment_guid){
            var paymentguid = $scope.selecteddatapayment.expense_payment_guid;
            $scope.paymentguid = $scope.selecteddatapayment;
            var paymentdetailsid = GetPaymentInfo.getpaymentinfo(paymentguid).get()
                .$promise.then(
                    function(response){

                        $scope.selectedpaymentdetails = response;
                        console.log('paymentdetails',$scope.selectedpaymentdetails);
                    },
                    function(err){
                        $scope.selectedpaymentdetails = null;
                    }
                );
        }
    };
    $scope.viewSelectedPaymentd();

    if(!!$stateParams){
        $scope.selecteddatapayment = $stateParams;
    }




// PUT request for  Edit Payment
    $scope.submitEditPayment = function(){
      var data={
          "expense_payment_guid": $scope.selectedpaymentdetails.expense_payment_guid,
          "payment_amount": $scope.selectedpaymentdetails.payment_amount,
          "payment_comment":$scope.selectedpaymentdetails.payment_comment,
          "payment_status_desc":$scope.selectedpaymentdetails.payment_status_desc || null,
          "payment_source_desc":$scope.selectedpaymentdetails.payment_source_desc,
          "activity_code":$scope.selectedpaymentdetails.activity_code || null,
          "object_code":$scope.selectedpaymentdetails.object_code || null,
          "vendor_code":$scope.selectedpaymentdetails.vendor_code || null,
          "vendor_name":$scope.selectedpaymentdetails.vendor_name || null,
      };

      UpdatePayment.updatepayment().update({guid:data.expense_payment_guid},data);
      $state.reload();
      $uibModalInstance.dismiss();
      modalMessageService.showMessage( "Success:","Payment Edited Successfully");
    };



// Selected Expense Payment reappropriation selected row here

    $scope.gridReapPay.onRegisterApi = function(gridApiReapPay){
        $scope.gridApiReapPay = gridApiReapPay;

        gridApiReapPay.selection.on.rowSelectionChanged($scope,function(row){
        var msg = 'row selected'+row.isSelected;
         $scope.selectedRows = $scope.gridApiReapPay.selection.getSelectedRows()[0];
         $scope.selectedguidreap = $scope.selectedRows.reappropriation_guid;
          console.log($scope.selectedguidreap);
        });
    };

    //Grid Reap Pay Data
        //if ($scope.source_appropriation){
            $scope.$watch('source_appropriation', function(){
                //console.log('HELLO!',$scope.source_appropriation);
                $scope.gridReapPay.data  = $scope.source_appropriation.reappropriated_in;
                setTimeout(function(){
                    $scope.$apply();
                },10);
            });
        //}





    // Post request for new Expense Payment (SADC)
    $scope.submitpayexp = function(){

        if (!$scope.grant_type && !$scope.pool_type){
          return false;
        }

        var response = {
          "expense_guid":$scope.selectedexpensedetails.expense_guid, //$scope.selectedguidexp,
          "partner_guid":$scope.partner_guid,
          "payment_source_type":$scope.payment_source_type,
          "payment_source_desc":$scope.payment_source_desc,
          "partner_grant_guid": (!!$scope.grant_type && !!$scope.grant_type.partner_grant_guid)? $scope.grant_type.partner_grant_guid : null,
          "competitive_pool_guid": (!!$scope.pool_type && !!$scope.pool_type.competitive_pool_guid) ? $scope.pool_type.competitive_pool_guid : null,
          "appropriation_guid":$scope.source_appropriation.appropriation_guid,
          "reappropriation_guid":$scope.selectedguidreap || null,
          "payment_amount":$scope.payment_amount,
          "payment_status_desc":$scope.payment_status.trim(),
          "payment_comment":$scope.payment_comment,
          "object_code":$scope.object_code,
          "activity_code":$scope.activity_code,
          "vendor_code":$scope.vendor_code,
          "vendor_name":$scope.vendor_name,
          "partner_flg":$scope.charge_partner
        };
        console.log('Part1',response);
        AddPayment.addpayment().save(response)
        .$promise.then(
           function(res){
              console.log(res);
              $state.reload();
              $uibModalInstance.close(response);
              modalMessageService.showMessage( "Success:","Added Payment Successfully");
           },
           function(response) {
                $log.debug("ERROR ADDING New Expense Payments:", response);
                if (response.data.result === 'error' ) {
                    modalMessageService.showMessage( "Error:", response.data.message);
                } else {
                    modalMessageService.showMessage( "Error:", "Parameters not set correct ");
                }
                $log.debug("Error: "+response.status + " " + response.statusText);
            }
        );
//        $uibModalInstance.close(response);
    };



    // Post request for new Expense Payment  (GRANT or OTHER-> Non SADC)
    $scope.submitexppay = function(){
        var response = {
          "expense_guid":$scope.selectedexpensedetails.expense_guid,
          "payment_source_type":$scope.payment_source_type.trim(),
          "payment_source_desc":$scope.payment_source_desc,
          "payment_amount":$scope.payment_amount,
           "payment_comment":$scope.payment_comment
//          "partner_grant_guid": (!!$scope.grant_type && !!$scope.grant_type.partner_grant_guid)? $scope.grant_type.partner_grant_guid : null,
//          "competitive_pool_guid": (!!$scope.pool_type && !!$scope.pool_type.competitive_pool_guid) ? $scope.pool_type.competitive_pool_guid : null,
//          "appropriation_guid":$scope.source_appropriation.appropriation_guid,
//          "reappropriation_guid":$scope.selectedguidreap || null,
//          "partner_flg":(!!$scope.charge_partner) ? $scope.charge_partner:false,
//          "payment_status_desc":$scope.payment_status.trim(),
//          "payment_comment":$scope.note1,
//          "object_code":(!!$scope.object_code) ? $scope.object_code:null,
//          "activity_code":(!!$scope.activity_code) ? $scope.activity_code:null,
//          "vendor_code":(!!$scope.vendor_code) ? $scope.vendor_code: null,
//          "vendor_name":$scope.vendor_name
        };
      console.log('Part2',response);
      AddPayment.addpayment().save(response)
        .$promise.then(
           function(res){
              console.log(res);
              $state.reload();
              $uibModalInstance.close(response);
               modalMessageService.showMessage( "Success:","Added Payment Successfully");
           },
           function(response) {
                $log.debug("ERROR ADDING New Expense Payments:", response);
                console.log(response);
               if (response.data.result === 'error' ) {
                   modalMessageService.showMessage( "Error:", response.data.message);
                } else {
                    modalMessageService.showMessage( "Error:", "Parameters not set correct ");
                }
                $log.debug("Error: "+response.status + " " + response.statusText);
            }
        );
//        $uibModalInstance.close(response);
    };


    var newcostsharerow = {
                "cost_per_acre": "",
                "payment_source":"" ,
                "share_description": "",
                "share_amount":"",
            };
     $scope.addNewcostshare = function(row){
      $scope.gridReapPay.data.push({
                "cost_per_acre": "",
                "payment_source":"" ,
                "share_description": "",
                "share_amount":"",
            });
    };



//Adding empty row  and deleting empty row

   $scope.addNewRow = function(){
      $scope.gridExpenseCostshare.data.push({});
    };

    $scope.deleteRow = function(){
       // $scope.gridApiFunds.selection.getSelectedRows()
        angular.forEach($scope.gridApiExpenseCostshare.selection.getSelectedRows(), function (data, index) {
          $scope.gridExpenseCostshare.data.splice($scope.gridExpenseCostshare.data.lastIndexOf(data), 1);
        });

   };


//// Register the grid for API calls like clearSelectedRows() and getSelectedRows()
//
//    $scope.gridExpenseCostshare.onRegisterApi = function(gridApiExpenseCostshare){
//        $scope.gridApiExpenseCostshare = gridApiExpenseCostshare;
//        gridApiExpenseCostshare.selection.on.rowSelectionChanged($scope,function(row){
//        var msg = 'row selected'+row.isSelected;
//         $scope.selectedRows = $scope.gridApiExpenseCostshare.selection.getSelectedRows()[0];
//         $scope.selectedguidfund = $scope.selectedRows.fund_guid;
//          console.log($scope.selectedguidfund);
//        });
//    };




// Filter options
$scope.filterOpts  = {
     year:null,program_type_guid:null,partner_guid:null,
   };


   $scope.updateFilter =  function(year, program_type_guid,partner_guid){
        $scope.filterOpts.year = year;
        $scope.filterOpts.program_type_guid=program_type_guid;
        $scope.filterOpts.partner_guid = partner_guid;

   };


$scope.updateGridData  = function(){

};




// Date picker

 $scope.today = function() {
    $scope.dt = new Date();
  };
  $scope.today();

   $scope.dateOptions = {
    formatYear: 'yy',
    maxDate: new Date(2020, 5, 22),
    minDate: new Date(),
    startingDay: 1
  };
   $scope.open1 = function() {
    $scope.popup1.opened = true;
  };


  $scope.setDate = function(year, month, day) {
    $scope.dt = new Date(year, month, day);
  };

$scope.clear = function() {
    $scope.dt = null;
  };

  $scope.formats = ['dd-MMMM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate'];
  $scope.format = $scope.formats[0];
  $scope.altInputFormats = ['M!/d!/yyyy'];

  $scope.popup1 = {
    opened: false
  };

  $scope.popup2 = {
    opened: false
  };

  var tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  var afterTomorrow = new Date();
  afterTomorrow.setDate(tomorrow.getDate() + 1);
  $scope.events = [
    {
      date: tomorrow,
      status: 'full'
    },
    {
      date: afterTomorrow,
      status: 'full'
    }
  ];



// Condition for disabling on source appropriation selection
    $scope.isDisableCompetitive = true;
    $scope.isDisableBase = true;

    $scope.sourceChange = function(){
    // alert("Selected Source " + $scope.appropriation_source_guid.grant_type_desc);
        $scope.isDisableCompetitive = true;
        $scope.isDisableBase = true;
    // console.log($scope.appropriation_source_guid.grant_type_desc);

        if($scope.appropriation_source_guid.grant_type_desc == "BASE")
        {
            $scope.isDisableBase = false;
        }

        if ($scope.appropriation_source_guid.grant_type_desc == "COMPETITIVE")
        {
            $scope.isDisableCompetitive = false;
        }
     };



//Add New Grant Details for the reappropriation
 $scope.addGrant = function(){
      var data={
          "reappropriation_guid": $scope.selectedFundData.fund_guid,
          "fund_id": $scope.selectedFundData.fund_id,
          "fund_name": $scope.selectedFundData.fund_name,
          "fund_description": $scope.selectedFundData.fund_description,
          "balance":$scope.selectedFundData.balance,
          "encumbered":$scope.selectedFundData.encumbered,
          "spent":$scope.selectedFundData.spent
      };
      console.log(data);
      UpdateFund.updatefund().update({guid:data.fund_guid},data);

};



// removing the grant row in the modal
    $scope.removePool = function(i){
    $scope.cpdetail.splice(i, 1);
    };

    $scope.removeGrant = function(i){
    $scope.grantdetail.splice(i, 1);
    };

});