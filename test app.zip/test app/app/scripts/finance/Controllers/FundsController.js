(function () {
    'use strict';
}());

var financeapp = angular.module('agSADCeFarms');
    financeapp.controller('FundsController', ['$scope','$stateParams','$location','$filter', '$uibModal','AuthService','uiGridConstants','Getfund','GetFundTrans','GetFundInfo','FundTransDataService','GetTransferStatus','DeleteFund','DeleteFundTrans','UpdateFundTrans','FundDataService','AddFund','UpdateFund', '$state', '$log','modalService','modalMessageService', function($scope,$stateParams,$location,$filter,$uibModal,AuthService,uiGridConstants,Getfund,GetFundTrans,GetFundInfo,FundTransDataService,GetTransferStatus,DeleteFund,DeleteFundTrans,UpdateFundTrans,FundDataService,AddFund,UpdateFund,$state,$log,modalService,modalMessageService) {




// Funds Grid display

    $scope.gridFunds = {
            enableSorting :true,
            enablePaginationControls: true,
            paginationPageSize: 15,
            paginationPageSizes:[5,15,25,50],
            enableFiltering: true,
            saveSelection: true,
            enableRowHeaderSelection: true,
            selectionRowHeaderWidth: 50,
            multiSelect: false,
            rowHeight: 35,
            showGridFooter:false,
            selectedItems: [],
            enableGridMenu: true,
            exporterCsvFilename: 'Funds.csv',
            exporterMenuVisibleData : true,
            exporterPdfDefaultStyle: {fontSize: 12},
            exporterPdfTableStyle: {margin: [30, 30, 30, 30]},
            exporterPdfTableHeaderStyle: {fontSize: 12, bold: true, italics: true, color: 'black'},
            exporterPdfHeader: { text: "Funds Details", style: 'headerStyle' },
            exporterPdfFooter: function ( currentPage, pageCount ) {
              return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' };
            },
            exporterPdfCustomFormatter: function ( docDefinition ) {
              docDefinition.styles.headerStyle = { fontSize: 22, bold: true };
              docDefinition.styles.footerStyle = { fontSize: 10, bold: true };
              return docDefinition;
            },
            exporterPdfOrientation: 'landscape',
            exporterPdfPageSize: 'LETTER',
            exporterPdfMaxGridWidth: 500,
            exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
            exporterExcelFilename: 'Funds.xlsx',
            exporterExcelSheetName: 'Sheet1',
            //
            //Row Selection Enhancement
            enableRowSelection: true,
            enableFullRowSelection: true,
            appScopeProvider: $scope,
            rowTemplate: '<div ng-click="grid.appScope.viewFundDetails(row)" ng-repeat="(colRenderIndex, col) in colContainer.renderedColumns track by col.uid" class="ui-grid-cell" ng-class="col.colIndex()" ui-grid-cell></div>',
            //
            //
            columnDefs: [
                  { name:'Fund ID', field: 'fund_id', width: 125, maxWidth: 200, minWidth: 70, pinnedLeft:false, sort: {
                      direction: uiGridConstants.ASC,
                      priority: 0,
                  }},
                  { name:'Fund Name', field: 'fund_name', width: 125, maxWidth: 200, minWidth: 70, pinnedLeft:false },
                  { name:'Fund Description', field: 'fund_description', width: 175, maxWidth: 200, minWidth: 70, pinnedLeft:false},
                  { name:'Balance', field: 'balance', width: 125, maxWidth: 200, minWidth: 70, cellFilter:'currency' , pinnedLeft:false },
                  { name:'Encumbered', field: 'encumbered', width: 125,  cellFilter:'currency' , pinnedLeft:false },
                  { name:'Spent', field: 'spent', width: 125,cellFilter:'currency', pinnedLeft:false },
        ],
    };
      //
    //Row Selection Enhancement
    $scope.viewFundDetails = function(row) {
        var itemguid = row.entity.fund_guid;
        if (itemguid) {
            $location.path('/finance/funds/detail/'+itemguid);
        }
    };
    //
    //

// Register the grid for API calls like clearSelectedRows() and getSelectedRows()
    $scope.gridFundsHeight = 'height: ' + ($scope.gridFunds.paginationPageSize * 35 + 150) + 'px';
    $scope.gridFunds.onRegisterApi = function(gridApiFunds){
        $scope.gridApiFunds = gridApiFunds;

        changegridFundsHeight($scope.gridFunds.data.length,15);
        $scope.gridApiFunds.pagination.on.paginationChanged($scope, function(newPage,pageSize){
            changegridFundsHeight($scope.gridFunds.data.length,pageSize);
        });
        gridApiFunds.selection.on.rowSelectionChanged($scope,function(row){
        var msg = 'row selected'+row.isSelected;
         $scope.selectedRows = $scope.gridApiFunds.selection.getSelectedRows()[0];
         $scope.selectedguidfund = $scope.selectedRows.fund_guid;
          console.log($scope.selectedguidfund);
        });
    };
    function changegridFundsHeight(newlength,pgsize) {
        $scope.gridFundsHeight = 'height: ' + ($scope.gridFunds.paginationPageSize * 35 + 150) + 'px';
        $scope.gridApiFunds.grid.handleWindowResize();
        $scope.gridApiFunds.core.refresh();
        }

// Add New Fund here
    $scope.newfundModal = function() {
    var modalInstance = $uibModal.open({
    templateUrl:'views/finance/newfund.html',
    controller:'FundsModalCtrl',
    backdrop: 'static',
    resolve: {
    fundtransitems: function () {
        return null;
        },
      },
    });
    modalInstance.result.then(function (modalResponse) {
            console.log("modalResponse", modalResponse);
        }, function () {
                    $log.debug("cancelled the Fund entry");
        });
          $scope.isDisabled = false;
      };

        var selectedFund = {};




// Delete Fund here
    $scope.deletefund = function(){
                $scope.currentselectedfund = getFundSelection();
                $scope.delfundid =   Object.values($scope.currentselectedfund.selectedFund)[0];
                $scope.fguid = $scope.delfundid.fund_guid;
                console.log($scope.fguid);
                var modalOptions = {
                closeButtonText: 'No',
                actionButtonText: 'Yes',
                headerText: 'Warning',
                bodyText: 'Are you sure you want to delete this item?'
             };
                 modalService.showModal({}, modalOptions)
                    .then(function (result) {
                DeleteFund.deletefund().delete({fund_guid:$scope.fguid})
                .$promise.then(
                   function(response){
                      modalMessageService.showMessage( "Success:","Fund deleted Successfully");
                      $log.debug("Deleted from server");
                      $state.reload();

                   },
               function(response) {
                    $log.debug("ERROR Deleting Funds:", response);
                   if (response.data.result === 'error' ) {
                       modalMessageService.showMessage( "Error:", response.data.message);
                    } else {
                        modalMessageService.showMessage( "Error:", "This Fund cannot be deleted  ");
                    }
                    $log.debug("Error: "+response.status + " " + response.statusText);
                }
              );
              });
            };


// Fund details
    $scope.viewSelectedFund = function(){
    FundDataService.setSelectedFund($scope.gridApiFunds.selection.getSelectedRows());
    $scope.selectedRows = $scope.gridApiFunds.selection.getSelectedRows()[0];
     $scope.selectedguidfund = $scope.selectedRows.fund_guid;

      var fund_guid = $scope.selectedguidfund;

    $location.path('/finance/funds/detail/'+fund_guid);
    };
    $scope.selectedFundData = FundDataService.getSelectedFund()[0];


    $scope.selectedFundAppropData = _.get($scope.selectedFundData, 'fund_approps');
    $scope.selectedFundTransData = _.get($scope.selectedFundData, 'fund_trans');


// Delete Funds Transaction here
    $scope.deletefundtrans = function(){
                $scope.currentselectedfund = getFundTransSelection();
                $scope.delfundtransid =   Object.values($scope.currentselectedfund.selectedFund)[0];
                $scope.ftransguid = $scope.delfundtransid.fund_transaction_guid;
                $log.debug($scope.ftransguid);
                DeleteFundTrans.deletefundtrans().delete({fund_transaction_guid:$scope.ftransguid})
                .$promise.then(
                   function(response){
                      modalMessageService.showMessage( "Success:","Fund Transaction deleted Successfully");
                      $log.debug("Deleted from server");
                      $state.reload();

                   },
               function(response) {
                    $log.debug("ERROR Deleting Fund Transaction:", response);
                   if (response.data.result === 'error' ) {
                       modalMessageService.showMessage( "Error:", response.data.message);
                    } else {
                        modalMessageService.showMessage( "Error:", "This Fund cannot be deleted  ");
                    }
                    $log.debug("Error: "+response.status + " " + response.statusText);
                }
              );
            };


// Fund details
       $scope.viewSelectedFund = function(){
          FundDataService.setSelectedFund($scope.gridApiFunds.selection.getSelectedRows());
            $scope.selectedRows = $scope.gridApiFunds.selection.getSelectedRows()[0];
             $scope.selectedguidfund = $scope.selectedRows.fund_guid;

                    var fund_guid = $scope.selectedguidfund;

           $location.path('/finance/funds/detail/'+fund_guid);

      };
         $scope.selectedFundData = FundDataService.getSelectedFund()[0];
         $scope.selectedFundAppropData = _.get($scope.selectedFundData, 'fund_approps');
         $scope.selectedFundTransData = _.get($scope.selectedFundData, 'fund_trans');



// Related Appropriation for Funds in  Grid display

    $scope.gridFundsApprops = {
            enableSorting :true,
            enablePaginationControls: true,
            paginationPageSize: 25,
            enableFiltering: true,
            saveSelection: true,
            enableRowHeaderSelection: true,
            selectionRowHeaderWidth: 50,
            multiSelect: false,
            rowHeight: 35,
            showGridFooter:false,
            selectedItems: [],
            enableGridMenu: true,
            exporterCsvFilename: 'Funds_Appropriations.csv',
            exporterPdfDefaultStyle: {fontSize: 12},
            exporterMenuVisibleData : true,
            exporterPdfTableStyle: {margin: [40, 40, 40, 40]},
            exporterPdfTableHeaderStyle: {fontSize: 12, bold: true, italics: true, color: 'black'},
            exporterPdfHeader: { text: "Funds Appropriations Details", style: 'headerStyle', },
            exporterPdfFooter: function ( currentPage, pageCount ) {
              return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' };
            },
            exporterPdfCustomFormatter: function ( docDefinition ) {
              docDefinition.styles.headerStyle = { fontSize: 22, bold: true };
              docDefinition.styles.footerStyle = { fontSize: 10, bold: true };
              return docDefinition;
            },
            exporterPdfOrientation: 'landscape',
            exporterPdfPageSize: 'LETTER',
            exporterPdfMaxGridWidth: 500,
            exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
            exporterExcelFilename: 'Funds_Appropriations.xlsx',
            exporterExcelSheetName: 'Sheet1',
            //
            //Row Selection Enhancement
            enableRowSelection: true,
            enableFullRowSelection: true,
            appScopeProvider: $scope,
            rowTemplate: '<div ng-click="grid.appScope.viewrelApprop(row)" ng-repeat="(colRenderIndex, col) in colContainer.renderedColumns track by col.uid" class="ui-grid-cell" ng-class="col.colIndex()" ui-grid-cell></div>',
            //
            //
            columnDefs: [
                  { name:'Appropriation', field: 'appropriation_name', width: 250, pinnedLeft:false, sort: {
                      direction: uiGridConstants.ASC,
                      priority: 0,
                  }},
                  { name:'Program', field: 'program_name', width: 250,  pinnedLeft:false },
                  { name:'Year', field: 'year', width: 125, pinnedLeft:false},
                  { name:'Initial Amount', field: 'initial_amount', width: 125, cellFilter:'currency', pinnedLeft:false },
                  { name:'Appropriation Balance', field: 'balance', width: 170, cellFilter:'currency', pinnedLeft:false },
                  { name:'Public Law', field: 'pl_type', width: 125,  pinnedLeft:false },
                  { name:'Appropriation Date', field: 'appropriation_date', width: 170,  pinnedLeft:false },
                  { name:'Reappropriation In', field: 'reappropriated_in', width: 170, cellFilter:'currency', pinnedLeft:false },
                  { name:'Reappropriation Out', field: 'reappropriated_out', width: 170, cellFilter:'currency', pinnedLeft:false },
        ],

    };
    //
    //Row Selection Enhancement
    $scope.viewrelApprop = function(row) {
        var itemguid = row.entity.appropriation_guid;
        if (itemguid) {
            $location.path('/finance/appropriations/appropdetail/' + itemguid);
        }
    };
    //
    //




//ui components
    $scope.ui_components = {
            'ui_fiscal_admin': false,
        };

//Check the AuthService here
if ( AuthService.isAuthenticated() ) {
    $log.debug("++++++User is authenticated");
    $log.debug("++++++Users ui access:", AuthService.getUserUIAccess());
    $scope.ui_components = {
            'ui_fiscal_admin':true
        };
} else {
    $log.debug("++++++User is not authenticated");
}




// Register the grid for API calls like clearSelectedRows() and getSelectedRows()
    $scope.gridFundsApprops.onRegisterApi = function(gridApiFunds){
        $scope.gridApiFunds = gridApiFunds;

        gridApiFunds.selection.on.rowSelectionChanged($scope,function(row){
        var msg = 'row selected'+row.isSelected;
         $scope.selectedRows = $scope.gridApiFunds.selection.getSelectedRows()[0];
         $scope.selectedguidfund = $scope.selectedRows.fund_guid;
        });
    };



// Funds Transaction Display GRID
    $scope.gridFundsTrans = {
            enableSorting :true,
            enablePaginationControls: true,
            paginationPageSize: 25,
            paginationPageSizes: [25,50,100],
            enableFiltering: true,
            saveSelection: true,
            enableRowHeaderSelection: true,
            selectionRowHeaderWidth: 50,
            multiSelect: false,
            rowHeight: 35,
            showGridFooter:false,
            selectedItems: [],
            enableGridMenu: true,
            exporterCsvFilename: 'Funds_Transactions.csv',
            exporterPdfDefaultStyle: {fontSize: 12},
            exporterMenuVisibleData : true,
            exporterPdfTableStyle: {margin: [60, 60, 60, 60]},
            exporterPdfTableHeaderStyle: {fontSize: 12, bold: true, italics: true, color: 'black'},
            exporterPdfHeader: { text: "Funds Transactions Details", style: 'headerStyle' },
            exporterPdfFooter: function ( currentPage, pageCount ) {
              return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' };
            },
            exporterPdfCustomFormatter: function ( docDefinition ) {
              docDefinition.styles.headerStyle = { fontSize: 22, bold: true };
              docDefinition.styles.footerStyle = { fontSize: 10, bold: true };
              return docDefinition;
            },
            exporterPdfOrientation: 'landscape',
            exporterPdfPageSize: 'LETTER',
            exporterPdfMaxGridWidth: 500,
            exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
            exporterExcelFilename: 'Funds_Transactions.xlsx',
            exporterExcelSheetName: 'Sheet1',
            //
            //Row Selection Enhancement
            enableRowSelection: true,
            enableFullRowSelection: true,
            appScopeProvider: $scope,
            rowTemplate: '<div ng-click="grid.appScope.EditFundTrans(row)" ng-repeat="(colRenderIndex, col) in colContainer.renderedColumns track by col.uid" class="ui-grid-cell" ng-class="col.colIndex()" ui-grid-cell></div>',
            //
            //
            columnDefs: [
                  { name:'Fund Transaction guid', field: 'fund_transaction_guid', width: 250,  pinnedLeft:false,visible:false},
                  { name:'Transaction Type', field: 'transaction_type_desc', width: 170, pinnedLeft:false },
                  { name:'Transaction Status', field: 'transaction_status', width: 170,  pinnedLeft:false},
                  { name:'Description', field: 'description', width: 170,pinnedLeft:false },
                  { name:'Transaction Date', field: 'transaction_date', type:'date',cellFilter: 'date:medium', width: 170,  pinnedLeft:false, sort: {
                      direction: uiGridConstants.ASC,
                      priority: 0,
                  } },
                  { name:'Amount', field: 'amount', width: 125,  cellFilter:'currency', pinnedLeft:false },
                  { name:'Notes', field: 'notes', width: 125, pinnedLeft:false },
                  { name:'Expense Payment', field: 'expense_payment_guid', width: 170,  cellFilter:'currency', pinnedLeft:false,visible:false },
                  { name:'Farm ID', field: 'farm_id', width: 125,pinnedLeft:false },
                  { name:'Farm Name', field: 'farm_name', width: 125, pinnedLeft:false },
        ],
    };


    // Register the grid for API calls like clearSelectedRows() and getSelectedRows()
    $scope.gridFundsTranstableHeight = 'height: ' + ($scope.gridFundsTrans.paginationPageSize * 35 + 150) + 'px';
    $scope.gridFundsTrans.onRegisterApi = function(gridApiFundsTrans){
        $scope.gridApiFundsTrans = gridApiFundsTrans;
        gridFundsTransHeight($scope.gridFundsTrans.data.length,5);
        $scope.gridApiFundsTrans.pagination.on.paginationChanged($scope, function(newPage,pageSize){
            gridFundsTransHeight($scope.gridFundsTrans.data.length,pageSize);
        });
        gridApiFundsTrans.selection.on.rowSelectionChanged($scope,function(row){
        var msg = 'row selected'+row.isSelected;
         $scope.selectedRows = $scope.gridApiFundsTrans.selection.getSelectedRows()[0];
         $scope.selectedguidfundtrans = $scope.selectedRows.fund_transaction_guid;
         var fundtransguid = $scope.selectedguidfundtrans;
        var fundtrasdetails = GetFundTrans.getfundtrans(fundtransguid).get()
                                      .$promise.then(
                    function(response){
                        $scope.selectedfundtransdetail = response;
                    },
                    function(err){
                      modalMessageService.showMessage( "Error:", "Cannot goto this path location");
                    }
                 );
        });
        };
        function gridFundsTransHeight(newlength,pgsize){
            console.log(newlength,pgsize);
            $scope.gridFundsTranstableHeight = 'height: ' + ($scope.gridFundsTrans.paginationPageSize * 35 + 150) + 'px';
            $scope.gridApiFundsTrans.grid.handleWindowResize();
            $scope.gridApiFundsTrans.core.refresh();
        }

// Register the grid for API calls like clearSelectedRows() and getSelectedRows()
    $scope.gridFundsTrans.onRegisterApi = function(gridApiFundsTrans){
        $scope.gridApiFundsTrans = gridApiFundsTrans;
        gridApiFundsTrans.selection.on.rowSelectionChanged($scope,function(row){
        var msg = 'row selected'+row.isSelected;
         $scope.selectedRows = $scope.gridApiFundsTrans.selection.getSelectedRows()[0];
         $scope.selectedguidfundtrans = $scope.selectedRows.fund_transaction_guid;
//          console.log($scope.selectedguidfundtrans);
        var fundtrasdetails = GetFundTrans.getfundtrans($scope.selectedguidfundtrans).get()
                                              .$promise.then(
                            function(response){
                                $scope.selectedfundtransdetails = response;
        //                                    console.log("fund transaction details",$scope.selectedfundtransdetails);
                            },
                            function(err){
                              modalMessageService.showMessage( "Error:", "Cannot goto this path location");
                            }
                         );
        });
    };




//Fund transaction details here

            $scope.viewSelectedFundTrans = function(){
            FundTransDataService.setSelectedFundTrans($scope.gridApiFundsTrans.selection.getSelectedRows());
            $scope.selectedRows = $scope.gridApiFundsTrans.selection.getSelectedRows()[0];
             $scope.selectedguidfundtrans = $scope.selectedRows.fund_transaction_guid;
              var fund_transaction_guid = $scope.selectedguidfundtrans;
            };
            $scope.selectedFundDataTrans = FundTransDataService.getSelectedFundTrans()[0];



    //
    //Row Selection Enhancement
    $scope.EditFundTrans = function(row) {
    var itemguid = row.entity.fund_transaction_guid;
    var modalInstance = $uibModal.open({
    templateUrl:'views/finance/fundtransedit.html',
    controller:'FundsModalCtrl',
    backdrop: 'static',
    resolve: {
    fundtransitems: function () {
        return itemguid;
        },
      },
    });
    modalInstance.result.then(function (modalResponse) {
    $log.debug("modalResponse", modalResponse);
    }, function () {
            $log.debug("cancelled the Fund entry");
    });
    $scope.isDisabled = false;
    $log.debug("Fund trans guid",$scope.selectedguidfundtrans);
    if (!!itemguid) {

       var fundtrasdetails = GetFundTrans.getfundtrans(itemguid).get()
                                      .$promise.then(
                    function(response){
                        $scope.selectedfundtransdetails = response;
                    //console.log("fund transaction details",$scope.selectedfundtransdetails);
                    },
                    function(err){
                      modalMessageService.showMessage( "Error:", "Cannot goto this path location");
                    }
                 );

    }
    };
    //
    //


// Selected Fund Transaction details based on the guid
    $scope.viewSelectedfund = function(){
    if(!!$scope.selecteddatafund && !!$scope.selecteddatafund.fundtrans){
        var fundtransguid = $scope.selecteddatafund.fundtrans;
        var fundtransdetails = GetFundTrans.getfundtrans(fundtransguid).get()
                              .$promise.then(
                                function(response){
                                    $scope.selectedfundtransdetails = response;
                                    $log.debug("fund transaction details",$scope.selectedfundtransdetails);
                                    //$location.path('/finance/funds/detail/'+fundguid);
                                },
                                function(err){
                                  modalMessageService.showMessage( "Error:", "Cannot goto this path location");
                                }
                             );
                }
        };
    $scope.viewSelectedfund();
          if(!!$stateParams){
              $scope.selecteddatafund = $stateParams;
            }


// Get Fund details API
    $scope.getFundDetails = function() {
            // Display loading image while fetching data
             $scope.loading_data = true;
            Getfund.getfundlist().query()
                .$promise.then(
                function(response){

                    $scope.fundsdetails = response;
                    $scope.gridFunds.data = response;
                    $log.debug("gridFunds.data:",$scope.gridFunds.data );
                    $scope.loading_data = false;

                },
                function(response) {
                    $log.debug("AFTER GETING ERROR FROM DETAILS:", $scope.fundsdetails);
                    $log.debug("Error: "+response.status + " " + response.statusText);
                    modalMessageService.showMessage( "Error:", response.status + " " +
                        response.statusText + '. Please contact ' + agSupportEmail);

                }
            );
        };

// Do Initial User load
  $scope.getFundDetails();






// Selected Fund details based on the guid
    $scope.viewSelectedfund = function(){
        if(!!$scope.selecteddatafund && !!$scope.selecteddatafund.fund_guid){
        var fundguid = $scope.selecteddatafund.fund_guid;
        $scope.fundguid = $scope.selecteddatafund;
        var funddetailsid = GetFundInfo.getfundinfo(fundguid).get()
                              .$promise.then(
                                function(response){
                                    $scope.selectedfunddetails = response;
                                    $scope.selecteddatadetailtrans = _.get($scope.selectedfunddetails, 'fund_trans');
                                        $location.path('/finance/funds/detail/'+fundguid);
                                },
                                function(err){
                                  modalMessageService.showMessage( "Error:", "Cannot goto this path location");
                                }
                             );
                }
        };

    $scope.viewSelectedfund();
          if(!!$stateParams){
              $scope.selecteddatafund = $stateParams;
            }




// Get Funds details grid table data from the guid
$scope.getReappropDetails = function() {
        $scope.loading_data = true;
        if(!!$scope.selecteddatafund && !!$scope.selecteddatafund.fund_guid){
        var fundguid = $scope.selecteddatafund.fund_guid;
        $scope.fundguid = $scope.selecteddatafund;
        var funddetailsid = GetFundInfo.getfundinfo(fundguid).get()
                              .$promise.then(
                                function(response){
                                    $scope.selectedfunddetails = response;
                                    $scope.selecteddatadetailapprops = _.get($scope.selectedfunddetails, 'fund_approps');
                                    $scope.selecteddatadetailtrans = _.get($scope.selectedfunddetails, 'fund_trans');
                                    $scope.gridFundsApprops.data = $scope.selecteddatadetailapprops;
                                    $scope.gridFundsTrans.data = $scope.selecteddatadetailtrans;


                                },
                                function(err){
                                   modalMessageService.showMessage( "Error:", "An error occurred. ");
                                }
                             );
                }
    };

            // Do Initial Reapprops   load
            $scope.getReappropDetails();




// Selected Fund
    var getFundSelection = function(){
        var selectedRows = $scope.gridApiFunds.selection.getSelectedRows();
         var fundSelection = { selectedFund: {}};
        angular.forEach( selectedRows, function(row){
            var fund_guid = row.fund_guid;
            var fund_id = row.fund_id;
            var fund_name = row.fund_name;
            fundSelection.selectedFund[fund_guid] = row;

        });
        $log.debug("NEW SELECTED USERS:", fundSelection);
        return fundSelection;

    };

    var guid = $scope.getFundSelection;




// Selected Fund Transaction
    var getFundTransSelection = function(){
        var selectedRows = $scope.gridApiFundsTrans.selection.getSelectedRows();
         var fundtransSelection = { selectedFundTrans: {}};
        angular.forEach( selectedRows, function(row){
            var fund_transaction_guid = row.fund_transaction_guid;
            fundtransSelection.selectedFundTrans[fund_transaction_guid] = row;

        });
        $log.debug("NEW SELECTED USERS:", fundtransSelection);
        return fundtransSelection;

    };


//Edit the Fund  here
    $scope.EditFund = function(){
    var modalInstance = $uibModal.open({
        templateUrl:'views/finance/fundedit.html',
        controller:'FundsModalCtrl',
         backdrop: 'static',
        resolve: {
            fundtransitems: function () {
                return null;
            },
        },

    });
    modalInstance.result.then(function (modalResponse) {
                $log.debug("modalResponse", modalResponse);
            }, function () {
                        $log.debug("cancelled the Fund Balance entry");
            });
    };


 //Adjust the Fund Balance here
    $scope.balanceModal = function(){
    var modalInstance = $uibModal.open({
        templateUrl:'views/finance/fundtransaction.html',
        controller:'FundsModalCtrl',
        backdrop: 'static',
        resolve: {
            fundtransitems: function () {
                return null;
            },
        },
    });
    modalInstance.result.then(function (modalResponse) {
                $log.debug("modalResponse", modalResponse);
            }, function () {
                        $log.debug("cancelled the Fund Balance entry");
            });
    };

}])



.controller('FundsModalCtrl', function(fundtransitems,$scope,$log,$state,$location,$stateParams,$filter,FundDataService,FundTransDataService,$uibModalInstance,Getfund,GetFundInfo,GetFundTrans,UpdateFundTrans,DeleteFundTrans,UpdateFund,GetTransferStatus,GetTransactiontype,AddTrans,AddFund,GetProgramtype,GetGranttype,modalService,modalMessageService){



// Fund Selection
    var getFundSelection = function(){
        var selectedRows = $scope.gridApiFunds.selection.getSelectedRows();
        var fundSelection = { selectedFund: {}};
        angular.forEach( selectedRows, function(row){
        var fund_guid = row.fund_guid;
        var fund_id = row.fund_id;
        var fund_name = row.fund_name;
        fundSelection.selectedFund[fund_guid] = row;
        });
        $log.debug("NEW SELECTED FUND:", fundSelection);
        return fundSelection;
    };




// Fund details
    $scope.viewSelectedFund = function(){
      FundDataService.setSelectedFund($scope.gridApiFunds.selection.getSelectedRows());
      $state.go('app.finance.funddetail');
    };
    $scope.selectedFundData = FundDataService.getSelectedFund()[0];


//Fund transaction details
$scope.transdatadetails = fundtransitems;
$log.debug("fund transaction details", $scope.transdatadetails);
if (!!fundtransitems) {
 var fundtrasdetails = GetFundTrans.getfundtrans($scope.transdatadetails).get()
                                                  .$promise.then(
                                function(response){
                                    $scope.selectedfundtransactiondetails = response;
                                    $log.debug("fund transaction details in modal controller",$scope.selectedfundtransactiondetails);
                                }
                             );
                             }


// Transaction types here
    var transactiontypes  = GetTransactiontype.gettransactiontype().query()
      .$promise.then(
        function(response){
            $scope.transactiontypeslist = response;
        });




// Get Fund list
 var funddetails = Getfund.getfundlist().query()
  .$promise.then(
    function(response){
        $scope.fundslist = response;
    });



// Get Funds details grid table data from the guid
$scope.getReappropDetails = function() {
        //loading image
        $scope.loading_data = true;
        if(!!$scope.selecteddatafund && !!$scope.selecteddatafund.fund_guid){
        var fundguid = $scope.selecteddatafund.fund_guid;
        $scope.fundguid = $scope.selecteddatafund;
        var funddetailsid = GetFundInfo.getfundinfo(fundguid).get()
                              .$promise.then(
                                function(response){
                                    $scope.selectedfunddetails = response;
                                    $scope.selecteddatadetailapprops = _.get($scope.selectedfunddetails, 'fund_approps');
                                    $scope.selecteddatadetailtrans = _.get($scope.selectedfunddetails, 'fund_trans');
                                },
                                function(err){
                                   modalMessageService.showMessage( "Error:", "An error occurred. ");
                                }
                             );
                }
    };

    // Do Initial Reapprops   load
    $scope.getReappropDetails();


    if(!!$stateParams){
      $scope.selecteddatafund = $stateParams;
    }



// Selected Fund details based on the guid
    $scope.viewSelectedfund = function(){
    if(!!$scope.selecteddatafund && !!$scope.selecteddatafund.fund_guid){
        var fundguid = $scope.selecteddatafund.fund_guid;
        $scope.fundguid = $scope.selecteddatafund;
        var funddetailsid = GetFundInfo.getfundinfo(fundguid).get()
                              .$promise.then(
                                function(response){
                                    $scope.selectedfunddetails = response;
                                        $location.path('/finance/funds/detail/'+fundguid);
                                },
                                function(err){
                                  modalMessageService.showMessage( "Error:", "Cannot goto this path location");
                                }
                             );
                }
        };
    $scope.viewSelectedfund();
          if(!!$stateParams){
              $scope.selecteddatafund = $stateParams;
            }



 // Post request for Adjust Transaction history
    $scope.addTrans = function(){
              $log.debug($scope.fundguid,$scope.selectedfunddetails.fund_guid);
          //var response = {"fund_guid":$scope.selectedFundData.fund_guid,"description":$scope.trans_description,"transaction_type_desc":$scope.fund_transaction_type.trim(),"transaction_status":$scope.fund_transfer_status.trim(),"amount":$scope.trans_amount}
          var response = {"fund_guid":$scope.selectedfunddetails.fund_guid,"transaction_type_desc":$scope.fund_transaction_type.trim(),"amount":$scope.trans_amount,"notes":$scope.notes};
          AddTrans.addtrans().save(response)
            .$promise.then(
               function(response){
//                  console.log(response);
                  modalMessageService.showMessage( "Success:","Added Tranasaction Successfully");
                  $state.reload();
               },
               function(response) {
                    $log.debug("Error Adding New Fund Transaction", response);
                   if (response.data.result === 'error' ) {
                       modalMessageService.showMessage( "Error:", response.data.message);
                        $log.debug("parameters not set correct");
                    } else {
                        modalMessageService.showMessage( "Error:", "An error occurred. ");
                    }
                    $log.debug("Error: "+response.status + " " + response.statusText);
                }
          );
         $uibModalInstance.close(response);
    };




    //
    //Row Selection Enhancement
    $scope.viewrelTrans = function(row) {
    var itemguid = row.entity.fund_transaction_guid;
        if (itemguid) {
           var fundtrasdetails = GetFundTrans.getfundtrans(itemguid).get()
                                          .$promise.then(
                        function(response){
                            $scope.selectedfundtransdetails = response;
                            $log.debug("fund transaction details",$scope.selectedfundtransdetails);
                        },
                        function(err){
                          modalMessageService.showMessage( "Error:", "Cannot goto this path location");
                        }
                     );

        }
    };
    //
    //




// Delete Funds Transaction here
    $scope.deletefundtrans = function(){
                $scope.transdatadetails = fundtransitems;
                var modalOptions = {
                closeButtonText: 'No',
                actionButtonText: 'Yes',
                headerText: 'Warning',
                bodyText: 'Are you sure you want to delete this item?'
             };
                 modalService.showModal({}, modalOptions)
                    .then(function (result) {
                DeleteFundTrans.deletefundtrans().delete({fund_transaction_guid:$scope.transdatadetails})
                .$promise.then(
                   function(response){
                      $uibModalInstance.close();
                      modalMessageService.showMessage( "Success:","Fund Transaction deleted Successfully");
                      $state.reload();

                   },
               function(response) {
                    $log.debug("ERROR Deleting Fund Transaction:", response);
                   if (response.data.result === 'error' ) {
                       modalMessageService.showMessage( "Error:", response.data.message);
                    } else {
                        modalMessageService.showMessage( "Error:", "This Fund cannot be deleted  ");
                    }
                    $log.debug("Error: "+response.status + " " + response.statusText);
                }


              );

               });

            };



//  Submit Edited Fund
     $scope.submitEditFund = function(){
         console.log($scope.selectedfunddetails);
          var data={
              "fund_guid": $scope.selectedfunddetails.fund_guid,
              "fund_id": $scope.selectedfunddetails.fund_id,
              "fund_name": $scope.selectedfunddetails.fund_name,
              "fund_description": $scope.selectedfunddetails.fund_description,
              "balance":$scope.selectedfunddetails.balance,
              "encumbered":$scope.selectedfunddetails.encumbered,
              "spent":$scope.selectedfunddetails.spent
          };
          console.log(data);
          UpdateFund.updatefund().update({guid:data.fund_guid},data);
          modalMessageService.showMessage( "Success:","Fund Edited Successfully");
          $state.reload();
         $uibModalInstance.dismiss();

    };



//  Submit Edited Fund Transaction
    $scope.submiteditfundtrans = function(){
      var data={
          "fund_transaction_guid": $scope.transdatadetails,
          "notes":$scope.selectedfundtransactiondetails.notes
      };
      console.log(data);
      UpdateFundTrans.updatefundtrans().update({guid:data.fund_transaction_guid},data)
       .$promise.then(
               function(response){
                   modalMessageService.showMessage( "Success:","Fund Transaction Edited Successfully");
                   $state.reload();
                   $uibModalInstance.dismiss();

               },
               function(response) {
                    $log.debug("ERROR ADDING EDITED FUND Transaction:", response);
                   if (response.data.result === 'error' ) {
                       modalMessageService.showMessage( "Error:", response.data.message);
                    } else {
                        modalMessageService.showMessage( "Error:", "An error occurred While Adding New Fund. ");
                    }
                    $log.debug("Error: "+response.status + " " + response.statusText);
                }
          );

    };



//Program type list
    var program = GetProgramtype.getprogramtype().query()
      .$promise.then(
        function(response){
            $scope.programtypelist = response;
        },
        function(response) {
            $log.debug("ERROR GETTING Program Type List:", response);
            if ( response.data === '{ "error": "Bad Request UE" }' ) {
                modalMessageService.showMessage( "Error:", "Check the service");
            } else {
                modalMessageService.showMessage( "Error:", "An error occurred. ");
            }
            $log.debug("Error: "+response.status + " " + response.statusText);

        }
     );

  $scope.close = function(){
        $uibModalInstance.dismiss();
    };



// Post request for new fund
    $scope.submit = function(){
      var response = {"fund_id":$scope.fundid, "fund_name":$scope.fundname,"fund_description":$scope.funddescription,"balance":$scope.fundbalance,};
        AddFund.addfund().save(response)
        .$promise.then(
           function(response){
              $state.reload();
              $uibModalInstance.close(response);
              modalMessageService.showMessage( "Success:","Fund Added Successfully");

           },
           function(response) {
                $log.debug("ERROR ADDING NEWFUND:", response);
               if (response.data.result === 'error' ) {
                   modalMessageService.showMessage( "Error:", response.data.message);
                } else {
                    modalMessageService.showMessage( "Error:", "An error occurred While Adding New Fund. ");
                }
                $log.debug("Error: "+response.status + " " + response.statusText);
            }
      );
    };

});
