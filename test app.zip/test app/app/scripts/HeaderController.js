(function () {
    'use strict';
}());

angular.module('agSADCeFarms')
    .controller('HeaderController', ['$scope', '$log', '$state', 'AuthService',
        'modalService', 'modalMessageService', 'agSupportEmail', '$window',
        function( $scope, $log, $state, AuthService,
                  modalService, modalMessageService, agSupportEmail, $window ) {

            $scope.$watchCollection(function(){
                return AuthService.authState;
            }, function() {
                if ( ! AuthService.authState ) {
                    $log.debug("+++AuthService.authState changed to:", AuthService.authState);
                    disable_ui_components();
                    $scope.current_user = "";
                    $scope.logged_in = false;
                    //$scope.logoff();
                }
            });

            $scope.ui_components = {
                'ui_adminmenu': false,
                'ui_appadmin': false,
                'ui_sysadmin': false,
                'ui_fiscal': false,
                'ui_useradmin': false
            };

            //var disable_ui_components = function(ui_access) {
            var disable_ui_components = function() {
                // reset all ui_components values to false
                angular.forEach( Object.keys($scope.ui_components), function(comp_key) {
                    //$log.debug("Setting", comp_key, "to false");
                    $scope.ui_components[comp_key] = false;
                });
            };

            var set_ui_values = function(ui_access){
                // first reset all ui_components values to false
                disable_ui_components();
                //disable_ui_components(ui_access);
                // set the value for each ui_component to true for each value in ui_access
                angular.forEach( ui_access, function(comp_key) {
                    //$log.debug("Setting", comp_key, "to true");
                    $scope.ui_components[comp_key] = true;
                });
                // Determine if user should see admin menu
                if ( $scope.ui_components.ui_appadmin || $scope.ui_components.ui_sysadmin ||
                    $scope.ui_components.ui_fiscal || $scope.ui_components.ui_useradmin ) {
                    $log.debug("User is allowed to see admin menu");
                    $scope.ui_components.ui_adminmenu = true;
                }
            };

            var checkAuthentication = function() {
                AuthService.authenticate()
                    .then(
                    function(response) {
                        $log.debug("======AUTHENTICATE RESPONSE:", response);
                        // Valid call to authenticate.  So set the AuthService response.
                        AuthService.setAuthenticateResponse(response);
                        if (response.status == 'AUTHENTICATED'){
                            AuthService.setAuthenticatedState(true);
                            // User is authenticated via portal so track session idleness
                            $log.debug("++++++User is authenticated.  Starting to track session.");
                            var session_timeout_minutes = response.session_timeout;
                            $log.debug("++++++Session timeout is set to ", session_timeout_minutes, "minutes.");
                            AuthService.startIdleWatch();
                            // Allow 30 minutes of idle time
                            AuthService.setSessionIdleTimeout(30*60);
                            // Warn user 30 seconds before terminating session
                            AuthService.setSessionIdleWarningTimeout(30);
                            // Set keepalive at 1 minute less than server session timeout
                            //AuthService.setKeepaliveInterval((session_timeout_minutes-1)*60);
                            //AuthService.setKeepaliveInterval(15);
                        } else {
                            // User is not authenticated via portal
                            AuthService.setAuthenticatedState(false);
                        }
                        if (AuthService.authResponse.status !== 'AUTHENTICATED'){
                            // Get the message for why user is not authenticated
                            var no_auth_message = AuthService.authResponse.message;
                            var mynj = AuthService.authResponse.mynj;
                            $log.debug("UNAUTHORIZED MESSAGE:", no_auth_message);
                            if ( mynj != "") {
                                $log.debug("+++Redirecting to portal");
                                $window.location.href = mynj;
                            } else {
                                $log.debug("+++Other portal issue");
                                modalMessageService.showMessage( "Error:", no_auth_message);
                            }
                            //var modalOptions = {
                            //    closeButtonText: 'Cancel',
                            //    actionButtonText: 'Log In to myNew Jersey',
                            //    headerText: "Login Required",
                            //    bodyText: no_auth_message
                            //};
                            //modalService.showModal({}, modalOptions, {})
                            //    .then(function() {
                            //        $log.debug("Login requested");
                            //        $window.open(AuthService.authResponse.mynj, '_blank');
                            //    },
                            //    // Ignore the cancel button
                            //    function(){
                            //        $log.debug("Login Cancelled.");
                            //    });
                        } else {
                            set_ui_values(AuthService.authResponse.ui_access);
                        }
                        showHeader();
                    },
                    function(response) {
                        $log.debug("ERROR FROM AUTHENTICATE SERVICE:", response.status);
                        $log.debug("Error:", response.status + " " + response.statusText + " Please contact " + agSupportEmail + " and mention this message.");
                        modalMessageService.showMessage( "Error:", response.status + " " + response.statusText + ". Please contact " + agSupportEmail + " and mention this message");
                    });
            };

            var showHeader = function(){
                if (AuthService.authResponse.status == 'AUTHENTICATED') {
                    $scope.logged_in = true;
                    $scope.current_user = "Welcome: " + AuthService.authResponse.first_name + ' ' + AuthService.authResponse.last_name;
                }
            };

            $scope.login = function() {
                if ( ! $scope.logged_in ) {
                    checkAuthentication();
                }

            };

            $scope.logoff = function() {
                disable_ui_components();
                AuthService.stopIdleWatch();
                AuthService.logoff();
                $scope.current_user = "";
                $scope.logged_in = false;
                $state.go('app');
            };

            checkAuthentication();
    }])
;
