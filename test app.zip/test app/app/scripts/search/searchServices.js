angular.module('agSADCeFarms')
.constant("baseURL", "/AG_SADCeFarms/")
.factory('searchFactory',[ '$http', 'baseURL', '$filter', function($http, baseURL, $filter){
    var getFarms = function(){
        return $http({
            method: 'GET',
             url : baseURL+'farmlist',
            headers: {
                'Content-Type': 'application/json'
            }
        });
    };

    var getCounty = function(){
        return $http({
            method: 'GET',
            url : baseURL+'county',
            headers: {
                'Content-Type': 'application/json'
            }
        });
    };

    var getCountyMun = function(){
        return $http({
            method: 'GET',
            url : baseURL+'countymun',
            headers: {
                'Content-Type': 'application/json'
            }
        });
    };

    var getPartner = function(){
        return $http({
            method: 'GET',
            url : baseURL+'partner',
            headers: {
                'Content-Type': 'application/json'
            }
        });
    };

    var getPreservationType = function(){
        return $http({
            method: 'GET',
            url : baseURL+'preservationtype',
            headers: {
                'Content-Type': 'application/json'
            }
        });
    };

    var getAppList = function(){
        return $http({
            method: 'GET',
            url : baseURL+'applist',
            headers: {
                'Content-Type': 'application/json'
            }
        });
    };

    var getApplicationType = function(){
        return $http({
            method: 'GET',
            url : baseURL+'applicationtype',
            headers: {
                'Content-Type': 'application/json'
            }
        });
    };

    var getProgramType = function(){
        return $http({
            method: 'GET',
            url : baseURL+'programtype',
            headers: {
                'Content-Type': 'application/json'
            }
        });
    };

    var getSearchedFarm = function(params){
        return $http({
            method: 'GET',
            url : baseURL+'search/farm' +'?' +params,
            headers: {
                'Content-Type': 'application/json'
            }
        });
    };

    var getSearchedApp = function(params){
        return $http({
            method: 'GET',
            url : baseURL+'search/application' +'?' +params,
            headers: {
                'Content-Type': 'application/json'
            }
        });
    };



    return{
        getFarms : getFarms,
        getProgramType : getProgramType,
        getApplicationType : getApplicationType,
        getAppList : getAppList,
        getPreservationType : getPreservationType,
        getPartner : getPartner,
        getCountyMun : getCountyMun,
        getCounty : getCounty,
        getSearchedFarm : getSearchedFarm,
        getSearchedApp : getSearchedApp
    };

}]);