angular.module('agSADCeFarms')
.controller('searchResultsController', ['$scope','searchFactory', 
'$state','$filter', '$stateParams', '$httpParamSerializer',
function($scope, SF, $state, $filter, $stateParams, $httpParamSerializer) {
    var SrchRsltsCtrl = this;
    SrchRsltsCtrl.viewTypes = {
        FARMRESULTS: 'farmResults',
        APPRESULTS: 'appResults',
        NORESULTS: 'noResults',
        LOADING: 'loading'
    } ;
    var onLoad = function() {
        //get the params from the route
        var filters = $stateParams.filtersAndObjs.filters;
        SrchRsltsCtrl.filterObjs = $stateParams.filtersAndObjs.filterObjs;
        //set the view based on received params
        SrchRsltsCtrl.currentView = filters.viewType;
        
        //Serialize Params 
        var onlyFilters = angular.copy(filters);
        delete onlyFilters['viewType'];
        var paramsStr = $httpParamSerializer(onlyFilters);
        
        //Call respective view funct
        if(filters.viewType == SrchRsltsCtrl.viewTypes.FARMRESULTS){
            SrchRsltsCtrl.farmResults(paramsStr);
        }else{
            SrchRsltsCtrl.appResults(paramsStr);
        }
    };
    SrchRsltsCtrl.farmResults = function(paramsStr){
        //config the farm ui-grid
        var preFarmLink = "<div class='ui-grid-cell-contents'> <a class='myDFarmLink' href='#farm/{{row.entity.farm_id}}'><u>{{row.entity.farm_id}}</u></a> </div>";
        SrchRsltsCtrl.farmColumns =
        [   { name:'Farm Id', field: 'farm_id', cellTooltip: true, cellTemplate:preFarmLink},
            { name:'Farm Name',field: 'farm_name' },
            { name:'Municipality',field: 'municipality' },
            { name:'Preserved Date',field: 'preserved_date' },
            { name:'Farm Status', field: 'status_preserved_desc' },
            { name:'Partner',field: 'partner' },
        ];
        SrchRsltsCtrl.farmGridOptions = {
        //   enableSorting: true,
          enableSorting: true,
          enableFiltering: true,
          enablePaginationControls: true,
          enableRowHeaderSelection: false,
          enableColumnResizing: true,
          columnDefs: SrchRsltsCtrl.farmColumns,
          enableRowSelection: false,
          enableFullRowSelection: false,
          appScopeProvider: $scope,
          onRegisterApi: function(farmGridApi) {
            SrchRsltsCtrl.farmGridApi = farmGridApi;
          }
        };
        // get the results and initiate ui-grid
        SF.getSearchedFarm(paramsStr).then(function(resp){
            SrchRsltsCtrl.farmResults = resp.data;
            SrchRsltsCtrl.farmGridOptions.data = resp.data;
        }, function(){
            
        });
    };
    $scope.routeToFarmInfo = function(row){
        $state.go('app.farm.information', {farm_id: row.entity.farm_id});
    };

    SrchRsltsCtrl.routeToSearch = function(){
        $state.go('app.search', { filterObjs: SrchRsltsCtrl.filterObjs });
    };

    SrchRsltsCtrl.appResults = function(paramsStr){
        //config the app ui-grid
         var preAppLink = "<div class='ui-grid-cell-contents'> <a class='myDAppLink' href='#application/{{row.entity.application_id}}'><u>{{row.entity.application_id}}</u></a> </div>";
         var preFarmLink = "<div class='ui-grid-cell-contents'> <a class='myDFarmLink' href='#farm/{{row.entity.farm_id}}'><u>{{row.entity.farm_id}}</u></a> </div>";
        SrchRsltsCtrl.appColumns =
        [   { name:'Application Id',field: 'application_id', cellTooltip: true, cellTemplate:preAppLink},
            { name:'Farm Id',field: 'farm_id', cellTooltip: true, cellTemplate:preFarmLink},
            { name:'Application Type', field: 'application_type' },
            { name:'Application Phase',field: 'application_phase' },
            { name:'Application Status',field: 'application_status' },
            { name:'Partner Name' ,field: 'partner_name' },
            { name:'Program Type',field: 'program_type' },
        ];
        SrchRsltsCtrl.appGridOptions = {
          enableSorting: true,
          enableFiltering: true,
          enablePaginationControls: true,
          enableRowHeaderSelection: true,
          enableColumnResizing: true,
          columnDefs: SrchRsltsCtrl.appColumns,
          enableRowSelection: false,
          enableFullRowSelection: false,
          appScopeProvider: $scope,
          onRegisterApi: function(appGridApi) {
         SrchRsltsCtrl.appGridApi = appGridApi;
          }
        };

        // get the results and initiate ui-grid
        SF.getSearchedApp(paramsStr).then(function(resp){
            SrchRsltsCtrl.searchedAppResults = resp.data;
            SrchRsltsCtrl.appGridOptions.data = resp.data;
        }, function(){

        });
    };

    onLoad();
 }]);