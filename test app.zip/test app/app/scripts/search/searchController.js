angular.module('agSADCeFarms')
.controller('searchController', ['$scope','searchFactory','AuthService', '$state','$filter',
'$httpParamSerializer','$stateParams','getTagTypes','modalService','$window','$log',
 function($scope, SF, AuthService,$state, $filter, $httpParamSerializer,$stateParams, getTagTypes, modalService, $window,$log){
    var SrchCtrl = this;
    $scope.ui_components = {
            'ui_search_auth': false

        };

         var disable_ui_components = function() {
        $scope.ui_components['ui_search_auth'] = false;
    }
    var setUIValues = function(){
        var ui_access = AuthService.authResponse.ui_access;
        angular.forEach( ui_access, function(comp_key) {
                if($scope.ui_components.hasOwnProperty(comp_key)){
                      $scope.ui_components[comp_key] = true;
                }
            });
    }

//AuthService
    if ( AuthService.isAuthenticated() ) {
    console.log("++++++User is authenticated");
    console.log("++++++Users ui access:", AuthService.getUserUIAccess());
    setUIValues();

    } else {
        console.log("++++++User is not authenticated");
        disable_ui_components();
    }

    $scope.$watchCollection(function(){
                return AuthService.authState;
            }, function() {
                if ( ! AuthService.authState ) {
                    $log.debug("+++AuthService.authState changed to:", AuthService.authState);
                    disable_ui_components();

                }else{
                    setUIValues();
                }
            });

    var onLoad = function(){
        SrchCtrl.searchFarmByFilters = {};

        SF.getProgramType().then(function(response){
            SrchCtrl.programTypes = response.data;
            SrchCtrl.programTypes = $filter('orderBy')(SrchCtrl.programTypes, 'program_name');
        }, function(response){
            console.log(response);
        });

        SF.getApplicationType().then(function(response){
            SrchCtrl.applicationTypes = response.data;
            SrchCtrl.applicationTypes = $filter('orderBy')(SrchCtrl.applicationTypes, 'application_type_label');
        }, function(response){
            console.log(response);
        });

        SF.getAppList().then(function(response){
            SrchCtrl.appLists = response.data;
        }, function(response){
            console.log(response);
        });

        SF.getPreservationType().then(function(response){
            SrchCtrl.preservationTypes = response.data;
        }, function(response){
            console.log(response);
        });

        SF.getPartner().then(function(response){
            SrchCtrl.partners = response.data;
            SrchCtrl.partners = $filter('orderBy')(SrchCtrl.partners, 'partner_label');
        }, function(response){
            console.log(response);
        });

        SF.getCountyMun().then(function(response){
            SrchCtrl.allCountyMun = response.data;
        }, function(response){
            console.log(response);
        });

        SF.getCounty().then(function(response){
            SrchCtrl.counties = response.data;
        }, function(response){
            console.log(response);
        });
        getTagTypes.getTagTypes().then(function(resp){
            if(resp.status==200){
                SrchCtrl.allAvailalbeTags = resp.data;
            }else{
                console.log(resp);
                toastr.error('Error occured while fectching tags');
            }
        }, function(){
            if(resp.status==200){
                SrchCtrl.allAvailalbeTags = resp.data;
            }else{
                console.log(resp);
                toastr.error('Error occured while fetching tags');
            }
        });

        SrchCtrl.showAppResults = false;
        SrchCtrl.showFarmResults = false;

        var filterObjs = $stateParams.filterObjs;

        if(filterObjs) {
            //Fill the values from the state params obj if exists.
            if('searchAppByFilters' in filterObjs) {
                SrchCtrl['searchAppByFilters'] = filterObjs.searchAppByFilters;
            }

            if('searchFarmByFilters' in filterObjs) {
                SrchCtrl['searchFarmByFilters'] = filterObjs.searchFarmByFilters;
            }

            if('searchFormById' in filterObjs) {
                SrchCtrl['searchFormById'] = filterObjs.searchFormById;
            }
        }

    };
    onLoad();



    SrchCtrl.onCountySelection = function(selectedCounty){
        //console.log(selectedCounty)
        var counties = SrchCtrl.allCountyMun.length;
        for(var i=0; i<counties;i++){
            if(JSON.parse(SrchCtrl.searchFarmByFilters.county).county_code == SrchCtrl.allCountyMun[i].county_code){
                SrchCtrl.countyMun = SrchCtrl.allCountyMun[i].munilist;
                SrchCtrl.countyMun = $filter('orderBy')(SrchCtrl.countyMun, 'name');
                break;
            }
        }
    };

    SrchCtrl.goToForm = function(){
        var filters = {};
        filters['viewType']="farmResults";
        if(SrchCtrl.searchFormById.selectedFarm.length>0){
            filters['farm_id'] = SrchCtrl.searchFormById.selectedFarm;
            SrchCtrl.validateAndRouteToFarm(filters);
        }else{
            toastr.warning('Enter the farmId');
        }

        // $state.go('app.farm.information', {farm_id: farmId});
    };

    SrchCtrl.validateAndRouteToFarm = function(filters){
        var paramsStr = $httpParamSerializer(filters);
        // route only if results exist.
        SF.getSearchedFarm(paramsStr).then(function(resp){
            if(resp.data.length>0){
                var filtersAndObjs = {
                    filters: filters,
                    filterObjs: SrchCtrl.getSelectedFilters()
                };
                $state.go('app.searchResults', {filtersAndObjs: filtersAndObjs});
            }else{
                toastr.warning("No list available");
            }
        }, function(resp){
            toastr.error('Some error occured.')
        });
    };

    SrchCtrl.goToApplication = function(){
        var filters = {};
        filters['viewType']="appResults";
        if(SrchCtrl.searchApplication.application.length>0){
            filters['application_id'] = SrchCtrl.searchApplication.application;
            // $state.go('app.searchResults', {filters: filters});
            SrchCtrl.validateAndRouteToApp(filters);
        }else{
            toastr.warning('Enter the application Id');
        }
    };

    SrchCtrl.validateAndRouteToApp = function(filters){
        var paramsStr = $httpParamSerializer(filters);

        SF.getSearchedApp(paramsStr).then(function(resp){
            if(resp.data.length>0){
                var filtersAndObjs = {
                    filters: filters,
                    filterObjs: SrchCtrl.getSelectedFilters()
                };
                $state.go('app.searchResults', {filters: filtersAndObjs});
            }else{
                toastr.warning("No list available");
            }
        }, function(){
            toastr.warning('Some error occured. ')
        });
    }

    SrchCtrl.searchFarm = function(){
        var filters = {};
        filters['viewType']="farmResults";
        if(SrchCtrl.searchFormById && SrchCtrl.searchFormById.selectedFarm &&  SrchCtrl.searchFormById.selectedFarm.length>0){
            filters['farm_id'] = SrchCtrl.searchFormById.selectedFarm;
        }
        if(SrchCtrl.searchFarmByFilters.farmName && SrchCtrl.searchFarmByFilters.farmName.length>0){
            filters['farm_name'] = SrchCtrl.searchFarmByFilters.farmName;
        }
        if(SrchCtrl.searchFarmByFilters.partner){
            filters['partner'] = JSON.parse(SrchCtrl.searchFarmByFilters.partner).partner_guid;
        }
        if(SrchCtrl.searchFarmByFilters.county){
            filters['county'] =JSON.parse( SrchCtrl.searchFarmByFilters.county).county_code;
        }
        if(SrchCtrl.searchFarmByFilters.block && SrchCtrl.searchFarmByFilters.block.length>0){
            filters['block'] = SrchCtrl.searchFarmByFilters.block;
        }
        if(SrchCtrl.searchFarmByFilters.address && SrchCtrl.searchFarmByFilters.address.length>0){
            filters['address'] = SrchCtrl.searchFarmByFilters.address;
        }
        if(SrchCtrl.searchFarmByFilters.municipality){
            filters['municipality'] = JSON.parse(SrchCtrl.searchFarmByFilters.municipality).muni_code;
        }
        if(SrchCtrl.searchFarmByFilters.preservationStatus && SrchCtrl.searchFarmByFilters.preservationStatus.length>0){
            filters['status_preserved_desc'] = SrchCtrl.searchFarmByFilters.preservationStatus;
        }
        if(SrchCtrl.searchFarmByFilters.lot && SrchCtrl.searchFarmByFilters.lot.length>0){
            filters['lot'] = SrchCtrl.searchFarmByFilters.lot;
        }
         if(SrchCtrl.searchFarmByFilters.landowner_first && SrchCtrl.searchFarmByFilters.landowner_first.length>0){
            filters['landowner_first'] = SrchCtrl.searchFarmByFilters.landowner_first;
        }
        if(SrchCtrl.searchFarmByFilters.landowner_last && SrchCtrl.searchFarmByFilters.landowner_last.length>0){
            filters['landowner_last'] = SrchCtrl.searchFarmByFilters.landowner_last;
        }
        if(SrchCtrl.searchFarmByFilters.SelectedTags && SrchCtrl.searchFarmByFilters.SelectedTags.length>0){
            filters['tags'] = SrchCtrl.searchFarmByFilters.SelectedTags;
            console.log('tags',SrchCtrl.searchFarmByFilters.SelectedTags);
        }

        SrchCtrl.validateAndRouteToFarm(filters);
    };

    SrchCtrl.searchApplication = function(){
        var filters = {};
        filters['viewType']="appResults";
        if(SrchCtrl.searchAppByFilters && SrchCtrl.searchAppByFilters.farm && SrchCtrl.searchAppByFilters.farm.length>0){
            filters['farm_id'] = SrchCtrl.searchAppByFilters.farm;
        }
        if(SrchCtrl.searchAppByFilters.partner){
            filters['partner'] = JSON.parse(SrchCtrl.searchAppByFilters.partner).partner_guid;
        }
        if(SrchCtrl.searchAppByFilters.applicationType){
            filters['application_type']  =JSON.parse( SrchCtrl.searchAppByFilters.applicationType).application_type_guid;
        }
        if(SrchCtrl.searchAppByFilters.year && SrchCtrl.searchAppByFilters.year.length>0){
            filters['year'] = SrchCtrl.searchAppByFilters.year;
        }
        if(SrchCtrl.searchAppByFilters.programType){
            filters['program_type']= JSON.parse( SrchCtrl.searchAppByFilters.programType).program_type_guid;
        }

        SrchCtrl.validateAndRouteToApp(filters);
    };

    SrchCtrl.clearFilters = function() {
        SrchCtrl.searchFarmByFilters.farmName = "";
        SrchCtrl.searchFormById = "";
        SrchCtrl.searchFarmByFilters.partner = "";
        SrchCtrl.searchFarmByFilters.landowner_first = "";
        SrchCtrl.searchFarmByFilters.landowner_last = "";
        SrchCtrl.searchFarmByFilters.SelectedTags = "";
        SrchCtrl.searchFarmByFilters.county = "";
        SrchCtrl.searchFarmByFilters.block = "";
        SrchCtrl.searchFarmByFilters.address = "";
        SrchCtrl.searchFarmByFilters.municipality = "";
        SrchCtrl.searchFarmByFilters.preservationStatus = "";
        SrchCtrl.searchFarmByFilters.lot = "";
        SrchCtrl.searchAppByFilters = "";
        SrchCtrl.searchAppByFilters.partner = "";
        SrchCtrl.searchAppByFilters.applicationType = "";
        SrchCtrl.searchAppByFilters.year = "";
        SrchCtrl.searchAppByFilters.programType = "";
        SrchCtrl.searchApplication.application = "";
    }
    SrchCtrl.getSelectedFilters = function() {
        var allSelectedFilters = {
        }

        if(SrchCtrl.searchAppByFilters) {
            allSelectedFilters['searchAppByFilters'] = SrchCtrl.searchAppByFilters;
        }

        if(SrchCtrl.searchFarmByFilters) {
            allSelectedFilters['searchFarmByFilters'] = SrchCtrl.searchFarmByFilters;
        }

        if(SrchCtrl.searchFormById) {
            allSelectedFilters['searchFormById'] = SrchCtrl.searchFormById;
        }
        return allSelectedFilters;
    }

    SrchCtrl.addNoteGroupTag = function(){
        var isSelected = isExistsInAlreadySelectedTags();
        if(SrchCtrl.selectedTag.length > 0 && !isSelected){
            $scope.tagsError = false;
            if(SrchCtrl.searchFarmByFilters.SelectedTags.length>0){
                SrchCtrl.searchFarmByFilters.SelectedTags =SrchCtrl.searchFarmByFilters.SelectedTags+ ',' + SrchCtrl.selectedTag;
            }else {
                SrchCtrl.searchFarmByFilters.SelectedTags = SrchCtrl.selectedTag;
            }
        }
        if(isSelected) {
            var msg = 'Tag(' + SrchCtrl.selectedTag + ') already selected'
            toastr.warning(msg);
        }
        SrchCtrl.selectedTag ="";
    };

    var isExistsInAlreadySelectedTags = function(){
        if(SrchCtrl.searchFarmByFilters.SelectedTags && SrchCtrl.searchFarmByFilters.SelectedTags.length > 0) {
            var alreadySelectedTags = SrchCtrl.searchFarmByFilters.SelectedTags.split(',');
            for(var i=0; i<alreadySelectedTags.length; i++){
                if(alreadySelectedTags[i] == SrchCtrl.selectedTag){
                    return true;
                }
            }
        } else {
            SrchCtrl.searchFarmByFilters.SelectedTags = '';
        }

        return false;
    };

    SrchCtrl.deleteNoteGroupTag = function(index){
        var allTags = SrchCtrl.searchFarmByFilters.SelectedTags.split(',');
        allTags.splice(index, 1);
        SrchCtrl.searchFarmByFilters.SelectedTags = allTags.join(',')
        toastr.success('Removed tag');
    };

    $scope.$watch("SrchCtrl.searchFarmByFilters.SelectedTags", function(newVal, oldVal){
        if(newVal && newVal.length>0){
            SrchCtrl.selectedTagsInDisplay = newVal.split(',');
        } else {
            SrchCtrl.selectedTagsInDisplay = [];
        }
    })


}]);