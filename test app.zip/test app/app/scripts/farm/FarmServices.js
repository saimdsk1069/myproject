(function () {

}());

angular.module('agSADCeFarms')
    .constant("baseURL", "/AG_SADCeFarms/")

    .service('GetfarmInfo', ['$resource','baseURL',function($resource,baseURL){
        var fundData = {};
        this.getFarmInfo = function(farmID){
            return $resource(baseURL+'farminfo/'+farmID,{method:'GET'});

        };
        this.setFund = function(fund){
                fundData = fund;
        };
        this.getFund = function(){
                return fundData;
        };

    }])

    .service('GetFarmTags', ['$resource','baseURL','$http','$q', function($resource,baseURL, $http, $q) {
        this.getFarmTags=function(farmID){
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url : baseURL+'farmtag/'+farmID
            }).then(function(response){
                deferred.resolve(response.data);
            },function(response){
                console.log(response);
            } );

            return deferred.promise;
        };

    }])

        //Post NewTag Service
    .service('AddNewTag', ['$resource','baseURL', function($resource,baseURL) {

        this.addNewTag = function(){
            return $resource(baseURL+'farmtag', null, {'save':{method:'POST'}});
        };
    }])

    .service('DeleteFarmTags', ['$resource','baseURL','$http', '$q',  function($resource,baseURL, $http, $q) {
        this.deleteFarmTags = function(deleteTag){
            var deferred = $q.defer();
            $http({
                method: 'DELETE',
                url : baseURL+'farmtag',
                data : deleteTag,
                headers: {
                    'Content-Type': 'application/json'
                }
            }).then(function(response){
                deferred.resolve(response.data);
            },function(response){
                console.log(response);
            } );

            return deferred.promise;
        };
    }])
    .factory('getTagTypes', ['$http','baseURL', function($http,baseURL){
        var getTagTypes = function(){
            return $http({
                method: 'GET',
                url : baseURL+'farmtagtype',
                headers: {
                    'Content-Type': 'application/json'
                }
            });
        };
        return {
            getTagTypes : getTagTypes
        };
    }])

    .factory('FarmMapFactory', ['$http','baseURL', function($http,baseURL){
        //Get Farm Map Object
        var fetchFarmMapObj = function(farmID) {
            return $http.get(baseURL+'farmlayers/' + farmID)
                .then(
                    function(response) {
                        return response.data;
                    },
                    function(errResponse) {
                        console.error('Error while fetching Farm Map credential');
                    }
                );
        };

        return{
            fetchFarmMapObj: fetchFarmMapObj

        };
    }])


    .factory('FarmContactsFactory', ['$http','baseURL', function($http,baseURL){
         return {
                    fetchAppContacts: function(farmID){
                        var url = baseURL + 'farmcontact/'+ farmID;
                        return $http.get(url)
                                .then(
                                        function (response) {
                                            return response.data;
                                        },
                                        function (errResponse) {
                                            console.error('Error while fetching App Contacts');
                                        }
                                );

                    },
                    deleteAppContacts: function(contactGUID){
                        var url = baseURL + 'farmcontact';
                        var deleteData = {'farm_contact_guid': contactGUID};
                        return $http({
                            method: 'DELETE',
                            url: url,
                            data: deleteData,
                            headers: {
                                'Content-Type': 'application/json'
                            }
                        }).then(
                                function (response) {
                                    return response.data;
                                },
                                function (errResponse) {
                                    console.error('Error while Deleting App Contacts');
                                }
                        );

                    },
                     fetchAppContactsUsers: function () {
                        var url = baseURL+'users';
                        return $http.get(url)
                                .then(
                                        function (response) {
                                            return response.data;
                                        },
                                        function (errResponse) {
                                            console.error('Error while fetching App Contacts users');
                                            //return $q.reject(errResponse);
                                        }
                                );
                    },
                    fetchAppContactsTypes: function () {
                        var url = baseURL + 'farmcontacttype';
                        return $http.get(url)
                                .then(
                                        function (response) {
                                            return response.data;
                                        },
                                        function (errResponse) {
                                            console.error('Error while fetching App Contacts Types');
                                        }
                                );
                    },
                    postAppNewContact: function (postData) {
                        var url = baseURL + 'farmcontact';

                        return  $http.post(url, postData).then(
                                function (response) {
                                    toastr.clear();
                                    toastr.success('App Contact Added successfully', 'Success');
                                    return response.data;
                                },
                                function (errResponse) {
                                    toastr.clear();
                                    toastr.error('Bad Connectivity / Server Error', 'Error while posting App Contact');
                                    //return $q.reject(errResponse);
                                }
                        );

                    },
                     putAppContact: function (putData) {
                        var url = baseURL + 'farmcontact';

                        return  $http.put(url, putData).then(
                                function (response) {
                                    toastr.clear();
                                    toastr.success('App Contact Edited successfully', 'Success');
                                    return response.data;
                                },
                                function (errResponse) {
                                    toastr.clear();
                                    toastr.error('Bad Connectivity / Server Error', 'Error while editing App Contact');
                                }
                        );

                    },
      checkfarmID: function (farmID) {
                        console.log(farmID);
                        if (farmID != '' && farmID != null && farmID != undefined) {
                            return true;
                        } else {
                            return false;
                        }

            }
        };
    }])

    .factory('FarmApplicationsFactory', ['$http','baseURL', function($http,baseURL){
        //applications
        var getApplications = function(farmID){
            return $http({
                method: 'GET',
                url : baseURL+'farmapp/'+farmID,
                headers: {
                    'Content-Type': 'application/json'
                }
            });
        };

        return{
            getApplications : getApplications
        };
    }])
//Notes and Documents
    .factory('FarmNotesAndDocumentsFactory', ['$http','baseURL', function($http,baseURL){
        return{
            getNoteGroups : function(farmId){
                return $http({
                    method: 'GET',
                    url : baseURL+'notegroup?farm_id='+farmId,
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });
            },

            postNoteGroup : function(farmId, newNoteGroup){
                return $http({
                    method: 'POST',
                    url : baseURL+'notegroup?farm_id='+farmId,
                    data : newNoteGroup,
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });
            },

            updateNoteGroup : function(noteGroupId, noteGroup){
                return $http({
                    method: 'PUT',
                    url : baseURL+'notegroup/'+noteGroupId,
                    data : noteGroup,
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });
            },

            deleteNoteGroup : function(noteGroupId){
                return $http({
                    method: 'DELETE',
                    url : baseURL+'notegroup/'+noteGroupId,
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });
            },

            postNote : function(newNote){
                return $http({
                    method: 'POST',
                    url : baseURL+'note',
                    data : newNote,
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });
            },

            updateNote : function(noteId, note){
                return $http({
                    method: 'PUT',
                    url : baseURL+'note/'+noteId,
                    data : note,
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });
            },

            deleteNote : function(noteId){
                return $http({
                    method: 'DELETE',
                    url : baseURL+'note/' + noteId,
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });
            },

            postNoteGroupTag : function(noteGroupTag){
                return $http({
                    method: 'POST',
                    url : baseURL+'notegrouptags',
                    data : noteGroupTag,
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });
            },

            getNoteGroupTags : function(){
                return $http({
                    method: 'GET',
                    url : baseURL+'notetagtypes',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });
            },

            deleteNoteGroupTag : function(deleteObj){
                return $http({
                    method: 'DELETE',
                    url : baseURL+'notegrouptags',
                    data : deleteObj,
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });
            },


        };

    }])

//farm scores services

.factory('farmService', ['$http','baseURL','$q',function($http,baseURL,$q){

        return {
            fetchAppScores: function(farmID) {
                var url = baseURL + 'farmscore/'+ farmID;
                return $http.get(url)
                        .then(
                        function(response) {
                            return response.data;
                        },
                        function(errResponse) {
                            console.error('Error while fetching Score Details');
                        }
                );
            },
                    getEditAppScore: function (scoreGUID) {
                        var url = baseURL + 'score/'+scoreGUID;
                        return $http.get(url)
                                .then(
                                        function (response) {
                                            return response.data;
                                        },
                                        function (errResponse) {
                                            console.error('Error while fetching App Scores');
                                            //return $q.reject(errResponse);
                                        }
                                );
                    },
                     fetchScoreStatus: function (farmID) {
                        var url = baseURL + 'scorestatus';
                        return $http.get(url)
                                .then(
                                        function (response) {
                                            return response.data;
                                        },
                                        function (errResponse) {
                                            console.error('Error while fetching App Scores');
                                            //return $q.reject(errResponse);
                                        }
                                );
                    },

                    checkfarmID: function (farmID) {
                        console.log(farmID);
                        if (farmID != '' && farmID != null && farmID != undefined) {
                            return true;
                        } else {
                            return false;
                        }

            }
        };
    }])

//Farm Documents Services

.factory('FarmDocService', ['$http','baseURL','$q',function($http,baseURL,$q){

        return {
                        fetchAppDocs: function(farmID) {
                var url = baseURL + 'document?farm_id='+farmID;
                return $http.get(url)
                        .then(
                        function(response) {
                            return response.data;
                        },
                        function(errResponse) {
                            console.error('Error while fetching Documents List');
                            //return $q.reject(errResponse);
                        }
                );
            },
             downloadDoc: function(docID) {
                var url =  baseURL + 'doc/'+ docID;
                return $http.get(url)
                        .then(
                        function(response) {
                            return response.data;
                        },
                        function(errResponse) {
                            console.error('Error while downloading Document');
                        }
                );
            },
              deleteAppDoc: function(docID,farmID) {
                var url = baseURL+ 'document/'+ docID;
                var deleteData = {'farm_id':farmID};
                return $http({
                    method: 'DELETE',
                    url : url,
                    data : deleteData,
                    headers: {
                        'Content-Type': 'application/json'
                    }
                }).then(
                        function(response) {
                            return response.data;
                        },
                        function(errResponse) {
                            console.error('Error while Deleting Document');

                        }
                );
            },
            fetchUploadDocType: function(farmID) {
                var url = baseURL + 'documenttype';
                return $http.get(url)
                        .then(
                        function(response) {
                            return response.data;
                        },
                        function(errResponse) {
                            console.error('Error while fetching Document Type Details');

                        }
                );
            },
            fetchUploadDocStatus: function(farmID) {
                var url = baseURL + 'documentstatus';
                return $http.get(url)
                        .then(
                        function(response) {
                            return response.data;
                        },
                        function(errResponse) {
                            console.error('Error while fetching Document Status Details');

                        }
                );
            },
            fetchUploadDocTags: function(farmID) {
                var url =  baseURL + 'documenttagtype';
                return $http.get(url)
                        .then(
                        function(response) {
                            return response.data;
                        },
                        function(errResponse) {
                            console.error('Error while fetching Document Tags Details');
                            //return $q.reject(errResponse);
                        }
                );
            },
            fetchUploadedDoc: function(farmID, docGUID) {
                var url = baseURL + 'document/'+ docGUID;
                return $http.get(url)
                        .then(
                        function(response) {
                            return response.data;
                        },
                        function(errResponse) {
                            console.error('Error while fetching Document Details');

                        }
                );
            },
            uploadEditDocument: function(putData, docGUID) { console.log(putData, docGUID);
                var url = baseURL + 'document/' + docGUID;
                return $http.put(url, putData)
                        .then(
                        function(response) {
                            return response;
                        },
                        function(errResponse) {
                            console.error('Error while Editing Document Details');
                            //return $q.reject(errResponse);
                        }
                );
            },
            uploadDocument: function (formData, farmID) {

                        var url =  baseURL + 'doc?farm_id=' + farmID; // replace with post url
                       return $http({
                       method: 'POST',
                       url : url,
                       headers: {
                        'Content-Type': undefined
                    },
                         data : formData
                })  .then(
                                        function (response) {
                                            toastr.clear();
                                            toastr.success('Document Uploaded successfully', 'Success');
                                            return response.data;
                                        },
                                        function (errResponse) {
                                            toastr.clear();
                                            toastr.error('Bad Connectivity / Server Error', 'Error while Uploading Document');
                                        }
                                );
            },
                     checkfarmID: function (farmID) {
                        console.log(farmID);
                        if (farmID != '' && farmID != null && farmID != undefined) {
                            return true;
                        } else {
                            return false;
                        }

            }
        };
    }])

//Farm To-Do services

.factory('FarmToDoService', ['$http','baseURL','$q',function($http,baseURL,$q){

        return {
                        fetchAppToDoList: function(farmID) {
                return $http.get(baseURL+'farmtodo?farm_id='+farmID)
                        .then(
                        function(response) {
                            return response.data;
                        },
                        function(errResponse) {
                            console.error('Error while fetching Application ToDo List');
                        }
                );
            },
            fetchAppToDoListToMe: function(farmID) {
                return $http.get(baseURL+'mytodos?farm_id='+farmID)
                        .then(
                        function(response) {
                            return response.data;
                        },
                        function(errResponse) {
                            console.error('Error while fetching Assigned ToDo List');
                        }
                );
            },
            fetchAppToDoItem: function(toDoItemGUID) {
                return $http.get(baseURL+'farmtodo/'+toDoItemGUID)
                        .then(
                        function(response) {
                            return response.data;
                        },
                        function(errResponse) {
                            console.error('Error while fetching Application ToDo Item Service');
                        }
                );
            },
            deleteAppToDoItem: function(toDoItemGUID) {
                var url = baseURL+'farmtodo/'+toDoItemGUID;
                return $http.delete(url)
                        .then(
                        function(response) {
                            return response.data;
                        },
                        function(errResponse) {
                            console.error('Error while deleting ToDo Item');
                        }
                );
            },
            markAppToDoItem: function(toDoItemGUID,completeflg) {
                var markData = {
                    'complete_todo': completeflg
                };
                var url = baseURL+'todo/'+toDoItemGUID;
                return $http.put(url, markData)
                        .then(
                        function(response) {
                            return response.data;
                        },
                        function(errResponse) {
                            console.error('Error while marking ToDo Item as Completed');
                        }
                );
            },
            editAppToDoItem: function(putData, toDoItemGUID) {
                console.log(putData);
                var url = baseURL+'farmtodo/'+toDoItemGUID;
                return $http.put(url, putData)
                        .then(
                        function(response) {
                        toastr.clear();
                        toastr.success('ToDo Item data saved successfully', 'Success');
                            return response.data;
                        },
                        function(errResponse) {
                            toastr.clear();
                            toastr.error('Bad Connectivity / Server Error', 'Error while editing ToDoItem');
                        }
                );
            },
            addAppToDoItem: function(postData, farmID) {
                console.log(postData);
                var url = baseURL+'farmtodo?farm_id=' + farmID; // replace with post url
                return $http.post(url, postData)
                        .then(
                        function(response) {
                        toastr.clear();
                        toastr.success('ToDo Item added successfully', 'Success');
                            return response.data;
                        },
                        function(errResponse) {
                            toastr.clear();
                            toastr.error('Bad Connectivity / Server Error', 'Error while Adding ToDoItem');
                        }
                );
            },
            fetchRolesList: function(farmID) {
                var url = baseURL+'roles';
                return $http.get(url)
                        .then(
                        function(response) {
                            return response.data;
                        },
                        function(errResponse) {
                            console.error('Error while adding ToDo Item');
                        }
                );
            },
            fetchUsersList: function(farmID) {
                var url = baseURL+'users';
                return $http.get(url)
                        .then(
                        function(response) {
                            return response.data;
                        },
                        function(errResponse) {
                            console.error('Error while adding ToDo Item');
                        }
                );
            },
                     checkfarmID: function (farmID) {
                        console.log(farmID);
                        if (farmID != '' && farmID != null && farmID != undefined) {
                            return true;
                        } else {
                            return false;
                        }

            }
        };
    }]);

