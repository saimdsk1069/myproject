(function () {
    'use strict';
}());

angular.module('agSADCeFarms')
    .controller('FarmBaseController',function($scope,$state,GetfarmInfo) {
        $scope.toggleCollapse = false;
        $scope.farmid = $state.params.farm_id;


        $scope.ui_components = {
            'ui_farmdashboard_applications': true,
            'ui_farmdashboard_expenses': true,
            'ui_farmdashboard_contacts': true,
            'ui_farmdashboard_scores': true,
            'ui_farmdashboard_expenseedit': true
        };

    });

angular.module('agSADCeFarms')
    .constant('errorImageURL', '../app/images/error-404.png')
    .controller('FarmController', ['$scope', '$uibModal', '$state', '$log',
        function($scope,$uibModal,$state,$log,modalService,modalMessageService) {

        if($state.params.farm_id == null || typeof($state.params.farm_id) == undefined || $state.params.farm_id == ''){
            $state.go('app.home');
        }
    }]);

//FarmInfo
angular.module('agSADCeFarms')
    .controller('FarmInfoController', ['$scope','$uibModal','GetfarmInfo','DeleteFarmTags',
        'GetFarmTags','$log','modalMessageService','$stateParams','errorImageURL','modalService',
        function($scope, $uibModal,GetfarmInfo,DeleteFarmTags,GetFarmTags,$log,modalMessageService,
          $stateParams, errorImageURL,modalService){


        //Get Farm Details
        var farmInfo = GetfarmInfo.getFarmInfo($scope.farmid).get()
           .$promise.then(
              function(response){
                $scope.FarmInfo =response;
              });




        $scope.parents = [];
        $scope.children = [];
        $scope.current_flg = false;
        var FICtrl = this;
        FICtrl.showErrorMessage = false;
        FICtrl.errorImageURL = errorImageURL;
         FICtrl.getFarmId = function(){
            return $stateParams.farm_id;
         };

        FICtrl.tagOrder= {};
        FICtrl.farmInfo = GetfarmInfo.getFarmInfo(FICtrl.getFarmId()).get()
                  .$promise.then(
                    function(response){
                       FICtrl.farmInfo =response;
                       $scope.current_flg = FICtrl.farmInfo.current_flg;
                       $scope.parents = FICtrl.farmInfo.farm_lineage.parents;
                       $scope.children = FICtrl.farmInfo.farm_lineage.children;

                    },
                    function(response) {
                    $log.debug("ERROR GETTING FarmInfo:", response);
                         if ( response.data === '{ "error": "Bad Request UE" }' ) {
                             toastr.error('Error occured while fetching FarmInfo');
                         } else {
                             toastr.error("Please enter a valid Farm ID");
                             FICtrl.showErrorMessage = true;
                         }
                         $log.debug("Error: "+ response.status + " " + response.statusText);

                    }

                 );


        //Tages edit mode
        FICtrl.isTagsInEditMode = false;

        FICtrl.putTagsInEditMode = function(){
            FICtrl.isTagsInEditMode = true;
        };

        FICtrl.putTagsToNormalMode = function(){
            FICtrl.isTagsInEditMode = false;
        };

        $scope.redirectFarm = function(farmID){
            window.location.href = '#farm/'+farmID;
        };

        FICtrl.deleteTag = function(index){
            var deletefarm = {
                         "farm_id": FICtrl.farmInfo.farm_tags[index].farm_id,
                         "farm_tag_desc":  FICtrl.farmInfo.farm_tags[index].farm_tag_desc};
           DeleteFarmTags.deleteFarmTags(deletefarm)
                            .then(
                               function(response){
                                  console.log(response);
                                  console.log('farm Tag deleted');
                                   FICtrl.refreshFarmTags();
                                   toastr.success('Tag deleted successfully');
                               },
                               function(response) {
                                    $log.debug("ERROR Delete  tag:", response);
                                    toastr.error('Error occured while deleting tag');
                                    $log.debug("Error: "+response.status + " " + response.statusText);
                                }
                          );
        };

        FICtrl.refreshFarmTags = function(){
            GetFarmTags.getFarmTags(FICtrl.farmInfo.farm_id)
                  .then(
                    function(response){
                       FICtrl.farmInfo.farm_tags =response;
                    },
                    function(response) {
                    $log.debug("ERROR GETTING FUNDDETAILS:", response);
                         if ( response.data === '{ "error": "Bad Request UE" }' ) {
                             modalMessageService.showMessage( "Error:", "Check the service");
                         } else {
                             modalMessageService.showMessage( "Error:", "An error occurred. ");
                         }
                         $log.debug("Error: "+response.status + " " + response.statusText);

                    }

                 );
        };

        FICtrl.createNewTag = function(){
        var farmID = FICtrl.farmInfo.farm_id;
            var modalInstance = $uibModal.open({
              animation: true,
                size: 'sm',
                static : true,
              templateUrl: 'views/farm/add_new_tag_modal.html',
              backdrop: 'static',
                resolve:{
                farm_id : function(){
                  return FICtrl.farmInfo.farm_id;
                }
              },
              controller: ['$scope','$uibModalInstance','AddNewTag','getTagTypes','farm_id',
                  function($scope, $uibModalInstance, AddNewTag,getTagTypes,farm_id){
                  getTagTypes.getTagTypes().then(function(response){
                      $scope.tagTypes = response.data;
                    }, function(response){
                      toastr.warning('Error while getting TagTypes');
                    });
                  $scope.ok= function(){
                      var newTag = {
                          "farm_id": farmID,
                          "farm_tag_desc": $scope.tagDescription.farm_tag_desc};
                    AddNewTag.addNewTag().save(newTag)
                            .$promise.then(
                               function(response){
                                  $uibModalInstance.close();
                                  toastr.success('Tag added successfully');
                               },
                               function(response) {
                                    $log.debug("ERROR ADDING TODOITEM:", response);
                                    toastr.error('Error occured while adding tag');
                                    $log.debug("Error: "+response.status + " " + response.statusText);
                                    $uibModalInstance.close();
                                }
                          );

                };
                $scope.cancel= function(){
                    $uibModalInstance.dismiss();
                };
              }]

            });

            modalInstance.result.then(function () {
              FICtrl.refreshFarmTags();
            }, function () {

            });
        };
    }])

//Farm Applications
.controller('FarmApplicationsCtrl', ['$scope', 'FarmApplicationsFactory','$stateParams','$log',
  'errorImageURL','$state',
 function($scope, FAF, $stateParams,$log, errorImageURL, $state){
  var FAC = this;
  var onLoad = function(){
    FAC.showErrorMessage = false;
    FAC.errorImageURL = errorImageURL;
    var preAppLink = "<div class='ui-grid-cell-contents'> <a class='myDAppLink' href='#application/{{row.entity.application_id}}'><u>{{row.entity.application_id}}</u></a> </div>";
     //Grid Config
    FAC.columnDefs = [
      {field: 'application_id',displayName: 'Application ID', visible: true,  width: 140, cellTooltip: true, cellTemplate:preAppLink},

      { field: 'application_type', displayName: 'Application Type', enableHiding: false, pinnedLeft:false },
      { field: 'application_category', displayName: 'Application Category',  enableHiding: false, pinnedLeft:false },

      { field: 'application_phase', displayName: 'Application phase', width: 140},

      { field: 'application_status', displayName: 'Application Status', width: 150  },
      { field: 'application_date', displayName: 'Application Date',cellFilter: 'date:"MMM dd,y"'  },
      { field: 'partner_name', displayName: 'Partner Name',  },
      { field: 'program_type', displayName: 'Program type', width: 140 },

      {field: 'last_edited_date',displayName:'Last Edited Date', width: 135}

    ];

    FAC.gridOptions = {
        enablePaginationControls: false,
        paginationPageSize: 25,
        enableFiltering: true,
        saveSelection: true,
        multiSelect: false,
        enableRowSelection: false,
        enableFullRowSelection: false,
        enableRowHeaderSelection: false,
        enableColumnResizing: true,
        enableGridMenu: true,
        exporterCsvFilename: 'Farm_Applications.csv',
        exporterPdfDefaultStyle: {fontSize: 12},
        exporterMenuVisibleData : true,
        exporterPdfTableStyle: {margin: [60, 60, 60, 60]},
        exporterPdfTableHeaderStyle: {fontSize: 12, bold: true, italics: true, color: 'black'},
        exporterPdfHeader: { text: "Farm Applications Details", style: 'headerStyle' },
        exporterPdfFooter: function ( currentPage, pageCount ) {
          return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' };
        },
        exporterPdfCustomFormatter: function ( docDefinition ) {
          docDefinition.styles.headerStyle = { fontSize: 22, bold: true };
          docDefinition.styles.footerStyle = { fontSize: 10, bold: true };
          return docDefinition;
        },
        exporterPdfOrientation: 'landscape',
        exporterPdfPageSize: 'LETTER',
        exporterPdfMaxGridWidth: 500,
        exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
        exporterExcelFilename: 'Farm_Applications.xlsx',
        exporterExcelSheetName: 'Sheet1',
        selectionRowHeaderWidth: 50,
        rowHeight: 35,
        showGridFooter:true,
        columnDefs : FAC.columnDefs
    };
    FAC.refreshApplications();
  };


  FAC.getFarmId = function(){
    return $stateParams.farm_id;
  };

  FAC.refreshApplications = function(){
    FAF.getApplications(FAC.getFarmId()).then(function(response){
      FAC.applications = response.data;
      FAC.gridOptions.data = response.data;
    },function(response){
      $log.debug("ERROR GETTING Applications details:", response);
        if ( response.data === '{ "error": "Bad Request UE" }' ) {
           toastr.error('Error occured while fetching farm contacts.');
        } else {
           toastr.error( "Please enter a valid farmid ");
           FAC.showErrorMessage = true;
        }
        $log.debug("Error: "+response.status + " " + response.statusText);
    });
  };

  FAC.viewAppliction = function(){
    if(FAC.gridApiApplications.selection.getSelectedRows().length <1){
      toastr.warning('Select atleast one appliction row to view');
    }else{
      var guid = FAC.gridApiApplications.selection.getSelectedRows()[0].application_id;
      $state.go('app.application.appinfo', {ID : guid});
    }
  };


  onLoad();

}])

//Notes and documents
.controller('FarmNotesAndDocumentsCtrl', ['$scope', 'FarmNotesAndDocumentsFactory', '$stateParams', '$log',
  'errorImageURL','$state','modalMessageService','modalService','$uibModal', '$filter',
  function($scope, FNADF, $stateParams, $log, errorImageURL,$state,modalMessageService,modalService, $uibModal, $filter){
    var FNADC = this;

    var onLoad = function(){
      FNADC.showErrorMessage = false;
      FNADC.errorImageURL = errorImageURL;
      FNADC.refreshNoteGroups();
      FNADC.notesAccordionOpenCloseStatus = false;
      FNADC.notesSortByOption ={};
      FNADC.isAllNotesInExpandedView = true;
      $scope.searchNoteGroup = 1;
      FNADC.noteGroupIdInExpandedMode = '';

      FNADF.getNoteGroupTags().then(function(resp){
        if(resp.status==200){
            FNADC.allAvailalbeTags = resp.data;
        }else{
            console.log(resp);
            toastr.error('Error occured while fectching tags');
        }
    }, function(){
        if(resp.status==200){
            FNADC.allAvailalbeTags = resp.data;
        }else{
            console.log(resp);
            toastr.error('Error occured while fectching tags');
        }
    });
    };

    $scope.onTagSelected = function(tag){
        if(tag){
              $scope.searchNoteGroup={'tags':[]};
              $scope.searchNoteGroup['tags']['tag_desc'] = tag.tag_desc;
        }else{
              $scope.searchNoteGroup = 1;
        }

    };
     $scope.modelOptions = {
                    debounce: {
                        default: 500,
                        blur: 250
                    },
                    getterSetter: true
                };
    FNADC.getFarmId = function(){
      return $stateParams.farm_id;
    };

    FNADC.refreshNoteGroups = function(){
        FNADF.getNoteGroups(FNADC.getFarmId()).then(
            function(result){
                FNADC.noteGroups = result.data;
                FNADC.notesAccordionArray = [];
                for(var i=0; i< result.data.length;i++){
                    var noteGroupGuid = FNADC.noteGroups[i].note_group_guid;
                    if(FNADC.noteGroupIdInExpandedMode == noteGroupGuid) {
                         FNADC.noteGroups[i]['isExpanded']=true;
                         FNADC.noteGroupIdInExpandedMode = '';
                    } else {
                        FNADC.noteGroups[i]['isExpanded']=false;
                    }

                }
            },function(res){
                console.log(res);
                toastr.error('error occured while fetching note groups');
            }
        );
    };

    FNADC.setNoteGroupIdInExpandedMode = function(noteGroupId){
        FNADC.noteGroupIdInExpandedMode = noteGroupId;
    }

    FNADC.addNewNoteGroup = function($event){
        $event.preventDefault();
        $event.stopPropagation();
        var newNoteGroup = {
            note_group_title : '',
            sadc_flg : false,
            notes : [],
            tags : []
        };
        upsertNoteGroup(newNoteGroup, true);
    };

    FNADC.editNoteGroup = function($event, noteGroup){
        $event.preventDefault();
        $event.stopPropagation();
        upsertNoteGroup(noteGroup, false);
    };

    var upsertNoteGroup = function(noteGroup, isNewNoteGroup){
        var modalInstance = $uibModal.open({
            animation: true,
            static : true,
            templateUrl: 'views/farm/farmNotesAndDocuments/mdl_upsert_note_group.html',
            backdrop: 'static',
            controller: 'UpsertNoteGroupModalCtrl',
            controllerAs : 'UNGMC',
            resolve:{
              resolvedObj : function(){
                var obj = {
                    noteGroup : angular.copy(noteGroup),
                    farmId : FNADC.getFarmId(),
                    isNewNoteGroup : isNewNoteGroup
                };
                return obj;
              }
            }
          });

          modalInstance.result.then(function (noteGroupGuid) {
            FNADC.noteGroupIdInExpandedMode = noteGroupGuid;
            FNADC.refreshNoteGroups();
          }, function () {

          });
    };

     FNADC.downloadPDFNote = function ($event,noteGroupID) {

                    var targetNoteGroup = '';

                    var doc = new jsPDF();
                    $.each($('#appNoteGroup-' + noteGroupID).find('drtv-note'), function(index, value){
                       if(targetNoteGroup.length>0){
                           targetNoteGroup = targetNoteGroup + '\n\n';
                       }
                       targetNoteGroup = targetNoteGroup + value.innerText.trim('');
                    });

                    targetNoteGroup = doc.splitTextToSize(targetNoteGroup, 180);

                    doc.text(targetNoteGroup, 10, 10);
                    doc.save('PDFnoteGroup-' + noteGroupID + '.pdf');
                };

    FNADC.addNewNote = function($event, noteGroupId){
        $event.preventDefault();
        $event.stopPropagation();

        var modalInstance = $uibModal.open({
            animation: true,
            static : true,
            templateUrl: 'views/farm/farmNotesAndDocuments/mdl_upsert_note.html',
            backdrop: 'static',
            controller: 'UpsertNoteModalCtrl',
            controllerAs : 'UNMCTRL',
            size: 'md',
            resolve:{
              noteObj : function(){
                var newNote = {
                    note_group_guid : noteGroupId,
                    note_text : ''
                };
                return newNote;
              }
            }
          });
          modalInstance.result.then(function () {
            FNADC.noteGroupIdInExpandedMode = noteGroupId;
            FNADC.refreshNoteGroups();

          }, function () {
          });
    };

    FNADC.addNewDocument = function(){
      var modalInstance = $uibModal.open({
            animation: true,
            static : true,
            templateUrl: 'views/farm/farmcontacts/mdl_upload_file.html',
            backdrop: 'static',
            size: 'md',
            controller: ['$uibModalInstance', function($uibModalInstance){
              var ANDMCTRL = this;
              ANDMCTRL.cancel = function(){
                $uibModalInstance.dismiss();
              };
            }],
            controllerAs : 'ANDMCTRL'
          });

          modalInstance.result.then(function () {
            FNADC.refreshDocuments();
          }, function () {

          });
    };


    FNADC.noteGroupsSortBy = function(){
        if(FNADC.noteGroupsSortByOption == 'old'){
            FNADC.noteGroups= $filter('orderBy')(FNADC.noteGroups, 'last_edited_date');
            var noteGroupsLen = FNADC.noteGroups.length;
            for(var i =0; i< noteGroupsLen; i++){
                FNADC.noteGroups[i].notes = $filter('orderBy')(FNADC.noteGroups[i].notes, 'last_edited_date');
            }
        }else{
            FNADC.noteGroups= $filter('orderBy')(FNADC.noteGroups, '-last_edited_date');
            var noteGroupsLen1 = FNADC.noteGroups.length;
            for(var j =0; j< noteGroupsLen; j++){
                FNADC.noteGroups[i].notes = $filter('orderBy')(FNADC.noteGroups[i].notes, '-last_edited_date');
            }
        }
    };

    FNADC.notesSortBy = function(noteGroupId, bool){
        for(var i=0; i<FNADC.noteGroups.length; i++){
            if(FNADC.noteGroups[i].note_group_guid == noteGroupId){
                if(bool == 'old'){
            FNADC.noteGroups[i].notes = $filter('orderBy')(FNADC.noteGroups[i].notes, 'last_edited_date');
        }else{
            FNADC.noteGroups[i].notes = $filter('orderBy')(FNADC.noteGroups[i].notes, '-last_edited_date');
        }
            }
        }

    };


    FNADC.deleteNoteGroup = function($event, noteGroupId){
    var modalOptions = {
                        closeButtonText: 'No',
                        actionButtonText: 'Yes',
                        headerText: 'Warning',
                        bodyText: 'Are you sure you want to delete this item?'
                     };
                         modalService.showModal({}, modalOptions)
                            .then(function (result) {
        $event.preventDefault();
        $event.stopPropagation();
        FNADF.deleteNoteGroup(noteGroupId).then(function(){
            toastr.success('Note Group Deleted');
            FNADC.refreshNoteGroups();
        },function(res){
            console.log(res);
            toastr.error('error occured while delete noteGroup');
        });
        });
    };
FNADC.toggleNotesExpandedView = function() {
        for(var i=0; i<FNADC.noteGroups.length; i++){
            FNADC.noteGroups[i]['isExpanded'] = FNADC.isAllNotesInExpandedView;
        }
        FNADC.isAllNotesInExpandedView = !FNADC.isAllNotesInExpandedView;
    }
  onLoad();
}])

.directive('drtvNote', [function(){
  return{
    restrict : 'E',
    scope : {
      note :'=',
      refreshFn : '&',
      setNoteGroupIdInExpandedMode: '&',
      sadcFlg : '=',
      noteGroupId : '='
    },
    bindToController : true,
    templateUrl: 'views/farm/farmNotesAndDocuments/drtvNote.html',
    controllerAs : 'NDCTRL',
    controller : ['$uibModal','FarmNotesAndDocumentsFactory','$q','modalMessageService','modalService', function($uibModal,FNADF, $q,modalMessageService,modalService){
    var NDCTRL = this;

      NDCTRL.deleteNote = function(){
      var modalOptions = {
                        closeButtonText: 'No',
                        actionButtonText: 'Yes',
                        headerText: 'Warning',
                        bodyText: 'Are you sure you want to delete this item?'
                     };
                         modalService.showModal({}, modalOptions)
                            .then(function (result) {
        FNADF.deleteNote(NDCTRL.note.note_guid).then(function(){
            toastr.success('Note Deleted');
            NDCTRL.setNoteGroupIdInExpandedMode()(NDCTRL.noteGroupId);
            NDCTRL.refreshFn();
        },function(res){
            console.log(res);
            toastr.error('error occured while deleting note');
        });
        });
      };

      NDCTRL.saveNoteText = function(data){
        var d = $q.defer();
        var noteObj = angular.copy(NDCTRL.note);
        noteObj.note_text = data;
        FNADF.updateNote(NDCTRL.note.note_guid, noteObj).then(function(resp){
                if(resp.status == 200){
//                    NDCTRL.note.note_text = noteObj.note_text;
                    d.resolve();
                    toastr.success('Notes Updated');
                }else{
                    d.resolve(resp);
                }
            },function(resp){
                console.log(resp);
                d.resolve(resp);
                toastr.error('some error occured while Updating note group');
            });
            return d.promise;
      };

      NDCTRL.editNote = function(){
          var modalInstance = $uibModal.open({
            animation: true,
            size: 'md',
            static : true,
            templateUrl: 'views/farm/farmNotesAndDocuments/mdl_upsert_note.html',
            backdrop: 'static',
            controller: 'UpsertNoteModalCtrl',
            controllerAs : 'UNMCTRL',
            resolve:{
              noteObj : function(){
                return NDCTRL.note;
              }
            }
          });

          modalInstance.result.then(function () {
            NDCTRL.setNoteGroupIdInExpandedMode(NDCTRL.noteGroupId);
            NDCTRL.refreshFn();
          }, function () {

          });
      };
         NDCTRL.downloadPDFNote = function (noteID) {
                                //console.log('Print This --', noteID);
                                var targetNotes = $('#note-'+noteID).html().trim();

                                var doc = new jsPDF();
                                var splitTitle = doc.splitTextToSize(targetNotes, 180);
                                doc.text(splitTitle, 10, 10);
                                doc.save('PDFnote-'+noteID+'.pdf');
                            };

    }]

  };
}])

.controller('UpsertNoteModalCtrl', ['$scope', '$uibModalInstance', 'noteObj','FarmNotesAndDocumentsFactory',
 function($scope, $uibModalInstance, note, FNADF){
  var UNMCTRL = this;

  var onLoad = function(){
     UNMCTRL.note = note;
     UNMCTRL.submitted = false;
  };

  UNMCTRL.save = function(){
    if(!$scope.upsertNoteForm.$invalid){
        if(!UNMCTRL.note.note_guid){
            FNADF.postNote(UNMCTRL.note).then(function(){
                toastr.success('New Note created');
                $uibModalInstance.close();
            },function(resp){
                console.log(resp);
                toastr.error('some error occured while saving note group');
            });
        }else{
            FNADF.updateNote(UNMCTRL.note.note_guid, UNMCTRL.note).then(function(){
                toastr.success('New Notes Group created');
                $uibModalInstance.close();
            },function(resp){
                console.log(resp);
                toastr.error('some error occured while Updating note group');
            });
        }
    }else{
        UNMCTRL.submitted = true;
        toastr.warning('Fill all the required fields');
    }
  };
  UNMCTRL.cancel = function(){
    $uibModalInstance.dismiss();
  };
  onLoad();
}])

.controller('UpsertNoteGroupModalCtrl', ['$scope', '$uibModalInstance', 'resolvedObj','FarmNotesAndDocumentsFactory','$uibModal',
 function($scope, $uibModalInstance, resolvedObj, FNADF, $uibModal){
  var UNGMC = this;

  var onLoad = function(){
    UNGMC.noteGroup = resolvedObj.noteGroup;
    UNGMC.submitted = false;
    UNGMC.isNewNoteGroup = resolvedObj.isNewNoteGroup;
    FNADF.getNoteGroupTags().then(function(resp){
        if(resp.status==200){
            UNGMC.allAvailalbeTags = resp.data;
        }else{
            console.log(resp);
            toastr.error('Error occured while fectching tags');
        }
    }, function(){
        if(resp.status==200){
            UNGMC.allAvailalbeTags = resp.data;
        }else{
            console.log(resp);
            toastr.error('Error occured while fectching tags');
        }
    });
  };
    UNGMC.addNoteGroupTag = function(){
        if(UNGMC.selectedTag.length > 0 && !isExistsInAlreadySelectedTags()){
        $scope.tagsError = false;
            UNGMC.noteGroup.tags.push({"tag_desc" : UNGMC.selectedTag});
            UNGMC.selectedTag ="";
        }
    };

    var isExistsInAlreadySelectedTags = function(){
        for(var i=0; i<UNGMC.noteGroup.tags.length; i++){
            if(UNGMC.noteGroup.tags[i].tag_desc == UNGMC.selectedTag){
                return true;
            }
        }
        return false;
    };

  UNGMC.deleteNoteGroupTag = function(index){
    UNGMC.noteGroup.tags.splice(index, 1);
    toastr.success('Removed tag');
  };

  UNGMC.permissions = [
    {key : true, value : 'SADC staff'},
    {key : false, value : 'Public'}
  ];

  $scope.tagsError = false;

  UNGMC.save = function(){
    if(!$scope.upsertNoteGroupForm.$invalid && UNGMC.noteGroup.tags.length > 0){
        if(!UNGMC.noteGroup.note_group_guid){
            var note = UNGMC.noteGroup.note_text;
            UNGMC.noteGroup.notes = [
                {
                    "note_text": note
                }
            ];
            FNADF.postNoteGroup(resolvedObj.farmId, UNGMC.noteGroup).then(function(resp){
                toastr.success('New Notes Group created');
                $uibModalInstance.close(resp.data.note_group_guid);
            },function(resp){
                console.log(resp);
                toastr.error('some error occured while saving note group');
            });
        }else{
            FNADF.updateNoteGroup(UNGMC.noteGroup.note_group_guid, UNGMC.noteGroup).then(function(resp){
                toastr.success(' Notes Group updated');
                $uibModalInstance.close(resp.data.note_group_guid);
            },function(resp){
                console.log(resp);
                toastr.error('some error occured while updatind note group');
            });
        }
    }else{
        UNGMC.submitted = true;
        toastr.warning('Fill all the required fields');
        $scope.tagsError = true;
    }
  };
  UNGMC.cancel = function(){
    $uibModalInstance.dismiss();
  };
  onLoad();
}])
.controller('FarmExpenseController', ['$scope', '$uibModal','$stateParams','$location','$filter','ExpenseDataService','AuthService','GetFarmExpense','GetExpenseData','GetExpense','DeleteExpense','$state', '$log','modalService','modalMessageService',
 function($scope,$uibModal,$stateParams,$location,$filter,ExpenseDataService,AuthService,GetFarmExpense,GetExpenseData,GetExpense,DeleteExpense,$state,$log,modalService,modalMessageService){



$scope.selectedExpenseData = ExpenseDataService.getSelectedExpense()[0];
$scope.selectedExpensePayment = _.get($scope.selectedExpenseData, 'expense_payments');
$scope.selectedExpenseCostshare = _.get($scope.selectedExpenseData, 'cost_share_json');

//   Ui Components
     $scope.ui_components = {
            'ui_farmdashboard_expenseedit':false,
            'ui_farmdashboard_expenses':false
        };

var farmid = $state.params.farm_id;
var farmExpLink = "<div class='ui-grid-cell-contents'> <a class='myFAppLink' href='#farm/{{row.entity.farm_id}}/expense_details/{{row.entity.expense_guid}}'><u>{{row.entity.expense_description}}</u></a> </div>";
//  Expenses
$scope.gridExpenses = {
            enableSorting :true,
            enablePaginationControls: true,
            paginationPageSize: 25,
            enableFiltering: true,
            saveSelection: true,
            enableRowHeaderSelection: false,
            selectionRowHeaderWidth: 50,
            multiSelect: false,
            rowHeight: 35,
            showGridFooter:false,
            selectedItems: [],
            enableGridMenu: true,
            exporterCsvFilename: 'Farm_Expenses.csv',
            exporterPdfDefaultStyle: {fontSize: 12},
            exporterMenuVisibleData : true,
            exporterPdfTableStyle: {margin: [40, 40, 40, 40]},
            exporterPdfTableHeaderStyle: {fontSize: 12, bold: true, italics: true, color: 'black'},
            exporterPdfHeader: { text: "Farm Expenses Details", style: 'headerStyle' },
            exporterPdfFooter: function ( currentPage, pageCount ) {
              return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' };
            },
            exporterPdfCustomFormatter: function ( docDefinition ) {
              docDefinition.styles.headerStyle = { fontSize: 22, bold: true };
              docDefinition.styles.footerStyle = { fontSize: 10, bold: true };
              return docDefinition;
            },
            exporterPdfOrientation: 'landscape',
            exporterPdfPageSize: 'LETTER',
            exporterPdfMaxGridWidth: 500,
            exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
            exporterExcelFilename: 'Farm_Expenses.xlsx',
            exporterExcelSheetName: 'Sheet1',
            enableRowSelection: true,
            enableFullRowSelection: true,
            appScopeProvider: $scope,
            rowTemplate: '<div ng-click="grid.appScope.viewselExp(row)" ng-repeat="(colRenderIndex, col) in colContainer.renderedColumns track by col.uid" class="ui-grid-cell" ng-class="col.colIndex()" ui-grid-cell></div>',

            columnDefs: [
                  { name:'Expense Description', field: 'expense_description', width: 200,resizable: true,  pinnedLeft:false, cellTemplate: farmExpLink},
                  { name:'Expense Type', field: 'expense_type', width: 200,resizable: true,pinnedLeft:false},
                  { name:'Expense Amount', field: 'expense_amount', width: 200, cellFilter:'currency', pinnedLeft:false },
                  { name:'Municipality', field: 'municipality', width: 250,resizable: true,  pinnedLeft:false},
                  { name:'County', field: 'county', width: 170, resizable: true, pinnedLeft:false},
                  { name:'Status', field: 'expense_status_desc', width: 125, pinnedLeft:false },
                  { name:'Application ID', field: 'application_id', width: 125, pinnedLeft:false},
        ],
    };
            $scope.viewselExp = function(row) {
                var itemguid = row.entity.expense_guid;
                if (itemguid) {
                    var farmguid =  $stateParams.farm_id;
                    $state.go('app.farm.ExpensesDetails',{farm_id:farmguid, expense_guid:itemguid});
                }
            };




// Register the grid for API calls like clearSelectedRows() and getSelectedRows()
$scope.gridExpenseHeight = 'height: ' + ($scope.gridExpenses.paginationPageSize * 35 + 150) + 'px';
$scope.gridExpenses.onRegisterApi = function(gridApiExpenses){
    $scope.gridApiExpenses = gridApiExpenses;
    gridApiExpenses.selection.on.rowSelectionChanged($scope,function(row){
    var msg = 'row selected'+row.isSelected;
     $scope.selectedRows = $scope.gridApiExpenses.selection.getSelectedRows()[0];
     $scope.selectedguidexpense = $scope.selectedRows.expense_guid;
    });
};




// Get Expense details  from service
$scope.getExpenseDetails = function() {
    $scope.loading_data = true;
    var farmguid =  $stateParams.farm_id;
//    console.log("Farm Guid",farmguid);
    GetFarmExpense.getfarmexpense(farmguid).query()
    .$promise.then(
    function(response){
       $scope.expensedetails = response;
        $scope.gridExpenses.data = response;
//        console.log("gridReapprops.data:",$scope.gridExpenses.data );
        $scope.loading_data = false;
    },
    function(response) {
        // If there is an error getting user statuses from database,
        // this will have an error as well.  If so, put the message in the error modal.
        $log.debug("AFTER GETING ERROR FROM DETAILS:", $scope.expensedetails);
        $log.debug("Error: "+response.status + " " + response.statusText);
        modalMessageService.showMessage( "Error:", response.status + " " +
            response.statusText + '. Please contact ' + agSupportEmail);
    }
    );
};


 $scope.farmguid =  $stateParams.farm_id;
//console.log("farm guid",farmguid);



// Do Initial Expense   load
$scope.getExpenseDetails();


// Selected Expenses
    var getExpenseSelection = function(){
        var selectedRows = $scope.gridExpenses.selection.getSelectedRows();
         var expenseSelection = { selectedExpense: {}};
        angular.forEach( selectedRows, function(row){
            var expense_guid = row.expense_guid;
            expenseSelection.selectedExpense[expense_guid] = row;
        });
        $log.debug("Selected Expense Details:", expenseSelection);
        return expenseSelection;
    };




//Expenses Payments Costshare details
$scope.gridExpenseCostshare = {
            enableSorting :true,
            enablePaginationControls: true,
            paginationPageSize: 25,
            enableFiltering: true,
            saveSelection: true,
            enableRowHeaderSelection: true,
            selectionRowHeaderWidth: 50,
            multiSelect: false,
            rowHeight: 35,
            showGridFooter:false,
            selectedItems: [],
            enableGridMenu: true,
            exporterCsvFilename: 'Farm_ExpenseCostshare.csv',
            exporterPdfDefaultStyle: {fontSize: 12},
            exporterMenuVisibleData : true,
            exporterPdfTableStyle: {margin: [40, 40, 40, 40]},
            exporterPdfTableHeaderStyle: {fontSize: 12, bold: true, italics: true, color: 'black'},
            exporterPdfHeader: { text: "Farm ExpenseCostshare Details", style: 'headerStyle' },
            exporterPdfFooter: function ( currentPage, pageCount ) {
              return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' };
            },
            exporterPdfCustomFormatter: function ( docDefinition ) {
              docDefinition.styles.headerStyle = { fontSize: 22, bold: true };
              docDefinition.styles.footerStyle = { fontSize: 10, bold: true };
              return docDefinition;
            },
            exporterPdfOrientation: 'landscape',
            exporterPdfPageSize: 'LETTER',
            exporterPdfMaxGridWidth: 500,
            exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
            exporterExcelFilename: 'Farm_ExpenseCostshare.xlsx',
            exporterExcelSheetName: 'Sheet1',
            columnDefs: [
                  { name:'Cost Per Acre', field: 'cost_per_acre', width: 300, pinnedLeft:false,enableCellEdit:true,},
                  { name:'Source', field: 'payment_source', width: 300,  pinnedLeft:false,enableCellEdit:true,},
                  { name:'Amount', field: 'share_amount', width: 250, cellFilter:'currency', pinnedLeft:false, enableCellEdit:true,},
                  { name:'Description', field: 'share_description', width: 170,  pinnedLeft:false,enableCellEdit:true,},
        ],
    };

if(!!$stateParams){
      $scope.selecteddataexpense = $stateParams;
    }



//Expenses  Details
    $scope.viewSelectedExpense = function(){
    if(!!$scope.selecteddataexpense && !!$scope.selecteddataexpense.expense_guid){
        var expguid = $scope.selecteddataexpense.expense_guid;
        $scope.expguid = $scope.selecteddataexpense.expense_guid;
    //                        console.log($scope.expguid);
        var expensedetailsid = GetExpenseData.getexpensedata(expguid).get()
                              .$promise.then(
                                function(response){

                                    $scope.selectedexpensedetails = response;
//                                    console.log($scope.selectedexpensedetails);
                                    $scope.selecteddatacostshareexpense = _.get($scope.selectedexpensedetails, 'cost_share_json');
                                    $scope.gridExpenseCostshare.data = $scope.selecteddatacostshareexpense;
                                    $scope.selecteddatapaymentexpense = _.get($scope.selectedexpensedetails, 'expense_payments');
                                    $scope.gridExpensePayments.data = $scope.selecteddatapaymentexpense;
//                                    $location.path('/finance/expenses/expensedetail/'+expguid);
                                },
                                function(err){
                                  alert("Service error");
                                }
                             );
        }
    };
    $scope.viewSelectedExpense();

// Expenses Payments details
$scope.gridExpensePayments = {
            enableSorting :true,
            enablePaginationControls: true,
            paginationPageSize: 25,
            enableFiltering: true,
            saveSelection: true,
            enableRowHeaderSelection: true,
            selectionRowHeaderWidth: 50,
            multiSelect: false,
            rowHeight: 35,
            showGridFooter:false,
            selectedItems: [],
            enableGridMenu: true,
            exporterCsvFilename: 'Farm_ExpensePayment.csv',
            exporterPdfDefaultStyle: {fontSize: 12},
            exporterMenuVisibleData : true,
            exporterPdfTableStyle: {margin: [40, 40, 40, 40]},
            exporterPdfTableHeaderStyle: {fontSize: 12, bold: true, italics: true, color: 'black'},
            exporterPdfHeader: { text: "Farm ExpensePayment Details", style: 'headerStyle' },
            exporterPdfFooter: function ( currentPage, pageCount ) {
              return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' };
            },
            exporterPdfCustomFormatter: function ( docDefinition ) {
              docDefinition.styles.headerStyle = { fontSize: 22, bold: true };
              docDefinition.styles.footerStyle = { fontSize: 10, bold: true };
              return docDefinition;
            },
            exporterPdfOrientation: 'landscape',
            exporterPdfPageSize: 'LETTER',
            exporterPdfMaxGridWidth: 500,
            exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
            exporterExcelFilename: 'Farm_expensepayment.xlsx',
            exporterExcelSheetName: 'Sheet1',
            enableRowSelection: true,
            enableFullRowSelection: true,
            appScopeProvider: $scope,
            columnDefs: [
                  { name:'Payment Amount', field: 'payment_amount', width: 300,cellFilter:'currency', pinnedLeft:false},
                  { name:'Payment Source', field: 'payment_source_type', width: 170,  pinnedLeft:false},
                  { name:'Payment Status', field: 'payment_status_desc', width: 170,  pinnedLeft:false},
                  { name:'Payment Comment', field: 'payment_comment', width: 250,  pinnedLeft:false },
                  { name:'Appropriation', field: 'appropriation_name', width: 250,pinnedLeft:false },
                  { name:'From Reappropriation', field: 'reapprop_flag', width: 170, pinnedLeft:false},
                  { name:'Activity Code', field: 'activity_code', width: 170, pinnedLeft:false},
                  { name:'Object Code', field: 'object_code', width: 170,  pinnedLeft:false},
                  { name:'Vendor Code', field: 'vendor_code', width: 170,  pinnedLeft:false},
                  { name:'Vendor Name', field: 'vendor_name', width: 170,  pinnedLeft:false},
        ],

    };



// Delete Expenses  here
    $scope.deleteExpense = function(){
                $scope.expenseguid = $scope.selectedguidexpense;
                 var modalOptions = {
                closeButtonText: 'No',
                actionButtonText: 'Yes',
                headerText: 'Warning',
                bodyText: 'Are you sure you want to delete this item?'
             };
                 modalService.showModal({}, modalOptions)
                    .then(function (result) {
                 DeleteExpense.deleteexpense().delete({expense_guid:$scope.expenseguid})
                    .$promise.then(
                       function(){
                          modalMessageService.showMessage( "Success:","Expense deleted Successfully");
                          $state.reload();
                       },
                       function(response) {
                            $log.debug("ERROR Deleting Expense:", response);
                           if (response.data.result === 'error' ) {
                               modalMessageService.showMessage( "Error:", response.data.message);
                            } else {
                                modalMessageService.showMessage( "Error:", "This Expense cannot be deleted");
                            }
                            $log.debug("Error: "+response.status + " " + response.statusText);
                        }
                  );
                   });
            };

//Check the AuthService here
if ( AuthService.isAuthenticated() ) {
    $scope.ui_components = {
            'ui_farmdashboard_expenseedit':true,
            'ui_farmdashboard_expenses':true
        };
} else {
}




//Add new Expenses
$scope.addExpense = function() {
     var modalInstance = $uibModal.open({
        templateUrl:'views/farm/newexpense.html',
        controller:'FarmExpenseModalController',
        backdrop: 'static',
      });
        modalInstance.result.then(function (modalResponse) {
            }, function () {
                        $log.debug("cancelled the Expense  entry");
            });
    };


//Edit the Expense  here
    $scope.EditExpense = function(){
    var modalInstance = $uibModal.open({
        templateUrl:'views/farm/expenseedit.html',
        controller:'FarmExpenseModalController',
        backdrop: 'static',
        resolve: {
            fundtransitems: function () {
                return null;
            },
        },
    });
    modalInstance.result.then(function (modalResponse) {
                console.log("modalResponse", modalResponse);
            }, function () {
                        $log.debug("cancelled the Expense Edit entry");
            });
    };




}])

.controller('FarmExpenseModalController',function($rootScope,$scope,$stateParams,$log,$state,$filter,$location,FundDataService,$uibModalInstance,GetAppID,PaymentDataService,GetPartner,GetExpenseData,UpdateExpense,ExpenseDataService,GetPaymentSource,GetFarmIDList,GetTransactiontype,GetExpensetype,GetExpensestatus,AddExpense,modalService,modalMessageService){

        // Get Expense Status
 var expensestatus = GetExpensestatus.getexpensestatus().query()
      .$promise.then(
        function(response){
            $scope.expenseststatuslist = response;
        });
$scope.close = function(){
    $uibModalInstance.dismiss();
};



    // Get Expense Types
GetExpensetype.getexpensetype().query()
  .$promise.then(
    function(response){
        $scope.expensetypelist = response;
    });


// Get Expense Status
GetExpensestatus.getexpensestatus().query()
  .$promise.then(
    function(response){
        $scope.expenseststatuslist = response;
    });

$scope.farmguid =  $stateParams.farm_id;
$scope.isReadOnly = true;


$scope.farmguid =  $stateParams.farm_id;
  $scope.application_id = "";
    GetAppID.getappid($scope.farmguid).query()
      .$promise.then(
        function(response){
        $scope.appidlist = response;
    });

    $scope.isFarmIDReadonly = true;

//Expenses Payments Costshare details
$scope.gridExpenseCostshare = {
            enableSorting :true,
            enablePaginationControls: true,
            paginationPageSize: 25,
            enableFiltering: true,
            saveSelection: true,
            enableRowHeaderSelection: true,
            selectionRowHeaderWidth: 50,
            multiSelect: false,
            rowHeight: 35,
            showGridFooter:false,
            selectedItems: [],
            columnDefs: [
                  { name:'Source', field: 'payment_source', width: 300,  pinnedLeft:false},
                  { name:'Amount', field: 'share_amount', width: 250,cellFilter:'currency', pinnedLeft:false },
                  { name:'Description', field: 'share_description', width: 170, pinnedLeft:false},
        ],

    };



if(!!$stateParams){
      $scope.selecteddataexpense = $stateParams;
    }


//Expenses  Details
    $scope.viewSelectedExpense = function(){
    if(!!$scope.selecteddataexpense && !!$scope.selecteddataexpense.expense_guid){
        var expguid = $scope.selecteddataexpense.expense_guid;
        $scope.expguid = $scope.selecteddataexpense.expense_guid;
        var expensedetailsid = GetExpenseData.getexpensedata(expguid).get()
                              .$promise.then(
                                function(response){

                                    $scope.selectedexpensedetails = response;
                                    $scope.selecteddatacostshareexpense = _.get($scope.selectedexpensedetails, 'cost_share_json');
                                    $scope.gridExpenseCostshare.data = $scope.selecteddatacostshareexpense;
                                    $scope.selecteddatapaymentexpense = _.get($scope.selectedexpensedetails, 'expense_payments');
                                    $scope.gridExpensePayments.data = $scope.selecteddatapaymentexpense;
                                },
                                function(err){
                                  alert("Service error");
                                }
                             );
        }
    };
    $scope.viewSelectedExpense();


$scope.close = function(){
    $uibModalInstance.dismiss();
};



//  Post request for new expeses
    $scope.submitFarmExpense = function(){
      var response = {"expense_type":$scope.Farmexpense_type,"expense_description":$scope.Farmexpense_desc,"expense_status_desc":$scope.Farmexpense_status,"expense_amount":$scope.Farmexpense_amount,"application_id":$scope.application_id,"farm_id":$scope.farmguid};
      AddExpense.addexpense().save(response)
        .$promise.then(
           function(response){
              $state.reload();
              $uibModalInstance.close(response);
              modalMessageService.showMessage( "Success:","Added New Expense Successfully");
           },
           function(response) {
                $log.debug("ERROR ADDING New Expense :", response);
               if (response.data.result === 'error' ) {
                   modalMessageService.showMessage( "Error:", response.data.message);
                } else {
                    modalMessageService.showMessage( "Error:", "An error occurred. ");
                }
                $log.debug("Error: "+response.status + " " + response.statusText);
            }
      );
    };

 // Submit Edit  Expense
    $scope.submitEditExpense = function(){
      var data={
          "expense_guid": $scope.selectedexpensedetails.expense_guid,
          "expense_amount": $scope.selectedexpensedetails.expense_amount,
          "expense_description":$scope.selectedexpensedetails.expense_description,
          "expense_status_desc":$scope.selectedexpensedetails.expense_status_desc,
          "farm_id":$scope.selectedexpensedetails.farm_id,
          "application_id":$scope.application_id,
          "cost_share_json":$scope.gridExpenseCostshare.data,
      };
      console.log(data);
      UpdateExpense.updateexpense().update({guid:data.expense_guid},data)
            .$promise.then(
               function(response){
                  $state.reload();
                  $uibModalInstance.dismiss();
                  modalMessageService.showMessage( "Success:","Expense Edited Successfully");
               },
               function(response) {
                    $log.debug("ERROR Editing Expense:", response);
                   if (response.data.result === 'error' ) {
                       modalMessageService.showMessage( "Error:", response.data.message);
                    } else {
                        modalMessageService.showMessage( "Error:", "An error occurred. ");
                    }
                    $log.debug("Error: "+response.status + " " + response.statusText);
                }
            );
    };

});