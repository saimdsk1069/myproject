(function () {
    'use strict';
}());
angular.module('agSADCeFarms')
        .controller('FarmContactsController', ['$scope', '$state', '$log', 'FarmContactsFactory', '$sce', '$http', '$window', 'modalService', 'modalMessageService', '$uibModal', '$rootScope',
            function ($scope, $state, $log, FarmContactsFactory, $sce, $http, $window, modalService, modalMessageService, $uibModal, $rootScope) {

                var checkID = FarmContactsFactory.checkfarmID($state.params.farm_id);

                if (checkID) {
                    $rootScope.getAppContacts = function () {
                        FarmContactsFactory.fetchAppContacts($state.params.farm_id).then(
                                function (response) {
                                    $rootScope.appContacts = response;
                                },
                                function (errResponse) {
                                    toastr.clear();
                                    toastr.error('Bad Connectivity / Server Down', 'Error while fetching App Contacts');
                                }
                        );
                    };
                    
                    $scope.APPID = $state.params.farm_id;
                    $scope.onlreadyInEdit = false;

                    $rootScope.getAppContacts();

                    FarmContactsFactory.fetchAppContactsTypes($state.params.farm_id).then(
                            function (response) {
                                $scope.appContactTypes = response;
                            },
                            function (errResponse) {
                                console.error('Error while fetching App Contacts Types');
                                return {};
                            }
                    );

                    $scope.onContactRowClick = function (index, row) {
                        $scope.selectedContact = row;
                        $('.appContactsRow').removeClass('highlighted');
                        $('.appContactsRow-' + index).addClass('highlighted');
                        //console.log(row, index);
                    };

                    $scope.appNewContactType = [];

                    $scope.editContact = function (index, contact) {
                        var modalInstance = $uibModal.open({
                            templateUrl: 'views/farm/farmEditContact.html',
                            controller: 'editFarmContactCtrl',
                            size: 'lg',
                            backdrop: 'static',
                            resolve: {
                                selectedItem : function(){
                                    return contact;
                                }
                            }
                        });

                        modalInstance.result.then(function (selectedItem) {
                            //$scope.selected = selectedItem;
                        }, function () {
                            console.log('Modal dismissed at: ' + new Date());
                        });

                    };


                    $scope.deleteContact = function () {
                        $('tr.appContactsRow').eq(parseInt($('input[name="selectContactsRow"]:checked').val()));

                        var rowData = $rootScope.appContacts[parseInt($('input[name="selectContactsRow"]:checked').val())];

                        FarmContactsFactory.deleteAppContacts(rowData.farm_contact_guid).then(
                                function (response) {
                                    $rootScope.getAppContacts();
                                    toastr.clear();
                                    toastr.success('Success', 'App Contact successfully Deleted');
                                },
                                function (errResponse) {
                                    toastr.clear();
                                    toastr.error('Bad Connectivity / Server Down', 'Error while Deleting App Contact');
                                }
                        );
                    };

                    $scope.addNewContact = function () {
                        var modalInstance = $uibModal.open({
                            templateUrl: 'views/farm/farmcontacts/mdl_add_new_contact.html',
                            controller: 'addFarmContactCtrl',
                            size: 'lg',
                            backdrop: 'static',
                            resolve: {}
                        });

                        modalInstance.result.then(function (selectedItem) {
                            //$scope.selected = selectedItem;
                        }, function () {
                            console.log('Modal dismissed at: ' + new Date());
                        });

                    };
                } else {
                    $scope.IDfailed = true;
                }
            }
        ]).controller('addFarmContactCtrl', function ($rootScope, $scope, $filter, $window, $uibModalInstance, FarmContactsFactory, $state) {

    $scope.contactsGrid = {
        paginationPageSizes: [25, 50, 75, 100],
        enableFiltering: true,
        enableRowSelection: true,
        multiSelect: false,
        enableFullRowSelection: true,
        paginationPageSize: 25,
        columnDefs: [
            {name: 'first_name'},
            {name: 'last_name'},
            {name: 'title'},
            {name: 'organization'},
            {name: 'email_primary', displayName: 'Email'},
            {name: 'phone_primary', displayName: 'Phone'}
        ]
    };

    $scope.contactsGrid.onRegisterApi = function (gridApi) {
        $scope.gridApi2 = gridApi;
    };

    $scope.addNewContact = function () {

        var selectedData = $scope.gridApi2.selection.getSelectedRows();

        var postData = {
            "farm_id": $state.params.farm_id,
            "auth_user_guid": selectedData.length > 0 ? selectedData[0].auth_user_guid : '',
            "contact_type_desc": $scope.appNewContactType ? $scope.appNewContactType.contact_type_desc : '',
            "note": $scope.appNewContactNote ? $scope.appNewContactNote : ''
        };

        if (postData.auth_user_guid == '' || postData.auth_user_guid == null || postData.auth_user_guid == undefined ||
                postData.contact_type_desc == '' || postData.contact_type_desc == null || postData.contact_type_desc == undefined) {

            toastr.clear();
            toastr.warning('Please select Contact Type and Contact from Table', 'Warning');
        } else {

            FarmContactsFactory.postAppNewContact(postData).then(
                    function (response) {
                        $rootScope.getAppContacts();
                        toastr.clear();
                        toastr.success('New Contact updated successfully', 'Success');

                        $uibModalInstance.close('save');
                    },
                    function (errResponse) {
                        console.error('Error while posting App Contact');
                        return {};
                    }
            );
        }


//        console.log(userData);
    };

    $scope.cancelContact = function () {
        $uibModalInstance.dismiss('Close');
    };

    FarmContactsFactory.fetchAppContactsUsers($state.params.farm_id).then(
            function (response) {
                $scope.contactsGrid.data = response;
            },
            function (errResponse) {
                console.error('Error while fetching App Contacts User List');
                return {};
            }
    );

    FarmContactsFactory.fetchAppContactsTypes($state.params.farm_id).then(
            function (response) {
                $scope.appContactTypes = response;
            },
            function (errResponse) {
                console.error('Error while fetching App Contacts Types');
                return {};
            }
    );
}).controller('editFarmContactCtrl', function ($rootScope, $scope,selectedItem, $filter, $window, $uibModalInstance, FarmContactsFactory, $state) {

    $scope.selectedItem = selectedItem;

    $scope.editNewContact = function () {
        var putData = {
            "farm_contact_guid" : $scope.selectedItem ? $scope.selectedItem.farm_contact_guid : '',
            "farm_id": $state.params.farm_id,
            "auth_user_guid": $scope.selectedItem ? $scope.selectedItem.auth_user_guid : '',
            "contact_type_desc": $scope.appEditContactType ? $scope.appEditContactType.contact_type_desc : $scope.selectedItem.contact_type_desc,
            "note": $scope.appEditContactNote ? $scope.appEditContactNote : ''
        };

        if(putData.farm_contact_guid == '' || putData.farm_contact_guid == null || putData.farm_contact_guid == undefined){
            toastr.clear();
            toastr.warning('Error in updating contact.. Please try again', 'Warning');

        $uibModalInstance.dismiss('Cancel');
        }else if(putData.auth_user_guid == '' || putData.auth_user_guid == null || putData.auth_user_guid == undefined){
            toastr.clear();
            toastr.warning('Error in updating contact.. Please try again', 'Warning');

        $uibModalInstance.dismiss('Cancel');
        }else if (putData.contact_type_desc == '' || putData.contact_type_desc == null || putData.contact_type_desc == undefined) {
            toastr.clear();
            toastr.warning('Please select Contact Type', 'Warning');
        } else {

            FarmContactsFactory.putAppContact(putData).then(
                    function (response) {
                        $rootScope.getAppContacts();
                        toastr.clear();
                        toastr.success('Contact updated successfully', 'Success');
                        $uibModalInstance.dismiss('Cancel');
                    },
                    function (errResponse) {
                        console.error('Error while editing App Contact');
                        return {};
                    }
            );
        }


        //console.log(userData);
    };

    $scope.userCancel = function () {
        $uibModalInstance.dismiss('Cancel');
    };

    $scope.cancelContact = function () {
        $uibModalInstance.dismiss('Cancel');
    };

    FarmContactsFactory.fetchAppContactsTypes($state.params.farm_id).then(
            function (response) {
                $scope.appContactTypes = response;
            },
            function (errResponse) {
                console.error('Error while fetching App Contacts Types');
                return {};
            }
    );
});