(function () {
    'use strict';
}());

angular.module('agSADCeFarms')
    .constant("baseURL", "/AG_SADCeFarms/")

    //service for getting the About Page dynamic content
    .service('GetAbout', ['$resource','baseURL',function($resource,baseURL){
        this.getContent = function(){
            console.log('getcontent fired');
            return $resource(baseURL+'pagecontent?content_page=about',{method:'GET'});
        };
        this.updateItem = function(){
            console.log('updateitem fired');
            return $resource(baseURL+'pagecontent?content_id=:itemid', null, {'update':{method:'PUT'}});
        };
    }]);





